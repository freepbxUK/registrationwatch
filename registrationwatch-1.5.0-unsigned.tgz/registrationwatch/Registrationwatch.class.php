<?php
/**
 * Registration Watch for FreePBX 16 and 17.
 *
 * PJSIP registration discovery and current status visibility.
 *
 * @copyright 2026 20 Telecom Ltd (trading as 20tele.com)
 * @license   GPLv3+
 */

namespace FreePBX\modules;

require_once __DIR__ . '/Webhook.php';

class Registrationwatch implements \BMO {

	/** Fallback only. Authoritative version lives in module.xml. */
	const VERSION = '1.5.0';

	const STATUS_REACHABLE = 'Reachable';
	const STATUS_UNREACHABLE = 'Unreachable';
	const STATUS_REGISTERED_NO_QUALIFY = 'Registered (no qualify)';
	const STATUS_UNKNOWN = 'Unknown';
	const STATUS_NOT_REGISTERED = 'Not registered';
	const CSRF_SESSION_KEY = 'registrationwatch_csrf_token';
	const ALERT_TIMING_MAX_SECONDS = 86400;
	const ALERT_STALE_TRANSITION_MAX_SECONDS = 300;
	const AUTO_DISABLE_ABSENT_DEFAULT_SECONDS = 2592000;
	const REPEAT_MODE_NEVER = 'never';
	const REPEAT_MODE_FIVE_MINUTES = '5m';
	const REPEAT_MODE_HOURLY = 'hourly';
	const REPEAT_MODE_DAILY = 'daily';
	const REPEAT_MODE_ESCALATING = 'escalating';
	const REPEAT_MODE_FIBONACCI = 'fibonacci';
	const REPEAT_DAILY_SECONDS = 86400;
	const REPEAT_ESCALATING_BASE_SECONDS = 300;
	const REPEAT_ESCALATING_CEILING_SECONDS = 86400;
	const WEBHOOK_WORKER_BATCH_LIMIT = 6;
	const WEBHOOK_WORKER_BUDGET_SECONDS = 12.0;
	const WEBHOOK_WORKER_DELIVERY_BUDGET_SECONDS = 7.0;
	const REPEAT_MODES = [
		self::REPEAT_MODE_NEVER,
		self::REPEAT_MODE_FIVE_MINUTES,
		self::REPEAT_MODE_HOURLY,
		self::REPEAT_MODE_DAILY,
		self::REPEAT_MODE_ESCALATING,
	];
	const AUTO_HANDOVER_STATE_PREFIX = 'auto_handover_state_';
	const AUTO_HANDOVER_BULK_STATE_KEY = 'auto_handover_bulk_state';
	const EXTENSION_MONITORING_SETTING_PREFIX = 'extension_monitoring_state_';
	const AUTO_HANDOVER_CONFIRM_POLLS_DEFAULT = 2;
	const AUTO_HANDOVER_CONFIRM_POLLS_CHURN = 3;
	const AUTO_HANDOVER_VALIDATION_POLLS = 3;
	const AUTO_HANDOVER_SUSPEND_RELEASE_POLLS = 3;
	const HISTORY_PAGE_SIZE = 25;

	private $settingsDefaults = [
		'alert_enabled' => '0',
		'alert_recipients' => '',
		'repeat_mode' => self::REPEAT_MODE_NEVER,
		'storm_threshold' => '20',
		'ui_show_limit' => '6',
		'alert_on_unreachable' => '1',
		'alert_on_not_registered' => '1',
		'alert_on_recovery' => '1',
		'debounce_seconds' => '0',
		'auto_disable_absent_seconds' => '2592000',
		'trusted_vpn_networks' => '',
		'topology_poll_interval_seconds' => '10',
		'status_history_prune_policy' => 'never',
		'alert_history_prune_policy' => 'never',
		'monitoring_snoozed_until' => '',
		'ui_map_view_mode' => 'card',
		'ui_map_sort_key' => 'extension',
		'ui_map_sort_dir' => 'asc',
		'ui_watched_sort_key' => 'extension',
		'ui_watched_sort_dir' => 'asc',
		'ui_status_history_sort_key' => 'time',
		'ui_status_history_sort_dir' => 'desc',
		'ui_alert_history_sort_key' => 'time',
		'ui_alert_history_sort_dir' => 'desc',
	];

	/** @var \FreePBX */
	private $FreePBX;

	public function __construct($freepbx = null) {
		if ($freepbx === null) {
			throw new \Exception('Not given a FreePBX Object');
		}
		$this->FreePBX = $freepbx;
	}

	public function install(): void {}
	public function uninstall(): void {}

	public function backup(): array {
		$backup = [
			'settings' => [],
			'registrations' => [],
		];

		try {
			$db = $this->db();

			// Backup settings
			$stmt = $db->query('SELECT setting_key, setting_value FROM registrationwatch_settings');
			if ($stmt) {
				$backup['settings'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			}

			// Backup stored registrations
			$stmt = $db->query('SELECT * FROM registrationwatch_registrations');
			if ($stmt) {
				$backup['registrations'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			}
		} catch (\Exception $e) {
			$this->logError('Backup failed: ' . $e->getMessage());
			return [];
		}

		return $backup;
	}

	public function restore($backup): void {
		if (!is_array($backup) || empty($backup)) {
			return;
		}

		try {
			$db = $this->db();

			// Restore settings (upsert to preserve existing values)
			if (isset($backup['settings']) && is_array($backup['settings'])) {
				foreach ($backup['settings'] as $row) {
					$stmt = $db->prepare(
						'INSERT INTO registrationwatch_settings (setting_key, setting_value, updated_at)
						VALUES (:setting_key, :setting_value, :updated_at)
						ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
					);
					$stmt->execute([
						':setting_key' => $row['setting_key'],
						':setting_value' => $row['setting_value'],
						':updated_at' => $this->now(),
					]);
				}
			}

			// Restore stored registrations (preserve discovery flags)
			if (isset($backup['registrations']) && is_array($backup['registrations'])) {
				foreach ($backup['registrations'] as $row) {
					$sourceIp = $this->normaliseSourceIp($row['source_ip'] ?? '');
					$uaClass = isset($row['registration_ua_class']) ? (string)$row['registration_ua_class'] : '';
					$registrationKey = isset($row['registration_key']) && $row['registration_key'] !== ''
						? (string)$row['registration_key']
						: ($sourceIp !== '' ? $this->registrationKey((string)$row['extension'], $sourceIp, $uaClass) : '');
					if ($registrationKey === '') {
						continue;
					}
					$stmt = $db->prepare(
						'INSERT INTO registrationwatch_registrations
							(registration_key, registration_ua_class, extension, description, notes, notes_updated_at, enabled, auto_disabled_absent_at, repeat_mode, discovered, last_known_status, contact_uri,
							 source_ip, source_port, contact_count, transport, user_agent, device_name, firmware_version,
							 contact_expires_at, qualify_frequency, last_heartbeat_at, latency_ms,
							 last_seen_at, last_checked_at, first_discovered_at, last_discovered_at,
							 created_at, updated_at)
						VALUES
							(:registration_key, :registration_ua_class, :extension, :description, :notes, :notes_updated_at, :enabled, :auto_disabled_absent_at, :repeat_mode, :discovered, :last_known_status, :contact_uri,
							 :source_ip, :source_port, :contact_count, :transport, :user_agent, :device_name, :firmware_version,
							 :contact_expires_at, :qualify_frequency, :last_heartbeat_at, :latency_ms,
							 :last_seen_at, :last_checked_at, :first_discovered_at, :last_discovered_at,
							 :created_at, :updated_at)
						ON DUPLICATE KEY UPDATE
							description = VALUES(description),
							notes = VALUES(notes),
							notes_updated_at = VALUES(notes_updated_at),
							enabled = VALUES(enabled),
							auto_disabled_absent_at = VALUES(auto_disabled_absent_at),
							repeat_mode = VALUES(repeat_mode),
							last_known_status = VALUES(last_known_status),
							contact_uri = VALUES(contact_uri),
							source_ip = VALUES(source_ip),
							source_port = VALUES(source_port),
							registration_ua_class = VALUES(registration_ua_class),
							contact_count = VALUES(contact_count),
							transport = VALUES(transport),
							user_agent = VALUES(user_agent),
							device_name = VALUES(device_name),
							firmware_version = VALUES(firmware_version),
							contact_expires_at = VALUES(contact_expires_at),
							qualify_frequency = VALUES(qualify_frequency),
							last_heartbeat_at = VALUES(last_heartbeat_at),
							latency_ms = VALUES(latency_ms),
							last_seen_at = VALUES(last_seen_at),
							last_checked_at = VALUES(last_checked_at),
							last_discovered_at = VALUES(last_discovered_at),
							updated_at = VALUES(updated_at)'
					);
					$stmt->execute([
						':registration_key' => $registrationKey,
						':registration_ua_class' => $uaClass,
						':extension' => $row['extension'],
						':description' => $row['description'] ?? null,
						':notes' => isset($row['notes']) ? substr((string)$row['notes'], 0, 72) : '',
						':notes_updated_at' => $row['notes_updated_at'] ?? null,
						':enabled' => $row['enabled'] ?? 1,
						':auto_disabled_absent_at' => $row['auto_disabled_absent_at'] ?? null,
						':repeat_mode' => isset($row['repeat_mode']) && $row['repeat_mode'] !== null && $row['repeat_mode'] !== ''
							? $this->normaliseRepeatMode((string)$row['repeat_mode'])
							: null,
						':discovered' => $row['discovered'] ?? 1,
						':last_known_status' => $row['last_known_status'] ?? self::STATUS_UNKNOWN,
						':contact_uri' => $row['contact_uri'] ?? null,
						':source_ip' => $sourceIp !== '' ? $sourceIp : null,
						':source_port' => $row['source_port'] ?? null,
						':contact_count' => max(1, (int)($row['contact_count'] ?? 1)),
						':transport' => $row['transport'] ?? null,
						':user_agent' => $row['user_agent'] ?? null,
						':device_name' => $row['device_name'] ?? null,
						':firmware_version' => $row['firmware_version'] ?? null,
						':contact_expires_at' => $row['contact_expires_at'] ?? null,
						':qualify_frequency' => $row['qualify_frequency'] ?? null,
						':last_heartbeat_at' => $row['last_heartbeat_at'] ?? null,
						':latency_ms' => $row['latency_ms'] ?? null,
						':last_seen_at' => $row['last_seen_at'] ?? null,
						':last_checked_at' => $row['last_checked_at'] ?? null,
						':first_discovered_at' => $row['first_discovered_at'] ?? null,
						':last_discovered_at' => $row['last_discovered_at'] ?? null,
						':created_at' => $row['created_at'] ?? $this->now(),
						':updated_at' => $this->now(),
					]);
				}
			}
		} catch (\Exception $e) {
			$this->logError('Restore failed: ' . $e->getMessage());
		}
	}
	public function doConfigPageInit($page): void {}

	public function getVersion(): string {
		try {
			$info = \FreePBX::Modules()->getInfo('registrationwatch');
			if (isset($info['registrationwatch']['version'])) {
				return (string)$info['registrationwatch']['version'];
			}
		} catch (\Exception $e) {
			// Module metadata may be unavailable during early install.
		}

		return self::VERSION;
	}

	public function showPage(): string {
		$data = $this->getPageData(false);
		$webhookPageData = $this->getWebhookPageData();

		return load_view(__DIR__ . '/views/main.php', [
			'moduleVersion' => $this->getVersion(),
			'registrations' => $data['registrations'],
			'statusHistory' => $data['statusHistory'],
			'alertSettings' => $data['alertSettings'],
			'webhookAuthorized' => $webhookPageData['webhookAuthorized'],
			'webhookDestinations' => $webhookPageData['webhookDestinations'],
			'webhookHistory' => $webhookPageData['webhookHistory'],
			'pruneSettings' => $this->getPruneSettings(),
			'alertHistory' => $data['alertHistory'],
			'lastRefresh' => $data['lastRefresh'],
			'refreshError' => $data['refreshError'],
			'emailStatus' => $data['emailStatus'],
			'timeDiagnostics' => $data['timeDiagnostics'],
			'pollIntervalSeconds' => $data['pollIntervalSeconds'],
			'csrfToken' => $this->createCsrfToken(),
		]);
	}

	public function ajaxRequest($req, &$setting): bool {
		switch ($req) {
			case 'refresh':
			case 'setenabled':
			case 'setrepeatmode':
			case 'savenotes':
			case 'saveshowlimit':
			case 'saveuisetting':
			case 'savealerts':
			case 'savetopology':
			case 'testemail':
			case 'gettopology':
			case 'saveprunepolicy':
			case 'gethistory':
			case 'deletestatushistoryrow':
			case 'deletealerthistoryrow':
			case 'resetextensionfromasterisk':
			case 'snoozemonitoring':
			case 'resumemonitoring':
			case 'savewebhook':
			case 'deletewebhook':
			case 'testwebhook':
				return true;
		}

		return false;
	}

	public function ajaxHandler(): array {
		$command = isset($_REQUEST['command']) ? (string)$_REQUEST['command'] : '';

		// CSRF protection: required for all state-modifying operations
		if (!$this->validateCsrfToken()) {
			return ['status' => false, 'message' => _('Invalid security token. Please reload the page and try again.')];
		}

		if (in_array($command, ['savewebhook', 'deletewebhook', 'testwebhook'], true)
			&& !$this->isWebhookAdministrator()) {
			return ['status' => false, 'message' => _('Full FreePBX administrator access is required for webhook management.')];
		}

		switch ($command) {
			case 'refresh':
				return $this->handleRefresh();
			case 'setenabled':
				return $this->handleSetEnabled();
			case 'setrepeatmode':
				return $this->handleSetRepeatMode();
			case 'savenotes':
				return $this->handleSaveNotes();
			case 'saveshowlimit':
				return $this->handleSaveShowLimit();
			case 'saveuisetting':
				return $this->handleSaveUiSetting();
			case 'savealerts':
				return $this->handleSaveAlerts();
			case 'savetopology':
				return $this->handleSaveTopology();
			case 'testemail':
				return $this->handleTestEmail();
			case 'gettopology':
				return $this->handleGetTopology();
			case 'saveprunepolicy':
				return $this->handleSavePrunePolicy();
			case 'gethistory':
				return $this->handleGetHistory();
			case 'deletestatushistoryrow':
				return $this->handleDeleteStatusHistoryRow();
			case 'deletealerthistoryrow':
				return $this->handleDeleteAlertHistoryRow();
			case 'resetextensionfromasterisk':
				return $this->handleResetExtensionFromAsterisk();
			case 'snoozemonitoring':
				return $this->handleSnoozeMonitoring();
			case 'resumemonitoring':
				return $this->handleResumeMonitoring();
			case 'savewebhook':
				return $this->handleSaveWebhook();
			case 'deletewebhook':
				return $this->handleDeleteWebhook();
			case 'testwebhook':
				return $this->handleTestWebhook();
		}

		return ['status' => false, 'message' => _('Unknown command')];
	}

	private function isWebhookAdministrator(): bool {
		if (!isset($_SESSION['AMP_user'])
			|| !is_object($_SESSION['AMP_user'])
			|| !method_exists($_SESSION['AMP_user'], 'checkSection')) {
			return false;
		}

		try {
			return $_SESSION['AMP_user']->checkSection('*') === true;
		} catch (\Throwable $e) {
			$this->logWarning('Webhook administrator authorization could not be verified; access denied.');
			return false;
		}
	}

	private function getWebhookPageData(): array {
		if (!$this->isWebhookAdministrator()) {
			return [
				'webhookAuthorized' => false,
				'webhookDestinations' => [],
				'webhookHistory' => [],
			];
		}

		return [
			'webhookAuthorized' => true,
			'webhookDestinations' => $this->getWebhookDestinationsForDisplay(),
			'webhookHistory' => $this->getRecentWebhookDeliveries(),
		];
	}

	private function handleGetHistory(): array {
		$historyType = isset($_REQUEST['history_type']) ? strtolower(trim((string)$_REQUEST['history_type'])) : '';
		if ($historyType === 'status') {
			return ['status' => true, 'statusHistory' => $this->getStatusHistory()];
		}
		if ($historyType === 'alert') {
			return ['status' => true, 'alertHistory' => $this->getAlertHistory()];
		}

		return ['status' => false, 'message' => _('Unknown history table.')];
	}

	private function handleRefresh(): array {
		try {
			$data = $this->getPageData(true);

			return [
				'status' => $data['refreshError'] === '',
				'message' => $data['refreshError'] === '' ? _('Registration status refreshed.') : $data['refreshError'],
				'registrations' => $data['registrations'],
				'watchedExtensions' => $data['watchedExtensions'],
				'statusHistory' => $data['statusHistory'],
				'alertHistory' => $data['alertHistory'],
				'lastRefresh' => $data['lastRefresh'],
				'timeDiagnostics' => $data['timeDiagnostics'],
				'monitoringState' => $data['monitoringState'],
			];
		} catch (\Exception $e) {
			$message = _('Failed to refresh registration status. Please check the system logs.');
			$this->logError('Refresh failed: ' . $e->getMessage());
			return ['status' => false, 'message' => $message];
		}
	}

	private function handleSetEnabled(): array {
		$registrationId = $this->positiveRequestId('registration_id');
		$enabled = !empty($_REQUEST['enabled']) ? 1 : 0;

		if ($registrationId <= 0) {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$db = $this->db();
		$extStmt = $db->prepare('SELECT extension FROM registrationwatch_registrations WHERE id = :id');
		$extStmt->execute([':id' => $registrationId]);
		$extension = (string)($extStmt->fetchColumn() ?? '');

		if ($extension === '') {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$this->setExtensionConfiguredMonitoringState($extension, $enabled);

		$stmt = $db->prepare('UPDATE registrationwatch_registrations SET enabled = :enabled, updated_at = :updated_at WHERE extension = :extension');
		$stmt->execute([
			':enabled' => $enabled,
			':updated_at' => $this->now(),
			':extension' => $extension,
		]);

		return [
			'status' => true,
			'message' => $enabled ? _('Registration selected.') : _('Registration selection cleared.'),
			'registration_id' => $registrationId,
			'enabled' => $enabled,
			'monitoringState' => $this->getMonitoringState(),
		];
	}

	private function extensionMonitoringSettingKey(string $extension): string {
		return self::EXTENSION_MONITORING_SETTING_PREFIX . $this->normaliseRegistrationExtension($extension);
	}

	private function setExtensionConfiguredMonitoringState(string $extension, int $enabled): void {
		$normalised = $this->normaliseRegistrationExtension($extension);
		if ($normalised === '') {
			return;
		}
		$this->setSetting($this->extensionMonitoringSettingKey($normalised), $enabled ? '1' : '0');
	}

	private function getExtensionConfiguredMonitoringState(string $extension): ?int {
		$normalised = $this->normaliseRegistrationExtension($extension);
		if ($normalised === '') {
			return null;
		}

		$stmt = $this->db()->prepare('SELECT setting_value FROM registrationwatch_settings WHERE setting_key = :setting_key LIMIT 1');
		$stmt->execute([':setting_key' => $this->extensionMonitoringSettingKey($normalised)]);
		$value = $stmt->fetchColumn();
		if ($value !== false && $value !== null && trim((string)$value) !== '') {
			return trim((string)$value) === '1' ? 1 : 0;
		}

		return null;
	}

	private function handleResetExtensionFromAsterisk(): array {
		$registrationId = $this->positiveRequestId('registration_id');
		if ($registrationId <= 0) {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$db = $this->db();
		$extStmt = $db->prepare('SELECT extension FROM registrationwatch_registrations WHERE id = :id');
		$extStmt->execute([':id' => $registrationId]);
		$extension = $this->normaliseRegistrationExtension((string)($extStmt->fetchColumn() ?? ''));
		if ($extension === '') {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$this->clearAutoHandoverState($extension, 'manual_refresh_from_asterisk');

		if (!$this->acquireReconcileLock()) {
			return ['status' => false, 'message' => _('Reset is unavailable because another registration reconcile is running. Try again in a moment.')];
		}

		try {
			$settings = $this->extensionResetSnapshot($extension);
			if (!$settings['ok']) {
				return ['status' => false, 'message' => $settings['message']];
			}

			$allowedDevices = $this->getAllowedPjsipDeviceIds();
			if (!isset($allowedDevices[$extension])) {
				return ['status' => false, 'message' => _('This extension is no longer a configured PJSIP device, so it cannot be rebuilt from Asterisk contacts.')];
			}

			$db->beginTransaction();
			try {
				$now = $this->now();
				$liveContacts = $this->getLiveContacts($allowedDevices);
				$descriptions = $this->getRegistrationDescriptions();
				$description = $descriptions[$extension] ?? '';

				$clearEscalations = $db->prepare(
					'DELETE FROM registrationwatch_alert_escalation
					WHERE registration_id IN (
						SELECT id FROM registrationwatch_registrations WHERE extension = :extension
					)'
				);
				$clearEscalations->execute([':extension' => $extension]);

				$deleteRows = $db->prepare('DELETE FROM registrationwatch_registrations WHERE extension = :extension');
				$deleteRows->execute([':extension' => $extension]);

				$extensionContacts = [];
				foreach ($liveContacts as $contact) {
					if ($this->normaliseRegistrationExtension((string)($contact['extension'] ?? '')) !== $extension) {
						continue;
					}
					$extensionContacts[] = $contact;
				}

				if ($extensionContacts) {
					$insert = $db->prepare(
						'INSERT INTO registrationwatch_registrations
							(registration_key, extension, description, notes, notes_updated_at, enabled, auto_disabled_absent_at, repeat_mode,
								discovered, last_known_status, contact_uri, source_ip, source_port, registration_ua_class,
								transport, user_agent, device_name, firmware_version, contact_count,
								contact_expires_at, qualify_frequency, latency_ms, last_seen_at, last_checked_at,
								created_at, updated_at, first_discovered_at, last_discovered_at)
						VALUES
							(:registration_key, :extension, :description, :notes, :notes_updated_at, :enabled, NULL, :repeat_mode,
								1, :last_known_status, :contact_uri, :source_ip, :source_port, :registration_ua_class,
								:transport, :user_agent, :device_name, :firmware_version, :contact_count,
								:contact_expires_at, :qualify_frequency, :latency_ms, :last_seen_at, :last_checked_at,
								:created_at, :updated_at, :first_discovered_at, :last_discovered_at)'
					);

					foreach ($extensionContacts as $contact) {
						$contactUri = (string)($contact['contact_uri'] ?? '');
						$lastSeenAt = $contactUri !== '' ? $now : null;
						$insert->execute([
							':registration_key' => (string)$contact['registration_key'],
							':extension' => $extension,
							':description' => $description,
							':notes' => $settings['notes'],
							':notes_updated_at' => $settings['notes_updated_at'],
							':enabled' => $settings['enabled'],
							':repeat_mode' => $settings['repeat_mode'],
							':last_known_status' => $this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN),
							':contact_uri' => $contactUri !== '' ? $contactUri : null,
							':source_ip' => $contact['source_ip'] ?? null,
							':source_port' => $contact['source_port'] ?? null,
							':registration_ua_class' => $contact['registration_ua_class'] ?? '',
							':transport' => $contact['transport'] ?? null,
							':user_agent' => $contact['user_agent'] ?? null,
							':device_name' => $contact['device_name'] ?? null,
							':firmware_version' => $contact['firmware_version'] ?? null,
							':contact_count' => max(1, (int)($contact['contact_count'] ?? 1)),
							':contact_expires_at' => $contact['contact_expires_at'] ?? null,
							':qualify_frequency' => $contact['qualify_frequency'] ?? null,
							':latency_ms' => $contact['latency_ms'] ?? null,
							':last_seen_at' => $lastSeenAt,
							':last_checked_at' => $now,
							':created_at' => $now,
							':updated_at' => $now,
							':first_discovered_at' => $now,
							':last_discovered_at' => $now,
						]);
					}
				} else {
					$insert = $db->prepare(
						'INSERT INTO registrationwatch_registrations
							(registration_key, extension, description, notes, notes_updated_at, enabled, auto_disabled_absent_at, repeat_mode,
								discovered, last_known_status, contact_count, last_checked_at,
								created_at, updated_at, first_discovered_at, last_discovered_at)
						VALUES
							(:registration_key, :extension, :description, :notes, :notes_updated_at, :enabled, NULL, :repeat_mode,
								1, :last_known_status, 1, :last_checked_at,
								:created_at, :updated_at, :first_discovered_at, :last_discovered_at)'
					);
					$insert->execute([
						':registration_key' => $this->noContactRegistrationKey($extension),
						':extension' => $extension,
						':description' => $description,
						':notes' => $settings['notes'],
						':notes_updated_at' => $settings['notes_updated_at'],
						':enabled' => $settings['enabled'],
						':repeat_mode' => $settings['repeat_mode'],
						':last_known_status' => self::STATUS_NOT_REGISTERED,
						':last_checked_at' => $now,
						':created_at' => $now,
						':updated_at' => $now,
						':first_discovered_at' => $now,
						':last_discovered_at' => $now,
					]);
				}

				$db->commit();
			} catch (\Throwable $e) {
				if ($db->inTransaction()) {
					$db->rollBack();
				}
				throw $e;
			}

			return [
				'status' => true,
				'message' => _('Registration state reset from Asterisk.'),
				'registrations' => $this->getRegistrationMapRows(),
				'watchedExtensions' => $this->getWatchedExtensionGroups(),
				'statusHistory' => $this->getStatusHistory(),
				'alertHistory' => $this->getAlertHistory(),
				'timeDiagnostics' => $this->getTimeDiagnostics(),
				'monitoringState' => $this->getMonitoringState(),
			];
		} catch (\Throwable $e) {
			$this->logError('Extension reset from Asterisk failed: ' . $e->getMessage());
			return ['status' => false, 'message' => _('Unable to reset from Asterisk. No changes were applied.')];
		} finally {
			$this->releaseReconcileLock();
		}
	}

	private function extensionResetSnapshot(string $extension): array {
		$stmt = $this->db()->prepare(
			'SELECT id, notes, notes_updated_at, enabled, repeat_mode
			FROM registrationwatch_registrations
			WHERE extension = :extension
			ORDER BY id ASC'
		);
		$stmt->execute([':extension' => $extension]);
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

		if (!$rows) {
			return [
				'ok' => false,
				'message' => _('No stored registrations were found for this extension.'),
			];
		}

		$normalise = function ($value): string {
			return trim((string)$value);
		};

		$noteValues = [];
		$preservedRow = null;
		foreach ($rows as $row) {
			$note = $normalise($row['notes'] ?? '');
			if ($note === '') {
				continue;
			}

			$noteValues[$note] = true;
			if ($preservedRow === null) {
				$preservedRow = $row;
			}
		}

		if (count($noteValues) > 1) {
			return [
				'ok' => false,
				'message' => _('Refresh cancelled because this extension has conflicting notes. Make the notes match, then try again.'),
			];
		}

		$enabledConfigured = $this->getExtensionConfiguredMonitoringState($extension);
		$enabled = $enabledConfigured === null ? 0 : $enabledConfigured;
		$repeatMode = null;
		$preservedRow = $preservedRow ?? $rows[0];
		$notes = $normalise($preservedRow['notes'] ?? '');
		$notesUpdatedAt = $normalise($preservedRow['notes_updated_at'] ?? '') !== ''
			? (string)$preservedRow['notes_updated_at']
			: null;

		foreach ($rows as $row) {
			$currentRepeat = isset($row['repeat_mode']) && trim((string)$row['repeat_mode']) !== ''
				? $this->normaliseRepeatMode((string)$row['repeat_mode'])
				: null;
			if ($currentRepeat !== null) {
				$repeatMode = $currentRepeat;
			}
		}

		return [
			'ok' => true,
			'enabled' => $enabled,
			'repeat_mode' => $repeatMode,
			'notes' => $notes,
			'notes_updated_at' => $notesUpdatedAt,
		];
	}

	private function handleSetRepeatMode(): array {
		$registrationId = $this->positiveRequestId('registration_id');
		$rawMode = isset($_REQUEST['repeat_mode']) ? trim((string)$_REQUEST['repeat_mode']) : '';

		if ($registrationId <= 0) {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$repeatMode = $rawMode === '' ? null : $this->normaliseRepeatMode($rawMode);
		$now = $this->now();
		$db = $this->db();
		$extStmt = $db->prepare('SELECT extension FROM registrationwatch_registrations WHERE id = :id');
		$extStmt->execute([':id' => $registrationId]);
		$extension = (string)($extStmt->fetchColumn() ?? '');

		if ($extension === '') {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$stmt = $db->prepare(
			'UPDATE registrationwatch_registrations
			SET repeat_mode = :repeat_mode,
				updated_at = :updated_at
			WHERE extension = :extension'
		);
		$stmt->execute([
			':repeat_mode' => $repeatMode,
			':updated_at' => $now,
			':extension' => $extension,
		]);

		$settings = $this->getAlertSettings();
		$resolvedMode = $this->resolveRepeatMode($repeatMode, $settings);
		if ($resolvedMode === self::REPEAT_MODE_NEVER) {
			$stmt = $db->prepare(
				'DELETE FROM registrationwatch_alert_escalation
				WHERE registration_id IN (
					SELECT id FROM registrationwatch_registrations WHERE extension = :extension
				)'
			);
			$stmt->execute([':extension' => $extension]);
		}

		return [
			'status' => true,
			'message' => _('Repeat alert setting saved.'),
			'registration_id' => $registrationId,
			'repeat_mode' => $repeatMode,
			'resolved_repeat_mode' => $resolvedMode,
		];
	}

	private function handleSaveNotes(): array {
		$registrationId = $this->positiveRequestId('registration_id');
		$notes = isset($_REQUEST['notes']) ? (string)$_REQUEST['notes'] : '';

		if ($registrationId <= 0) {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$notes = trim(preg_replace('/\s+/', ' ', $notes));
		if (function_exists('mb_substr')) {
			$notes = mb_substr($notes, 0, 72);
		} else {
			$notes = substr($notes, 0, 72);
		}

		$now = $this->now();
		$notesUpdatedAt = $notes === '' ? null : $now;

		$db = $this->db();
		$extStmt = $db->prepare('SELECT extension FROM registrationwatch_registrations WHERE id = :id');
		$extStmt->execute([':id' => $registrationId]);
		$extension = (string)($extStmt->fetchColumn() ?? '');

		if ($extension === '') {
			return ['status' => false, 'message' => _('Missing watched registration.')];
		}

		$stmt = $db->prepare(
			'UPDATE registrationwatch_registrations
			SET notes = :notes,
				notes_updated_at = :notes_updated_at,
				updated_at = :updated_at
			WHERE extension = :extension'
		);
		$stmt->execute([
			':notes' => $notes,
			':notes_updated_at' => $notesUpdatedAt,
			':updated_at' => $now,
			':extension' => $extension,
		]);

		return [
			'status' => true,
			'message' => $notes === '' ? _('Registration note cleared.') : _('Registration note saved.'),
			'registration_id' => $registrationId,
			'notes' => $notes,
			'notes_updated_at' => $notesUpdatedAt,
		];
	}

	private function handleSaveShowLimit(): array {
		$showLimit = isset($_REQUEST['show_limit']) ? strtolower(trim((string)$_REQUEST['show_limit'])) : '6';
		$allowed = ['6', '30', '60', '120', 'all'];

		if (!in_array($showLimit, $allowed, true)) {
			$showLimit = '6';
		}

		$now = $this->now();
		$stmt = $this->db()->prepare(
			'INSERT INTO registrationwatch_settings (setting_key, setting_value, updated_at)
			VALUES (:setting_key, :setting_value, :updated_at)
			ON DUPLICATE KEY UPDATE
				setting_value = VALUES(setting_value),
				updated_at = VALUES(updated_at)'
		);
		$stmt->execute([
			':setting_key' => 'ui_show_limit',
			':setting_value' => $showLimit,
			':updated_at' => $now,
		]);

		return [
			'status' => true,
			'message' => _('Show limit saved.'),
			'show_limit' => $showLimit,
		];
	}

	private function handleSaveUiSetting(): array {
		$dirs = ['asc', 'desc'];
		$rules = [
			'ui_map_view_mode'              => ['card', 'row'],
			'ui_map_sort_key'               => ['extension', 'status', 'description', 'device_ip', 'network_ip', 'device', 'contact_expires', 'qualify', 'latency'],
			'ui_map_sort_dir'               => $dirs,
			'ui_watched_sort_key'           => ['monitored', 'extension', 'description', 'repeat', 'notes'],
			'ui_watched_sort_dir'           => $dirs,
			'ui_status_history_sort_key'    => ['time', 'extension', 'from', 'to', 'source', 'reason', 'latency'],
			'ui_status_history_sort_dir'    => $dirs,
			'ui_alert_history_sort_key'     => ['time', 'extension', 'type', 'status', 'recipient', 'result', 'error'],
			'ui_alert_history_sort_dir'     => $dirs,
		];
		$key = isset($_REQUEST['key']) ? (string)$_REQUEST['key'] : '';
		$value = isset($_REQUEST['value']) ? strtolower(trim((string)$_REQUEST['value'])) : '';
		if (!array_key_exists($key, $rules)) {
			return ['status' => false, 'message' => _('Unknown UI setting.')];
		}
		if (!in_array($value, $rules[$key], true)) {
			return ['status' => false, 'message' => _('Invalid value for UI setting.')];
		}
		$this->setSetting($key, $value);
		return ['status' => true];
	}

	private function handleSaveAlerts(): array {
		$recipientsRaw = isset($_REQUEST['alert_recipients']) ? (string)$_REQUEST['alert_recipients'] : '';
		$recipients = $this->normaliseRecipients($recipientsRaw);
		if ($recipientsRaw !== '' && !$recipients) {
			return ['status' => false, 'message' => _('Enter at least one valid email recipient.')];
		}
		$debounceSeconds = $this->normaliseAlertTimingSeconds('debounce_seconds', $this->settingsDefaults['debounce_seconds']);
		if ($debounceSeconds === null) {
			return ['status' => false, 'message' => _('Debounce delay must be a whole number from 0 to 86400 seconds.')];
		}
		$stormThreshold = $this->normaliseStormThreshold(isset($_REQUEST['storm_threshold']) ? (string)$_REQUEST['storm_threshold'] : $this->settingsDefaults['storm_threshold']);
		if ($stormThreshold === null) {
			return ['status' => false, 'message' => _('Storm Threshold must be a whole number from 0 to 10000.')];
		}

		$settings = [
			'alert_enabled' => !empty($_REQUEST['alert_enabled']) ? '1' : '0',
			'alert_recipients' => implode(', ', $recipients),
			'repeat_mode' => $this->normaliseRepeatMode(isset($_REQUEST['repeat_mode']) ? (string)$_REQUEST['repeat_mode'] : $this->settingsDefaults['repeat_mode']),
			'storm_threshold' => (string)$stormThreshold,
			'alert_on_unreachable' => !empty($_REQUEST['alert_on_unreachable']) ? '1' : '0',
			'alert_on_not_registered' => !empty($_REQUEST['alert_on_not_registered']) ? '1' : '0',
			'alert_on_recovery' => !empty($_REQUEST['alert_on_recovery']) ? '1' : '0',
			'debounce_seconds' => (string)$debounceSeconds,
		];

		foreach ($settings as $key => $value) {
			$this->setSetting($key, $value);
		}

		return [
			'status' => true,
			'message' => _('Alert settings saved.'),
			'alertSettings' => $this->getAlertSettings(),
		];
	}

	private function handleSaveTopology(): array {
		$vpnNetworks = isset($_REQUEST['trusted_vpn_networks']) ? (string)$_REQUEST['trusted_vpn_networks'] : '';
		$pollInterval = (int)($_REQUEST['topology_poll_interval_seconds'] ?? 10);

		// Enforce minimum 5 seconds if not disabled (0 or negative)
		if ($pollInterval > 0 && $pollInterval < 5) {
			$pollInterval = 5;
		} elseif ($pollInterval < 0) {
			$pollInterval = 0;
		}

		$settings = [
			'trusted_vpn_networks' => $vpnNetworks,
			'topology_poll_interval_seconds' => (string)$pollInterval,
		];

		foreach ($settings as $key => $value) {
			$this->setSetting($key, $value);
		}

		return [
			'status' => true,
			'message' => _('Topology settings saved.'),
			'alertSettings' => $this->getAlertSettings(),
		];
	}

	private function getSystemIdentifier(): string {
		try {
			if (!class_exists('\\FreePBX')) {
				return 'unknown system';
			}
			$value = trim((string)\FreePBX::Config()->get('FREEPBX_SYSTEM_IDENT'));
			if ($value !== '') {
				return preg_replace('/\s+/', ' ', $value) ?? $value;
			}
		} catch (\Throwable $e) {
		}

		return 'unknown system';
	}

	private function handleTestEmail(): array {
		$settings = $this->getAlertSettings();
		$recipients = $this->normaliseRecipients($settings['alert_recipients']);
		if (!$recipients) {
			return ['status' => false, 'message' => _('No valid alert recipients are configured.')];
		}

		$now = $this->now();
		$sent = 0;
		$failed = 0;
		foreach ($recipients as $recipient) {
			$subject = _('Registration Watch: test email');
			$message = 'Registration Watch test email from ' . $this->getSystemIdentifier() . "\n\nTime: " . $now . "\nSource: manual test\n\nPlease note: Email \"From:\" Address has been configured in Advanced Settings.\n";
			$result = $this->sendEmail($recipient, $subject, $message);
			if ($result['status']) {
				$sent++;
			} else {
				$failed++;
			}
			$this->insertAlertHistory([
				'extension' => '',
				'history_id' => null,
				'alert_type' => 'test',
				'status' => 'test',
				'recipient' => $recipient,
				'subject' => $subject,
				'message' => $message,
				'sent_at' => $now,
				'result' => $result['status'] ? 'sent' : 'failed',
				'error' => $result['status'] ? null : $result['message'],
			]);
		}

		$status = $sent > 0;
		if ($sent === 0) {
			$message = sprintf(_('Test email failed for %d recipient(s).'), $failed);
		} elseif ($failed > 0) {
			$message = sprintf(_('Test email accepted by local mailer for %d recipient(s); %d failed. Delivery is not confirmed.'), $sent, $failed);
		} else {
			$message = sprintf(_('Test email accepted by local mailer for %d recipient(s). Delivery is not confirmed.'), $sent);
		}

		return [
			'status' => $status,
			'message' => $message,
			'alertHistory' => $this->getAlertHistory(),
		];
	}

	private function handleSaveWebhook(): array {
		$id = isset($_REQUEST['destination_id']) ? trim((string)$_REQUEST['destination_id']) : '';
		$name = isset($_REQUEST['name']) ? trim((string)$_REQUEST['name']) : '';
		$url = isset($_REQUEST['url']) ? trim((string)$_REQUEST['url']) : '';
		$method = isset($_REQUEST['method']) ? strtoupper(trim((string)$_REQUEST['method'])) : 'POST';
		$enabled = !empty($_REQUEST['enabled']);
		$allowPrivate = !empty($_REQUEST['allow_private']);
		$template = isset($_REQUEST['payload_template']) ? trim((string)$_REQUEST['payload_template']) : '';

		if ($name === '' || strlen($name) > 80) {
			return ['status' => false, 'message' => _('Enter a destination name of 1 to 80 characters.')];
		}
		if (!in_array($method, ['POST', 'GET'], true)) {
			return ['status' => false, 'message' => _('Choose POST or GET as the HTTP method.')];
		}
		$urlError = null;
		if (RegistrationwatchWebhook::validateDestinationUrl($url, $allowPrivate, $urlError) === null) {
			return ['status' => false, 'message' => _($urlError)];
		}
		if (strlen($template) > RegistrationwatchWebhook::MAX_PAYLOAD_BYTES) {
			return ['status' => false, 'message' => _('The JSON payload template exceeds 8192 bytes.')];
		}
		if ($template !== '') {
			preg_match_all('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', $template, $variables);
			$allowedVariables = ['event', 'event_id', 'extension', 'technology', 'previous_status', 'current_status', 'timestamp', 'source', 'system_identifier', 'alert_type'];
			foreach ($variables[1] as $variable) {
				if (!in_array($variable, $allowedVariables, true)) {
					return ['status' => false, 'message' => sprintf(_('Unknown payload variable: %s.'), $variable)];
				}
			}
			$templateError = null;
			$rendered = RegistrationwatchWebhook::renderPayload($template, [
				'event' => 'registration.unregistered',
				'event_id' => str_repeat('a', 64),
				'extension' => '2001',
				'technology' => 'PJSIP',
				'previous_status' => self::STATUS_REACHABLE,
				'current_status' => self::STATUS_NOT_REGISTERED,
				'timestamp' => gmdate('c'),
				'source' => 'Registration Watch',
				'system_identifier' => $this->getSystemIdentifier(),
				'alert_type' => 'not_registered',
			], $templateError);
			if ($rendered === null) {
				return ['status' => false, 'message' => _($templateError)];
			}
		}

		if ($id !== '' && !preg_match('/^[a-f0-9]{32}$/', $id)) {
			return ['status' => false, 'message' => _('Invalid webhook destination identifier.')];
		}

		$headersJson = isset($_REQUEST['custom_headers_json']) ? trim((string)$_REQUEST['custom_headers_json']) : '';
		$decodedHeaders = null;
		if ($headersJson !== '' && empty($_REQUEST['clear_headers'])) {
			$decodedHeaders = json_decode($headersJson, true);
			if (!is_array($decodedHeaders) || json_last_error() !== JSON_ERROR_NONE || substr(ltrim($headersJson), 0, 1) !== '{') {
				return ['status' => false, 'message' => _('Custom headers must be a valid JSON object of header names and values.')];
			}
			$headersError = null;
			$headers = RegistrationwatchWebhook::validateHeaders($decodedHeaders, $headersError);
			if ($headers === null) {
				return ['status' => false, 'message' => _($headersError)];
			}
		}

		if (!$this->acquireWebhookConfigurationLock(10)) {
			return ['status' => false, 'message' => _('Webhook configuration is currently being updated. Try again shortly.')];
		}
		$destinationLocked = false;
		try {
			$destinations = $this->getWebhookDestinations();
			$existing = null;
			if ($id !== '') {
				foreach ($destinations as $destination) {
					if ((string)$destination['id'] === $id) {
						$existing = $destination;
						break;
					}
				}
				if ($existing === null) {
					return ['status' => false, 'message' => _('The webhook destination no longer exists. Reload the page and try again.')];
				}
			} elseif (count($destinations) >= RegistrationwatchWebhook::MAX_DESTINATIONS) {
				return ['status' => false, 'message' => _('A maximum of 20 webhook destinations is allowed.')];
			} else {
				try {
					$id = bin2hex(random_bytes(16));
				} catch (\Throwable $e) {
					$this->logError('Unable to generate a webhook destination identifier.');
					return ['status' => false, 'message' => _('Unable to create the webhook destination.')];
				}
			}

			$destinationLocked = $this->acquireWebhookDestinationLock($id, 10);
			if (!$destinationLocked) {
				return ['status' => false, 'message' => _('The webhook destination is currently delivering. Try again shortly.')];
			}

			$headersEncrypted = (string)($existing['headers_encrypted'] ?? '');
			if (!empty($_REQUEST['clear_headers'])) {
				$headersEncrypted = '';
			} elseif ($decodedHeaders !== null) {
				$masterSecret = $this->getWebhookMasterSecret();
				if ($decodedHeaders && $masterSecret === '') {
					return ['status' => false, 'message' => _('FreePBX database encryption settings are unavailable; custom authentication headers cannot be saved safely.')];
				}
				$headersEncrypted = $decodedHeaders
					? (RegistrationwatchWebhook::encryptHeaders($decodedHeaders, $masterSecret) ?? '')
					: '';
				if ($decodedHeaders && $headersEncrypted === '') {
					return ['status' => false, 'message' => _('Unable to encrypt the custom authentication headers.')];
				}
			}

			$record = [
				'id' => $id,
				'name' => $name,
				'url' => $url,
				'enabled' => $enabled ? 1 : 0,
				'method' => $method,
				'allow_private' => $allowPrivate ? 1 : 0,
				'payload_template' => $template,
				'headers_encrypted' => $headersEncrypted,
			];
			$replaced = false;
			foreach ($destinations as $index => $destination) {
				if ((string)$destination['id'] === $id) {
					$destinations[$index] = $record;
					$replaced = true;
					break;
				}
			}
			if (!$replaced) {
				$destinations[] = $record;
			}

			$saveError = $this->saveWebhookDestinations($destinations);
			$materialChange = $existing !== null && (
				$this->webhookDestinationDeliveryFingerprint($existing)
					!== $this->webhookDestinationDeliveryFingerprint($record)
			);
			if ($saveError === null && $materialChange) {
				$this->suppressWebhookDeliveries(
					$id,
					'Destination configuration changed before delivery.'
				);
			}
			if ($saveError !== null) {
				return ['status' => false, 'message' => _($saveError)];
			}
		} finally {
			if ($destinationLocked) {
				$this->releaseWebhookDestinationLock($id);
			}
			$this->releaseWebhookConfigurationLock();
		}
		return [
			'status' => true,
			'message' => _('Webhook destination saved.'),
			'webhookDestinations' => $this->getWebhookDestinationsForDisplay(),
		];
	}

	private function handleDeleteWebhook(): array {
		$id = isset($_REQUEST['destination_id']) ? trim((string)$_REQUEST['destination_id']) : '';
		if (!preg_match('/^[a-f0-9]{32}$/', $id)) {
			return ['status' => false, 'message' => _('Invalid webhook destination identifier.')];
		}
		if (!$this->acquireWebhookConfigurationLock(10)) {
			return ['status' => false, 'message' => _('Webhook configuration is currently being updated. Try again shortly.')];
		}
		$destinationLocked = false;
		try {
			$destinations = $this->getWebhookDestinations();
			$remaining = array_values(array_filter($destinations, static function (array $destination) use ($id): bool {
				return (string)($destination['id'] ?? '') !== $id;
			}));
			if (count($remaining) === count($destinations)) {
				return ['status' => false, 'message' => _('The webhook destination no longer exists.')];
			}
			$destinationLocked = $this->acquireWebhookDestinationLock($id, 10);
			if (!$destinationLocked) {
				return ['status' => false, 'message' => _('The webhook destination is currently delivering. Try again shortly.')];
			}
			$saveError = $this->saveWebhookDestinations($remaining);
			if ($saveError === null) {
				$this->suppressWebhookDeliveries($id, 'Destination removed before delivery.');
			}
			if ($saveError !== null) {
				return ['status' => false, 'message' => _($saveError)];
			}
		} finally {
			if ($destinationLocked) {
				$this->releaseWebhookDestinationLock($id);
			}
			$this->releaseWebhookConfigurationLock();
		}
		return [
			'status' => true,
			'message' => _('Webhook destination removed.'),
			'webhookDestinations' => $this->getWebhookDestinationsForDisplay(),
			'webhookHistory' => $this->getRecentWebhookDeliveries(),
		];
	}

	private function handleTestWebhook(): array {
		$id = isset($_REQUEST['destination_id']) ? trim((string)$_REQUEST['destination_id']) : '';
		$destination = $this->getWebhookDestination($id);
		if ($destination === null) {
			return ['status' => false, 'message' => _('Select an existing webhook destination.')];
		}
		$destination = $this->prepareWebhookDestination($destination);
		if (isset($destination['error'])) {
			return ['status' => false, 'message' => $destination['error']];
		}

		try {
			$eventId = hash('sha256', 'registrationwatch:test:' . bin2hex(random_bytes(16)));
		} catch (\Throwable $e) {
			$this->logError('Unable to generate a webhook test event identifier.');
			return ['status' => false, 'message' => _('Unable to create the webhook test event.')];
		}
		$variables = [
			'event' => 'registration.test',
			'event_id' => $eventId,
			'extension' => '',
			'technology' => 'PJSIP',
			'previous_status' => '',
			'current_status' => '',
			'timestamp' => gmdate('c'),
			'source' => 'Registration Watch',
			'system_identifier' => $this->getSystemIdentifier(),
			'alert_type' => 'test',
		];
		$payloadError = null;
		$payload = RegistrationwatchWebhook::renderPayload(
			(string)($destination['payload_template'] ?? ''),
			$variables,
			$payloadError
		);
		if ($payload === null) {
			return ['status' => false, 'message' => _($payloadError)];
		}
		$result = RegistrationwatchWebhook::deliver($destination, $payload);
		$statusText = $result['http_status'] !== null
			? sprintf(_('HTTP %d'), (int)$result['http_status'])
			: (string)$result['error'];
		return [
			'status' => !empty($result['status']),
			'message' => !empty($result['status'])
				? sprintf(_('Test webhook accepted with %s.'), $statusText)
				: sprintf(_('Test webhook failed: %s'), $statusText),
			'http_status' => $result['http_status'],
		];
	}

	private function getWebhookDestinations(): array {
		$stmt = $this->db()->prepare('SELECT setting_value FROM registrationwatch_settings WHERE setting_key = :setting_key LIMIT 1');
		$stmt->execute([':setting_key' => 'webhook_destinations']);
		$raw = (string)($stmt->fetchColumn() ?? '');
		if ($raw === '') {
			return [];
		}
		$destinations = json_decode($raw, true);
		if (!is_array($destinations) || json_last_error() !== JSON_ERROR_NONE) {
			$this->logWarning('Stored webhook destination configuration is invalid JSON.');
			return [];
		}
		return array_values(array_filter($destinations, static function ($destination): bool {
			return is_array($destination)
				&& preg_match('/^[a-f0-9]{32}$/', (string)($destination['id'] ?? ''))
				&& isset($destination['url'], $destination['name']);
		}));
	}

	private function saveWebhookDestinations(array $destinations): ?string {
		$encoded = json_encode(array_values($destinations), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if (!is_string($encoded)) {
			return 'Unable to encode webhook destination configuration.';
		}
		if (strlen($encoded) > RegistrationwatchWebhook::MAX_DESTINATION_CONFIG_BYTES) {
			return 'Webhook destination configuration exceeds the supported storage limit.';
		}
		$this->setSetting('webhook_destinations', $encoded);
		return null;
	}

	private function webhookDestinationDeliveryFingerprint(array $destination): string {
		return hash('sha256', json_encode([
			'url' => (string)($destination['url'] ?? ''),
			'method' => strtoupper((string)($destination['method'] ?? 'POST')),
			'allow_private' => !empty($destination['allow_private']) ? 1 : 0,
			'enabled' => !empty($destination['enabled']) ? 1 : 0,
			'headers_encrypted' => (string)($destination['headers_encrypted'] ?? ''),
		], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
	}

	private function suppressWebhookDeliveries(string $destinationId, string $reason): void {
		$stmt = $this->db()->prepare(
			"UPDATE registrationwatch_webhook_queue
			SET status = 'suppressed', last_error = :error, updated_at = :updated_at
			WHERE destination_id = :destination_id
				AND status IN ('pending', 'processing')"
		);
		$stmt->execute([
			':error' => substr($reason, 0, 512),
			':updated_at' => $this->now(),
			':destination_id' => $destinationId,
		]);
	}

	private function acquireWebhookDestinationLock(string $destinationId, int $timeoutSeconds): bool {
		return $this->acquireWebhookAdvisoryLock('rw_hook_' . $destinationId, $timeoutSeconds);
	}

	private function releaseWebhookDestinationLock(string $destinationId): void {
		$this->releaseWebhookAdvisoryLock('rw_hook_' . $destinationId);
	}

	private function acquireWebhookConfigurationLock(int $timeoutSeconds): bool {
		return $this->acquireWebhookAdvisoryLock('rw_hook_config', $timeoutSeconds);
	}

	private function releaseWebhookConfigurationLock(): void {
		$this->releaseWebhookAdvisoryLock('rw_hook_config');
	}

	private function acquireWebhookAdvisoryLock(string $lockName, int $timeoutSeconds): bool {
		try {
			$db = $this->db();
			if ($db->getAttribute(\PDO::ATTR_DRIVER_NAME) !== 'mysql') {
				return true;
			}
			$stmt = $db->query(
				'SELECT GET_LOCK(' . $db->quote($lockName)
				. ', ' . max(0, $timeoutSeconds) . ')'
			);
			return $stmt !== false && (int)$stmt->fetchColumn() === 1;
		} catch (\Throwable $e) {
			$this->logWarning('Webhook destination lock could not be acquired; the configuration/delivery race is deferred.');
			return false;
		}
	}

	private function releaseWebhookAdvisoryLock(string $lockName): void {
		try {
			$db = $this->db();
			if ($db->getAttribute(\PDO::ATTR_DRIVER_NAME) !== 'mysql') {
				return;
			}
			$db->query(
				'SELECT RELEASE_LOCK(' . $db->quote($lockName) . ')'
			);
		} catch (\Throwable $e) {
			$this->logWarning('Webhook destination lock could not be released explicitly; MySQL will release it with the connection.');
		}
	}

	private function getWebhookDestination(string $id): ?array {
		if (!preg_match('/^[a-f0-9]{32}$/', $id)) {
			return null;
		}
		foreach ($this->getWebhookDestinations() as $destination) {
			if ((string)$destination['id'] === $id) {
				return $destination;
			}
		}
		return null;
	}

	private function getWebhookMasterSecret(): string {
		return $this->getFreePBXConfigValue('AMPDBPASS');
	}

	private function prepareWebhookDestination(array $destination): array {
		$encrypted = (string)($destination['headers_encrypted'] ?? '');
		if ($encrypted === '') {
			$destination['headers'] = [];
			return $destination;
		}
		$headers = RegistrationwatchWebhook::decryptHeaders($encrypted, $this->getWebhookMasterSecret());
		if ($headers === null) {
			$this->logWarning('Unable to decrypt webhook authentication headers; re-save the destination credentials.');
			return ['error' => _('Saved authentication headers cannot be decrypted. Re-enter them and save this destination.')];
		}
		$destination['headers'] = $headers;
		return $destination;
	}

	private function getWebhookDestinationsForDisplay(): array {
		$display = [];
		foreach ($this->getWebhookDestinations() as $destination) {
			$headers = [];
			if (!empty($destination['headers_encrypted'])) {
				$prepared = $this->prepareWebhookDestination($destination);
				if (!isset($prepared['error'])) {
					$headers = array_keys((array)($prepared['headers'] ?? []));
				}
			}
			$display[] = [
				'id' => (string)$destination['id'],
				'name' => (string)$destination['name'],
				'url' => (string)$destination['url'],
				'method' => (string)($destination['method'] ?? 'POST'),
				'enabled' => !empty($destination['enabled']),
				'allow_private' => !empty($destination['allow_private']),
				'payload_template' => (string)($destination['payload_template'] ?? ''),
				'header_names' => $headers,
				'has_custom_headers' => !empty($destination['headers_encrypted']),
			];
		}
		return $display;
	}

	private function getRecentWebhookDeliveries(?string $destinationId = null): array {
		$sql = 'SELECT destination_id, event_id, history_id, alert_type, event_type, status, attempts, http_status, last_error, last_attempt_at, created_at
			FROM registrationwatch_webhook_queue';
		$params = [];
		if ($destinationId !== null && preg_match('/^[a-f0-9]{32}$/', $destinationId)) {
			$sql .= ' WHERE destination_id = :destination_id';
			$params[':destination_id'] = $destinationId;
		}
		$sql .= ' ORDER BY id DESC LIMIT 50';
		$stmt = $this->db()->prepare($sql);
		$stmt->execute($params);
		return $stmt->fetchAll(\PDO::FETCH_ASSOC);
	}

	private function handleGetTopology(): array {
		$this->reconcileIfStale($this->getPollInterval());
		try {
			return [
				'status' => true,
				'registrations' => $this->getRegistrationMapRows(),
				'watchedExtensions' => $this->getWatchedExtensionGroups(),
				'statusHistory' => $this->getStatusHistory(),
				'alertHistory' => $this->getAlertHistory(),
				'timeDiagnostics' => $this->getTimeDiagnostics(),
				'timestamp' => $this->now(),
				'monitoringState' => $this->getMonitoringState(),
			];
		} catch (\Exception $e) {
			$this->logWarning('Registration map retrieval failed: ' . $e->getMessage());
			return [
				'status' => false,
				'message' => _('Unable to load registration map.'),
				'registrations' => [],
				'statusHistory' => [],
				'alertHistory' => [],
				'timeDiagnostics' => $this->getTimeDiagnostics(),
			];
		}
	}

	private function handleSavePrunePolicy(): array {
		try {
			$historyType = isset($_REQUEST['history_type']) ? strtolower(trim((string)$_REQUEST['history_type'])) : '';
			$policy = $this->normalisePrunePolicy(isset($_REQUEST['policy']) ? (string)$_REQUEST['policy'] : 'never');
			$confirmed = !empty($_REQUEST['confirmed']);

			if (!in_array($historyType, ['status', 'alert'], true)) {
				return ['status' => false, 'message' => _('Unknown history table.')];
			}

			if ($policy !== 'never' && !$confirmed) {
				return ['status' => false, 'message' => _('Confirm permanent deletion before applying pruning.')];
			}

			$settingKey = $historyType === 'status' ? 'status_history_prune_policy' : 'alert_history_prune_policy';
			$this->setSetting($settingKey, $policy);

			$deleted = 0;
			if ($policy !== 'never') {
				$result = $this->applyHistoryPruning($historyType, $policy);
				$deleted = $result[$historyType] ?? 0;
			}

			$message = $policy === 'never'
				? _('History pruning disabled. No rows were deleted.')
				: sprintf(_('History pruning policy saved. Permanently deleted %d older row(s).'), $deleted);

			$response = [
				'status' => true,
				'message' => $message,
				'history_type' => $historyType,
				'policy' => $policy,
				'deleted' => $deleted,
				'pruneSettings' => $this->getPruneSettings(),
			];

			if ($historyType === 'status') {
				$response['statusHistory'] = $this->getStatusHistory();
			} else {
				$response['alertHistory'] = $this->getAlertHistory();
			}

			return $response;
		} catch (\Exception $e) {
			$this->logError('History pruning failed: ' . $e->getMessage());
			return ['status' => false, 'message' => _('Unable to update history pruning. Please check the system logs.')];
		}
	}

	private function handleDeleteStatusHistoryRow(): array {
		try {
			$id = $this->positiveRequestId('id');
			if ($id <= 0 || empty($_REQUEST['confirmed'])) {
				return ['status' => false, 'message' => _('Confirm the selected Status History row deletion.')];
			}

			$stmt = $this->db()->prepare('DELETE FROM registrationwatch_status_history WHERE id = :id');
			$stmt->execute([':id' => $id]);
			$deleted = $stmt->rowCount();

			return [
				'status' => true,
				'message' => $deleted > 0 ? _('Status History row permanently deleted.') : _('Status History row was not found.'),
				'deleted' => $deleted,
				'statusHistory' => $this->getStatusHistory(),
			];
		} catch (\Exception $e) {
			$this->logError('Status History row delete failed: ' . $e->getMessage());
			return ['status' => false, 'message' => _('Unable to delete Status History row. Please check the system logs.')];
		}
	}

	private function handleDeleteAlertHistoryRow(): array {
		try {
			$id = $this->positiveRequestId('id');
			if ($id <= 0 || empty($_REQUEST['confirmed'])) {
				return ['status' => false, 'message' => _('Confirm the selected Alert History row deletion.')];
			}

			$stmt = $this->db()->prepare('DELETE FROM registrationwatch_alert_history WHERE id = :id');
			$stmt->execute([':id' => $id]);
			$deleted = $stmt->rowCount();

			return [
				'status' => true,
				'message' => $deleted > 0 ? _('Alert History row permanently deleted.') : _('Alert History row was not found.'),
				'deleted' => $deleted,
				'alertHistory' => $this->getAlertHistory(),
			];
		} catch (\Exception $e) {
			$this->logError('Alert History row delete failed: ' . $e->getMessage());
			return ['status' => false, 'message' => _('Unable to delete Alert History row. Please check the system logs.')];
		}
	}

	private function handleSnoozeMonitoring(): array {
		$allowed = [300, 900, 1800, 3600, 86400];
		$seconds = isset($_REQUEST['seconds']) ? (int)$_REQUEST['seconds'] : 0;
		if (!in_array($seconds, $allowed, true)) {
			return ['status' => false, 'message' => _('Invalid snooze duration.')];
		}
		$until = date('Y-m-d H:i:s', strtotime($this->now()) + $seconds);
		$this->setSetting('monitoring_snoozed_until', $until);
		return [
			'status' => true,
			'message' => _('Monitoring snoozed.'),
			'monitoringState' => $this->getMonitoringState(),
		];
	}

	private function handleResumeMonitoring(): array {
		$this->setSetting('monitoring_snoozed_until', '');
		return [
			'status' => true,
			'message' => _('Monitoring resumed.'),
			'monitoringState' => $this->getMonitoringState(),
		];
	}

	private function getPageData(bool $refreshStatus): array {
		$refreshError = '';
		if ($refreshStatus) {
			try {
				$this->reconcileCurrentStatus();
			} catch (\Exception $e) {
				$this->logError('Status reconciliation failed: ' . $e->getMessage());
				$refreshError = _('Unable to reconcile registration status. Please check the system logs.');
			}
		}

		return [
			'registrations' => $this->getStoredRegistrations(),
			'statusHistory' => $this->getStatusHistory(),
			'alertSettings' => $this->getAlertSettings(),
			'alertHistory' => $this->getAlertHistory(),
			'lastRefresh' => $this->getLastRefreshTime(),
			'emailStatus' => $this->getEmailStatus(),
			'timeDiagnostics' => $this->getTimeDiagnostics(),
			'pollIntervalSeconds' => $this->getPollInterval(),
			'refreshError' => $refreshError,
			'monitoringState' => $this->getMonitoringState(),
		];
	}

	private function getTimeDiagnostics(): array {
		$moduleTime = $this->now();
		$databaseTime = '';

		try {
			$stmt = $this->db()->query('SELECT NOW()');
			$databaseTime = $stmt ? (string)$stmt->fetchColumn() : '';
		} catch (\Throwable $e) {
			$this->logWarning('Database time diagnostic unavailable: ' . $e->getMessage());
		}

		return [
			'module_time' => $moduleTime,
			'database_time' => $databaseTime,
		];
	}

	private function getPollInterval(): int {
		$settings = $this->getAlertSettings();
		$interval = (int)($settings['topology_poll_interval_seconds'] ?? 10);
		// Enforce minimum 5 seconds, default 10 seconds
		if ($interval < 5 && $interval > 0) {
			return 5;
		}
		// 0 or negative means disabled
		if ($interval <= 0) {
			return 0;
		}
		return $interval;
	}
	private function syncDiscoveredRegistrations(?array $liveContacts = null, ?array $allowedDevices = null): void {
		$now = $this->now();
		$allowedDevices = $allowedDevices === null ? $this->getAllowedPjsipDeviceIds() : $allowedDevices;
		$liveContacts = $liveContacts === null ? $this->getLiveContacts($allowedDevices) : $liveContacts;
		$liveContactKeys = array_fill_keys(array_keys($liveContacts), true);
		$liveKeysByExtension = [];
		foreach ($liveContacts as $liveContact) {
			$liveExtension = $this->normaliseRegistrationExtension((string)($liveContact['extension'] ?? ''));
			if ($liveExtension === '') {
				continue;
			}
			$liveKeysByExtension[$liveExtension][] = (string)($liveContact['registration_key'] ?? '');
		}
		$descriptions = $this->getRegistrationDescriptions();
		$liveExtensions = [];
		$db = $this->db();

		foreach ($liveContacts as $registration) {
			$extension = (string)$registration['extension'];
			$liveExtensions[$this->normaliseRegistrationExtension($extension)] = true;
			$stmt = $db->prepare('SELECT id FROM registrationwatch_registrations WHERE registration_key = :registration_key');
			$stmt->execute([':registration_key' => $registration['registration_key']]);
			$id = $stmt->fetchColumn();

			if ($id) {
				$update = $db->prepare(
					'UPDATE registrationwatch_registrations
					SET description = :description,
						discovered = 1,
						enabled = CASE WHEN auto_disabled_absent_at IS NOT NULL THEN 1 ELSE enabled END,
						auto_disabled_absent_at = NULL,
						contact_uri = :contact_uri,
						source_ip = :source_ip,
						source_port = :source_port,
						registration_ua_class = :registration_ua_class,
						transport = :transport,
						user_agent = :user_agent,
						device_name = :device_name,
						firmware_version = :firmware_version,
						contact_count = :contact_count,
						contact_expires_at = :contact_expires_at,
						qualify_frequency = :qualify_frequency,
						last_discovered_at = :last_discovered_at,
						updated_at = :updated_at
					WHERE registration_key = :registration_key'
				);
				$update->execute([
					':description' => $descriptions[$extension] ?? '',
					':contact_uri' => $registration['contact_uri'] ?? null,
					':source_ip' => $registration['source_ip'] ?? null,
					':source_port' => $registration['source_port'] ?? null,
					':registration_ua_class' => $registration['registration_ua_class'] ?? '',
					':transport' => $registration['transport'] ?? null,
					':user_agent' => $registration['user_agent'] ?? null,
					':device_name' => $registration['device_name'] ?? null,
					':firmware_version' => $registration['firmware_version'] ?? null,
					':contact_count' => max(1, (int)($registration['contact_count'] ?? 1)),
					':contact_expires_at' => $registration['contact_expires_at'] ?? null,
					':qualify_frequency' => $registration['qualify_frequency'] ?? null,
					':last_discovered_at' => $now,
					':updated_at' => $now,
					':registration_key' => $registration['registration_key'],
				]);
				continue;
			}

			$placeholderId = $this->placeholderRegistrationId($extension);
			if ($placeholderId > 0) {
				$update = $db->prepare(
					'UPDATE registrationwatch_registrations
					SET registration_key = :registration_key,
						description = :description,
						discovered = 1,
						enabled = CASE WHEN auto_disabled_absent_at IS NOT NULL THEN 1 ELSE enabled END,
						auto_disabled_absent_at = NULL,
						contact_uri = :contact_uri,
						source_ip = :source_ip,
						source_port = :source_port,
						registration_ua_class = :registration_ua_class,
						transport = :transport,
						user_agent = :user_agent,
						device_name = :device_name,
						firmware_version = :firmware_version,
						contact_count = :contact_count,
						contact_expires_at = :contact_expires_at,
						qualify_frequency = :qualify_frequency,
						last_discovered_at = :last_discovered_at,
						updated_at = :updated_at
					WHERE id = :id'
				);
				$update->execute([
					':registration_key' => $registration['registration_key'],
					':description' => $descriptions[$extension] ?? '',
					':contact_uri' => $registration['contact_uri'] ?? null,
					':source_ip' => $registration['source_ip'] ?? null,
					':source_port' => $registration['source_port'] ?? null,
					':registration_ua_class' => $registration['registration_ua_class'] ?? '',
					':transport' => $registration['transport'] ?? null,
					':user_agent' => $registration['user_agent'] ?? null,
					':device_name' => $registration['device_name'] ?? null,
					':firmware_version' => $registration['firmware_version'] ?? null,
					':contact_count' => max(1, (int)($registration['contact_count'] ?? 1)),
					':contact_expires_at' => $registration['contact_expires_at'] ?? null,
					':qualify_frequency' => $registration['qualify_frequency'] ?? null,
					':last_discovered_at' => $now,
					':updated_at' => $now,
					':id' => $placeholderId,
				]);
				continue;
			}

			$deadCandidateDiagnostics = $this->singleDeadCandidateDiagnostics($extension, (string)$registration['registration_key'], $liveKeysByExtension[$this->normaliseRegistrationExtension($extension)] ?? []);
			$this->logSingleDeadCandidateDiagnostics($deadCandidateDiagnostics);

			$deadRegistrationId = $this->singleDeadRegistrationId($extension, $liveContactKeys);
			if ($deadRegistrationId <= 0) {
				$this->logInfo('Registration Watch continuity reuse rejected: ' . ($deadCandidateDiagnostics['rejection_reason'] ?? 'unknown'));
			}
			if ($deadRegistrationId > 0) {
				$update = $db->prepare(
					'UPDATE registrationwatch_registrations
					SET registration_key = :registration_key,
						description = :description,
						discovered = 1,
						enabled = CASE WHEN auto_disabled_absent_at IS NOT NULL THEN 1 ELSE enabled END,
						auto_disabled_absent_at = NULL,
						contact_uri = :contact_uri,
						source_ip = :source_ip,
						source_port = :source_port,
						registration_ua_class = :registration_ua_class,
						transport = :transport,
						user_agent = :user_agent,
						device_name = :device_name,
						firmware_version = :firmware_version,
						contact_count = :contact_count,
						contact_expires_at = :contact_expires_at,
						qualify_frequency = :qualify_frequency,
						last_discovered_at = :last_discovered_at,
						updated_at = :updated_at
					WHERE id = :id'
				);
				$update->execute([
					':registration_key' => $registration['registration_key'],
					':description' => $descriptions[$extension] ?? '',
					':contact_uri' => $registration['contact_uri'] ?? null,
					':source_ip' => $registration['source_ip'] ?? null,
					':source_port' => $registration['source_port'] ?? null,
					':registration_ua_class' => $registration['registration_ua_class'] ?? '',
					':transport' => $registration['transport'] ?? null,
					':user_agent' => $registration['user_agent'] ?? null,
					':device_name' => $registration['device_name'] ?? null,
					':firmware_version' => $registration['firmware_version'] ?? null,
					':contact_count' => max(1, (int)($registration['contact_count'] ?? 1)),
					':contact_expires_at' => $registration['contact_expires_at'] ?? null,
					':qualify_frequency' => $registration['qualify_frequency'] ?? null,
					':last_discovered_at' => $now,
					':updated_at' => $now,
					':id' => $deadRegistrationId,
				]);
				continue;
			}

			$normalisedExtension = $this->normaliseRegistrationExtension($extension);
			$configuredMonitoringState = $this->getExtensionConfiguredMonitoringState($normalisedExtension);
			$inheritedEnabled = $configuredMonitoringState === null ? 0 : $configuredMonitoringState;
			$this->logInfo('Registration Watch continuity fallback insert enabled=' . $inheritedEnabled . ' for extension ' . $normalisedExtension . ', registration_key ' . (string)$registration['registration_key']);

			$insert = $db->prepare(
				'INSERT INTO registrationwatch_registrations
					(registration_key, extension, description, enabled, discovered, last_known_status, contact_uri,
					 source_ip, source_port, registration_ua_class, transport, user_agent, device_name, firmware_version,
					 contact_count, contact_expires_at, qualify_frequency, created_at, updated_at, first_discovered_at, last_discovered_at)
				VALUES
					(:registration_key, :extension, :description, :enabled, 1, :last_known_status, :contact_uri,
					 :source_ip, :source_port, :registration_ua_class, :transport, :user_agent, :device_name, :firmware_version,
					 :contact_count, :contact_expires_at, :qualify_frequency, :created_at, :updated_at, :first_discovered_at, :last_discovered_at)'
			);
			$insert->execute([
				':registration_key' => $registration['registration_key'],
				':extension' => $extension,
				':description' => $descriptions[$extension] ?? '',
				':enabled' => $inheritedEnabled,
				':last_known_status' => self::STATUS_UNKNOWN,
				':contact_uri' => $registration['contact_uri'] ?? null,
				':source_ip' => $registration['source_ip'] ?? null,
				':source_port' => $registration['source_port'] ?? null,
				':registration_ua_class' => $registration['registration_ua_class'] ?? '',
				':transport' => $registration['transport'] ?? null,
				':user_agent' => $registration['user_agent'] ?? null,
				':device_name' => $registration['device_name'] ?? null,
				':firmware_version' => $registration['firmware_version'] ?? null,
				':contact_count' => max(1, (int)($registration['contact_count'] ?? 1)),
				':contact_expires_at' => $registration['contact_expires_at'] ?? null,
				':qualify_frequency' => $registration['qualify_frequency'] ?? null,
				':created_at' => $now,
				':updated_at' => $now,
				':first_discovered_at' => $now,
				':last_discovered_at' => $now,
			]);
		}

		$this->seedMissingDeviceRegistrations($allowedDevices, $liveExtensions, $descriptions, $now);
	}

	private function seedMissingDeviceRegistrations(array $allowedDevices, array $liveExtensions, array $descriptions, string $now): void {
		$knownCounts = $this->storedRegistrationCountsByExtension();
		foreach (array_keys($allowedDevices) as $extension) {
			if (isset($liveExtensions[$extension]) || ($knownCounts[$extension] ?? 0) > 0) {
				continue;
			}
			$configuredMonitoringState = $this->getExtensionConfiguredMonitoringState($extension);
			$enabled = $configuredMonitoringState === null ? 0 : $configuredMonitoringState;

			$stmt = $this->db()->prepare(
				'INSERT IGNORE INTO registrationwatch_registrations
					(registration_key, extension, description, enabled, discovered, last_known_status,
					 contact_count, created_at, updated_at, first_discovered_at, last_discovered_at)
				VALUES
					(:registration_key, :extension, :description, :enabled, 1, :last_known_status,
					 1, :created_at, :updated_at, :first_discovered_at, :last_discovered_at)'
			);
			$stmt->execute([
				':registration_key' => $this->noContactRegistrationKey($extension),
				':extension' => $extension,
				':description' => $descriptions[$extension] ?? '',
				':enabled' => $enabled,
				':last_known_status' => self::STATUS_UNKNOWN,
				':created_at' => $now,
				':updated_at' => $now,
				':first_discovered_at' => $now,
				':last_discovered_at' => $now,
			]);
		}
	}

	private function storedRegistrationCountsByExtension(): array {
		$stmt = $this->db()->query('SELECT extension, COUNT(*) AS total FROM registrationwatch_registrations GROUP BY extension');
		$counts = [];
		foreach ($stmt ? $stmt->fetchAll(\PDO::FETCH_ASSOC) : [] as $row) {
			$extension = $this->normaliseRegistrationExtension((string)($row['extension'] ?? ''));
			if ($extension !== '') {
				$counts[$extension] = (int)($row['total'] ?? 0);
			}
		}

		return $counts;
	}

	private function normaliseExtensionMonitoringState(array $allowedDevices, string $now): void {
		$extensionsStmt = $this->db()->query('SELECT DISTINCT extension FROM registrationwatch_registrations');
		$extensions = $extensionsStmt ? $extensionsStmt->fetchAll(\PDO::FETCH_COLUMN, 0) : [];
		$updateEnabled = $this->db()->prepare(
			'UPDATE registrationwatch_registrations
			SET enabled = :enabled,
				updated_at = :updated_at
			WHERE extension = :extension
				AND enabled <> :enabled'
		);
		$clearAutoDisabled = $this->db()->prepare(
			'UPDATE registrationwatch_registrations
			SET auto_disabled_absent_at = NULL,
				updated_at = :updated_at
			WHERE extension = :extension
				AND auto_disabled_absent_at IS NOT NULL'
		);

		foreach ($extensions as $extension) {
			$normalised = $this->normaliseRegistrationExtension((string)$extension);
			if ($normalised === '' || !isset($allowedDevices[$normalised])) {
				continue;
			}
			$configured = $this->getExtensionConfiguredMonitoringState($normalised);
			if ($configured === null) {
				continue;
			}
			$updateEnabled->execute([
				':enabled' => $configured,
				':updated_at' => $now,
				':extension' => $normalised,
			]);
			if ($configured === 1) {
				$clearAutoDisabled->execute([
					':updated_at' => $now,
					':extension' => $normalised,
				]);
			}
		}
	}

	private function hasStoredRegistrations(): bool {
		if (!$this->tableExists('registrationwatch_registrations')) {
			return false;
		}

		$stmt = $this->db()->query('SELECT COUNT(*) FROM registrationwatch_registrations');
		return $stmt ? (int)$stmt->fetchColumn() > 0 : false;
	}

	private function shouldDeferForEmptyAllowlist(array $allowedDevices): bool {
		return !$allowedDevices && $this->hasStoredRegistrations();
	}

	private function placeholderRegistrationId(string $extension): int {
		$stmt = $this->db()->prepare(
			'SELECT id
			FROM registrationwatch_registrations
			WHERE registration_key = :registration_key
				AND (source_ip IS NULL OR source_ip = "")
			LIMIT 1'
		);
		$stmt->execute([':registration_key' => $this->noContactRegistrationKey($extension)]);
		$id = $stmt->fetchColumn();

		return $id ? (int)$id : 0;
	}

	private function singleDeadRegistrationId(string $extension, ?array $liveContactKeys = null): int {
		$normalisedExtension = $this->normaliseRegistrationExtension($extension);
		if ($normalisedExtension === '') {
			return 0;
		}

		if ($liveContactKeys === null) {
			$stmt = $this->db()->prepare(
				'SELECT id
				FROM registrationwatch_registrations
				WHERE extension = :extension
					AND last_known_status = :status
				ORDER BY id ASC
				LIMIT 2'
			);
			$stmt->execute([
				':extension' => $normalisedExtension,
				':status' => self::STATUS_NOT_REGISTERED,
			]);
			$ids = $stmt->fetchAll(\PDO::FETCH_COLUMN, 0);

			return count($ids) === 1 ? (int)$ids[0] : 0;
		}

		$placeholderKey = $this->noContactRegistrationKey($normalisedExtension);
		$params = [
			':extension' => $normalisedExtension,
			':placeholder_key' => $placeholderKey,
		];
		$sql =
			'SELECT id
			FROM registrationwatch_registrations
			WHERE extension = :extension
				AND discovered = 1
				AND source_ip IS NOT NULL AND source_ip <> ""
				AND registration_key <> :placeholder_key';

		if ($liveContactKeys) {
			$placeholders = [];
			$index = 0;
			foreach (array_keys($liveContactKeys) as $liveKey) {
				$key = ':live_key_' . $index;
				$placeholders[] = $key;
				$params[$key] = (string)$liveKey;
				$index++;
			}
			$sql .= ' AND registration_key NOT IN (' . implode(', ', $placeholders) . ')';
		}

		$sql .= ' ORDER BY id ASC LIMIT 2';
		$stmt = $this->db()->prepare($sql);
		$stmt->execute($params);
		$ids = $stmt->fetchAll(\PDO::FETCH_COLUMN, 0);

		return count($ids) === 1 ? (int)$ids[0] : 0;
	}

	private function singleDeadCandidateDiagnostics(string $extension, string $newRegistrationKey, array $extensionLiveKeys): array {
		$normalisedExtension = $this->normaliseRegistrationExtension($extension);
		$placeholderKey = $this->noContactRegistrationKey($normalisedExtension);

		$stmt = $this->db()->prepare(
			'SELECT id, registration_key, source_ip, discovered, last_known_status, enabled
			FROM registrationwatch_registrations
			WHERE extension = :extension
			ORDER BY id ASC'
		);
		$stmt->execute([':extension' => $normalisedExtension]);
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);

		$liveKeysSet = [];
		foreach ($extensionLiveKeys as $liveKey) {
			$liveKeysSet[(string)$liveKey] = true;
		}

		$candidateCount = 0;
		$predicateMisses = [
			'discovered' => 0,
			'source_ip' => 0,
			'placeholder' => 0,
			'live_key_conflict' => 0,
		];
		$rowDiagnostics = [];

		foreach ($rows as $row) {
			$rowKey = (string)($row['registration_key'] ?? '');
			$hasSourceIp = trim((string)($row['source_ip'] ?? '')) !== '';
			$isDiscovered = (int)($row['discovered'] ?? 0) === 1;
			$isPlaceholder = $rowKey === $placeholderKey;
			$isLiveKey = isset($liveKeysSet[$rowKey]);

			$predicate = [
				'discovered' => $isDiscovered,
				'has_source_ip' => $hasSourceIp,
				'not_placeholder' => !$isPlaceholder,
				'not_live_key' => !$isLiveKey,
			];

			$eligible = $predicate['discovered']
				&& $predicate['has_source_ip']
				&& $predicate['not_placeholder']
				&& $predicate['not_live_key'];

			if ($eligible) {
				$candidateCount++;
			} else {
				if (!$predicate['discovered']) {
					$predicateMisses['discovered']++;
				}
				if (!$predicate['has_source_ip']) {
					$predicateMisses['source_ip']++;
				}
				if (!$predicate['not_placeholder']) {
					$predicateMisses['placeholder']++;
				}
				if (!$predicate['not_live_key']) {
					$predicateMisses['live_key_conflict']++;
				}
			}

			$rowDiagnostics[] = [
				'id' => (int)($row['id'] ?? 0),
				'registration_key' => $rowKey,
				'source_ip' => $row['source_ip'] ?? null,
				'discovered' => (int)($row['discovered'] ?? 0),
				'is_placeholder' => $isPlaceholder,
				'last_known_status' => (string)($row['last_known_status'] ?? ''),
				'enabled' => (int)($row['enabled'] ?? 0),
				'predicates' => $predicate,
				'eligible' => $eligible,
			];
		}

		$rejectionReason = 'single dead candidate found';
		if ($candidateCount === 0) {
			$reasons = [];
			if ($predicateMisses['discovered'] > 0) {
				$reasons[] = 'rows not discovered=' . $predicateMisses['discovered'];
			}
			if ($predicateMisses['source_ip'] > 0) {
				$reasons[] = 'rows missing source_ip=' . $predicateMisses['source_ip'];
			}
			if ($predicateMisses['placeholder'] > 0) {
				$reasons[] = 'placeholder rows=' . $predicateMisses['placeholder'];
			}
			if ($predicateMisses['live_key_conflict'] > 0) {
				$reasons[] = 'rows still live in current keyset=' . $predicateMisses['live_key_conflict'];
			}
			$rejectionReason = 'no dead candidates; ' . ($reasons ? implode(', ', $reasons) : 'no rows matched predicate set');
		} elseif ($candidateCount > 1) {
			$rejectionReason = 'ambiguous dead candidates count=' . $candidateCount;
		}

		return [
			'extension' => $normalisedExtension,
			'new_registration_key' => $newRegistrationKey,
			'live_keys_for_extension' => array_values(array_unique(array_filter(array_map('strval', $extensionLiveKeys), function ($key) {
				return $key !== '';
			}))),
			'rows' => $rowDiagnostics,
			'candidate_count' => $candidateCount,
			'rejection_reason' => $rejectionReason,
		];
	}

	private function logSingleDeadCandidateDiagnostics(array $diagnostics): void {
		$this->logInfo('Registration Watch continuity candidate diagnostics: ' . json_encode($diagnostics));
	}

	private function getPjsipRegistrationTargets(): array {
		if (!$this->tableExists('pjsip')) {
			return [];
		}

		$stmt = $this->db()->query("SELECT DISTINCT id FROM pjsip WHERE keyword = 'type' AND data = 'endpoint'");
		$ids = $stmt ? $stmt->fetchAll(\PDO::FETCH_COLUMN, 0) : [];
		$registrations = [];

		foreach ($ids as $id) {
			$id = trim((string)$id);
			if ($id !== '') {
				$registrations[$id] = true;
			}
		}

		return $registrations;
	}

	private function getAllowedPjsipDeviceIds(): array {
		if (!$this->tableExists('devices')) {
			return [];
		}

		$stmt = $this->db()->query("SELECT id FROM devices WHERE LOWER(tech) = 'pjsip' AND id <> ''");
		$ids = $stmt ? $stmt->fetchAll(\PDO::FETCH_COLUMN, 0) : [];
		$allowed = [];

		foreach ($ids as $id) {
			$id = $this->normaliseRegistrationExtension((string)$id);
			if ($id !== '') {
				$allowed[$id] = true;
			}
		}

		return $allowed;
	}

	private function getRegistrationDescriptions(): array {
		$db = $this->db();
		$descriptions = [];

		if ($this->tableExists('users')) {
			$stmt = $db->query("SELECT extension, name FROM users WHERE extension <> ''");
			foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
				$descriptions[(string)$row['extension']] = (string)$row['name'];
			}
		}

		if ($this->tableExists('devices')) {
			$stmt = $db->query("SELECT id, description FROM devices WHERE LOWER(tech) = 'pjsip' AND id <> ''");
			foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
				$id = (string)$row['id'];
				if (!isset($descriptions[$id]) || $descriptions[$id] === '') {
					$descriptions[$id] = (string)$row['description'];
				}
			}
		}

		return $descriptions;
	}

	private function reconcileIfStale(int $maxAgeSeconds): void {
		$threshold = max(5, $maxAgeSeconds);
		try {
			$stmt = $this->db()->query(
				'SELECT MAX(last_checked_at) FROM registrationwatch_registrations WHERE discovered = 1'
			);
			$latest = $stmt ? $stmt->fetchColumn() : null;
			if ($latest !== null && $latest !== false && $latest !== '') {
				$nowTs = strtotime($this->now());
				$latestTs = strtotime((string)$latest);
				if ($latestTs !== false && ($nowTs - $latestTs) < $threshold) {
					return;
				}
			}
			$this->reconcileCurrentStatus();
		} catch (\Throwable $e) {
			$this->logWarning('Registration Watch stale-guard reconciliation failed: ' . $e->getMessage());
		}
	}

	private function reconcileCurrentStatus(): void {
		if (!$this->acquireReconcileLock()) {
			$this->logWarning('Registration Watch reconcile skipped because another reconcile is already running.');
			return;
		}

		try {
			$this->reconcileCurrentStatusLocked();
		} finally {
			$this->releaseReconcileLock();
		}
	}

	private function reconcileCurrentStatusLocked(): void {
		$allowedDevices = $this->getAllowedPjsipDeviceIds();
		if ($this->shouldDeferForEmptyAllowlist($allowedDevices)) {
			$this->logWarning('Registration Watch PJSIP device allowlist is empty while watched registrations exist; reconciliation deferred to avoid disabling configured devices.');
			return;
		}

		$contacts = $this->getLiveContacts($allowedDevices);
		$this->syncDiscoveredRegistrations($contacts, $allowedDevices);
		$now = $this->now();
		$this->normaliseExtensionMonitoringState($allowedDevices, $now);
		$this->applyAutomaticIpChangeHandover($contacts, $allowedDevices, $now);
		$db = $this->db();
		$registrations = $this->getStoredRegistrations();
		$settings = $this->getAlertSettings();
		$autoDisableAbsentSeconds = $this->autoDisableAbsentSeconds($settings);

		foreach ($registrations as $registration) {
			if ((int)$registration['discovered'] === 0) {
				continue;
			}

			$registrationId = (int)$registration['id'];
			$extension = $this->normaliseRegistrationExtension((string)($registration['extension'] ?? ''));
			if (!isset($allowedDevices[$extension])) {
				$this->disableNonDeviceRegistration($registrationId, $now);
				continue;
			}

			$previousStatus = $this->normaliseState($registration['last_known_status'] ?? self::STATUS_UNKNOWN);
			$previousContactUri = $registration['contact_uri'] ?? null;
			$previousHadContact = $this->hadRegisteredState($previousStatus) || (string)($registration['contact_uri'] ?? '') !== '';
			$registrationKey = (string)$registration['registration_key'];
			$contact = $contacts[$registrationKey] ?? null;
			$status = self::STATUS_NOT_REGISTERED;
			$contactUri = null;
			$latency = null;
			$sourceIp = $registration['source_ip'] ?? null;
			$sourcePort = $registration['source_port'] ?? null;
			$userAgent = $registration['user_agent'] ?? null;
			$deviceName = $registration['device_name'] ?? null;
			$firmwareVersion = $registration['firmware_version'] ?? null;
			$contactExpiresAt = $registration['contact_expires_at'] ?? null;
			$qualifyFrequency = $registration['qualify_frequency'] ?? null;
			$contactCount = max(1, (int)($registration['contact_count'] ?? 1));
			$registrationUaClass = $registration['registration_ua_class'] ?? '';
			$lastSeen = $registration['last_seen_at'] ?: null;
			$enabled = (int)($registration['enabled'] ?? 0);
			$autoDisabledAbsentAt = $registration['auto_disabled_absent_at'] ?? null;

			if ($contact !== null) {
				$status = $contact['status'];
				$contactUri = $contact['contact_uri'];
				$latency = $contact['latency_ms'];
				$sourceIp = $contact['source_ip'] ?? null;
				$sourcePort = $contact['source_port'] ?? null;
				$userAgent = $contact['user_agent'] ?? $userAgent;
				$deviceName = $contact['device_name'] ?? $deviceName;
				$firmwareVersion = $contact['firmware_version'] ?? $firmwareVersion;
				$contactExpiresAt = $contact['contact_expires_at'] ?? $contactExpiresAt;
				$qualifyFrequency = $contact['qualify_frequency'] ?? $qualifyFrequency;
				$contactCount = max(1, (int)($contact['contact_count'] ?? 1));
				$registrationUaClass = $contact['registration_ua_class'] ?? $registrationUaClass;
				if ($contactUri !== '') {
					$lastSeen = $now;
				}
				if ($autoDisabledAbsentAt !== null && $autoDisabledAbsentAt !== '') {
					$enabled = 1;
					$autoDisabledAbsentAt = null;
				}
			} elseif ($this->shouldAutoDisableAbsentRegistration($registration, $autoDisableAbsentSeconds, $now)) {
				$enabled = 0;
				$autoDisabledAbsentAt = $autoDisabledAbsentAt ?: $now;
				$this->deleteEscalationsForRegistration($registrationId);
			}

			if ($previousStatus !== $status) {
				$historyContactUri = $contactUri;
				if ($status === self::STATUS_NOT_REGISTERED && trim((string)$previousContactUri) !== '') {
					$historyContactUri = $previousContactUri;
				}

				$this->insertStatusHistory(
					$registrationId,
					$registrationKey,
					(string)$registration['extension'],
					$previousStatus,
					$status,
					$this->historyReason($previousHadContact, $status),
					$historyContactUri,
					$latency,
					$now
				);
			}

			$stmt = $db->prepare(
				'UPDATE registrationwatch_registrations
				SET last_known_status = :last_known_status,
					enabled = :enabled,
					auto_disabled_absent_at = :auto_disabled_absent_at,
					contact_uri = :contact_uri,
					latency_ms = :latency_ms,
					source_ip = :source_ip,
					source_port = :source_port,
					registration_ua_class = :registration_ua_class,
					user_agent = :user_agent,
					device_name = :device_name,
					firmware_version = :firmware_version,
					contact_count = :contact_count,
					contact_expires_at = :contact_expires_at,
					qualify_frequency = :qualify_frequency,
					last_seen_at = :last_seen_at,
					last_checked_at = :last_checked_at,
					updated_at = :updated_at
				WHERE id = :id'
			);
			$stmt->execute([
				':last_known_status' => $status,
				':enabled' => $enabled,
				':auto_disabled_absent_at' => $autoDisabledAbsentAt,
				':contact_uri' => $contactUri,
				':latency_ms' => $latency,
				':source_ip' => $sourceIp,
				':source_port' => $sourcePort,
				':registration_ua_class' => $registrationUaClass,
				':user_agent' => $userAgent,
				':device_name' => $deviceName,
				':firmware_version' => $firmwareVersion,
				':contact_count' => $contactCount,
				':contact_expires_at' => $contactExpiresAt,
				':qualify_frequency' => $qualifyFrequency,
				':last_seen_at' => $lastSeen,
				':last_checked_at' => $now,
				':updated_at' => $now,
				':id' => $registrationId,
			]);
		}

		$this->normaliseExtensionMonitoringState($allowedDevices, $now);

		$this->processAlertQueue($now);
	}

	private function autoHandoverStateKey(string $extension): string {
		return self::AUTO_HANDOVER_STATE_PREFIX . $this->normaliseRegistrationExtension($extension);
	}

	private function getJsonSettingState(string $key): array {
		$stmt = $this->db()->prepare('SELECT setting_value FROM registrationwatch_settings WHERE setting_key = :setting_key LIMIT 1');
		$stmt->execute([':setting_key' => $key]);
		$raw = (string)($stmt->fetchColumn() ?? '');
		if ($raw === '') {
			return [];
		}
		$decoded = json_decode($raw, true);
		return is_array($decoded) ? $decoded : [];
	}

	private function setJsonSettingState(string $key, array $state): void {
		$encoded = json_encode($state);
		if ($encoded === false) {
			return;
		}
		$this->setSetting($key, $encoded);
	}

	private function clearJsonSettingState(string $key): void {
		$stmt = $this->db()->prepare('DELETE FROM registrationwatch_settings WHERE setting_key = :setting_key');
		$stmt->execute([':setting_key' => $key]);
	}

	private function getAutoHandoverState(string $extension): array {
		return $this->getJsonSettingState($this->autoHandoverStateKey($extension));
	}

	private function setAutoHandoverState(string $extension, array $state): void {
		$this->setJsonSettingState($this->autoHandoverStateKey($extension), $state);
	}

	private function clearAutoHandoverState(string $extension, string $reason = ''): void {
		$this->clearJsonSettingState($this->autoHandoverStateKey($extension));
		if ($reason !== '') {
			$this->logInfo('Registration Watch auto handover candidate reset for extension ' . $extension . ': ' . $reason);
		}
	}

	private function buildLiveSignature(array $contactsForExtension): string {
		$parts = [];
		foreach ($contactsForExtension as $registrationKey => $contact) {
			$parts[] = implode('|', [
				(string)$registrationKey,
				$this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN),
				$this->normaliseSourceIp($contact['source_ip'] ?? ''),
				isset($contact['source_port']) ? (string)$contact['source_port'] : '',
			]);
		}
		sort($parts, SORT_STRING);
		return implode(',', $parts);
	}

	private function reachableReplacementContacts(array $contactsForExtension, string $oldKey, string $oldIp): array {
		$reachable = [];
		foreach ($contactsForExtension as $newKey => $contact) {
			$newStatus = $this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN);
			if ($newStatus !== self::STATUS_REACHABLE) {
				continue;
			}
			$newIp = $this->normaliseSourceIp($contact['source_ip'] ?? '');
			$isDifferentIdentity = ((string)$newKey !== $oldKey) || ($newIp !== '' && $newIp !== $oldIp);
			if (!$isDifferentIdentity) {
				continue;
			}
			$reachable[(string)$newKey] = $contact;
		}
		return $reachable;
	}

	private function applyAutomaticIpChangeHandover(array $contacts, array $allowedDevices, string $now): void {
		$rowsByExtension = [];
		$enabledMonitoredExtensions = [];
		foreach ($this->getStoredRegistrations() as $row) {
			if ((int)($row['discovered'] ?? 0) !== 1) {
				continue;
			}
			$extension = $this->normaliseRegistrationExtension((string)($row['extension'] ?? ''));
			if ($extension === '' || !isset($allowedDevices[$extension])) {
				continue;
			}
			$rowsByExtension[$extension][] = $row;
			if ((int)($row['enabled'] ?? 0) === 1) {
				$enabledMonitoredExtensions[$extension] = true;
			}
		}

		$liveByExtension = [];
		$liveKeys = [];
		foreach ($contacts as $registrationKey => $contact) {
			$extension = $this->normaliseRegistrationExtension((string)($contact['extension'] ?? ''));
			if ($extension === '' || !isset($allowedDevices[$extension])) {
				continue;
			}
			$key = (string)$registrationKey;
			$liveByExtension[$extension][$key] = $contact;
			$liveKeys[$key] = true;
		}

		$globalSignature = $this->buildLiveSignature($contacts);
		$bulkCandidateExtensions = 0;
		foreach (array_keys(array_merge($rowsByExtension, $liveByExtension)) as $extension) {
			$rows = $rowsByExtension[$extension] ?? [];
			$live = $liveByExtension[$extension] ?? [];
			$degradedCount = 0;
			$replacementReachableCount = 0;
			foreach ($rows as $row) {
				if ((int)($row['enabled'] ?? 0) !== 1) {
					continue;
				}
				$status = $this->normaliseState($row['last_known_status'] ?? self::STATUS_UNKNOWN);
				if ($status === self::STATUS_UNREACHABLE || $status === self::STATUS_NOT_REGISTERED) {
					$degradedCount++;
				}
			}
			if ($degradedCount === 0) {
				continue;
			}
			foreach ($live as $contact) {
				if ($this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN) === self::STATUS_REACHABLE) {
					$replacementReachableCount++;
				}
			}
			if ($replacementReachableCount > 0) {
				$bulkCandidateExtensions++;
			}
		}

		$enabledExtensionCount = max(1, count($enabledMonitoredExtensions));
		$bulkAbsoluteThreshold = 3;
		$bulkProportion = $bulkCandidateExtensions / $enabledExtensionCount;
		$isBulkEvent = $bulkCandidateExtensions >= $bulkAbsoluteThreshold && $bulkProportion >= 0.25;

		$bulkState = $this->getJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY);
		if (($bulkState['phase'] ?? '') === 'suspended') {
			$stable = (($bulkState['global_signature'] ?? '') === $globalSignature && !$isBulkEvent)
				? ((int)($bulkState['stable_healthy_polls'] ?? 0) + 1)
				: 0;
			$bulkState['stable_healthy_polls'] = $stable;
			$bulkState['global_signature'] = $globalSignature;
			$bulkState['updated_at'] = $now;
			$this->setJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY, $bulkState);
			if ($stable >= self::AUTO_HANDOVER_SUSPEND_RELEASE_POLLS) {
				$this->clearJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY);
				$this->logInfo('Registration Watch auto handover bulk suspension released after stable healthy polls.');
			} else {
				return;
			}
		} elseif ($isBulkEvent) {
			if (!$bulkState || ($bulkState['phase'] ?? '') !== 'active') {
				$bulkState = [
					'phase' => 'active',
					'first_seen_at' => $now,
					'updated_at' => $now,
					'global_signature' => $globalSignature,
					'stable_polls' => 1,
					'churn_events' => 0,
					'candidate_extensions' => $bulkCandidateExtensions,
				];
				$this->setJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY, $bulkState);
				$this->logWarning('Registration Watch bulk topology event detected; automatic handover delayed. candidate_extensions=' . $bulkCandidateExtensions . ', monitored_extensions=' . $enabledExtensionCount);
				return;
			}

			if (($bulkState['global_signature'] ?? '') === $globalSignature) {
				$bulkState['stable_polls'] = (int)($bulkState['stable_polls'] ?? 0) + 1;
			} else {
				$bulkState['churn_events'] = (int)($bulkState['churn_events'] ?? 0) + 1;
				$bulkState['stable_polls'] = 1;
				$bulkState['global_signature'] = $globalSignature;
			}
			$bulkState['candidate_extensions'] = $bulkCandidateExtensions;
			$bulkState['updated_at'] = $now;
			if ((int)($bulkState['churn_events'] ?? 0) >= 2) {
				$bulkState['phase'] = 'suspended';
				$bulkState['suspend_reason'] = 'bulk_event_flapping';
				$bulkState['stable_healthy_polls'] = 0;
				$this->setJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY, $bulkState);
				$this->logWarning('Registration Watch bulk topology event continues changing; automatic handover bulk-suspended.');
				return;
			}
			$this->setJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY, $bulkState);
			return;
		} elseif ($bulkState && ($bulkState['phase'] ?? '') === 'active') {
			if (($bulkState['global_signature'] ?? '') === $globalSignature) {
				$bulkState['stable_polls'] = (int)($bulkState['stable_polls'] ?? 0) + 1;
			} else {
				$bulkState['stable_polls'] = 0;
				$bulkState['global_signature'] = $globalSignature;
			}
			$bulkState['updated_at'] = $now;
			if ((int)($bulkState['stable_polls'] ?? 0) < 2) {
				$this->setJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY, $bulkState);
				return;
			}
			$this->clearJsonSettingState(self::AUTO_HANDOVER_BULK_STATE_KEY);
			$this->logInfo('Registration Watch bulk topology event stabilized; automatic handover resumed.');
		}

		$extensions = array_unique(array_merge(array_keys($rowsByExtension), array_keys($liveByExtension)));
		$pollWindowSeconds = max(5, $this->getPollInterval());
		$nowTs = strtotime($now);
		if ($nowTs === false) {
			return;
		}

		foreach ($extensions as $extension) {
			$state = $this->getAutoHandoverState($extension);
			$phase = (string)($state['phase'] ?? '');
			$rows = $rowsByExtension[$extension] ?? [];
			$liveForExtension = $liveByExtension[$extension] ?? [];
			$liveSignature = $this->buildLiveSignature($liveForExtension);

			if ($phase === 'suspended') {
				$reachableCount = 0;
				foreach ($liveForExtension as $contact) {
					if ($this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN) === self::STATUS_REACHABLE) {
						$reachableCount++;
					}
				}
				$enabledDegradedCount = 0;
				foreach ($rows as $row) {
					if ((int)($row['enabled'] ?? 0) !== 1) {
						continue;
					}
					$status = $this->normaliseState($row['last_known_status'] ?? self::STATUS_UNKNOWN);
					if ($status === self::STATUS_UNREACHABLE || $status === self::STATUS_NOT_REGISTERED) {
						$enabledDegradedCount++;
					}
				}
				$healthy = $enabledDegradedCount === 0 && $reachableCount === 1;
				if ($healthy && ($state['healthy_signature'] ?? '') === $liveSignature) {
					$state['healthy_polls'] = (int)($state['healthy_polls'] ?? 0) + 1;
				} elseif ($healthy) {
					$state['healthy_signature'] = $liveSignature;
					$state['healthy_polls'] = 1;
				} else {
					$state['healthy_polls'] = 0;
					$state['healthy_signature'] = $liveSignature;
				}
				$state['updated_at'] = $now;
				$this->setAutoHandoverState($extension, $state);
				if ((int)($state['healthy_polls'] ?? 0) >= self::AUTO_HANDOVER_SUSPEND_RELEASE_POLLS) {
					$this->clearAutoHandoverState($extension, 'suspension_released_after_stable_healthy_polls');
				}
				continue;
			}

			if ($phase === 'validation') {
				$expectedNewKey = (string)($state['new_key'] ?? '');
				$expectedOldKey = (string)($state['old_key'] ?? '');
				$reachable = [];
				foreach ($liveForExtension as $key => $contact) {
					if ($this->normaliseState($contact['status'] ?? self::STATUS_UNKNOWN) === self::STATUS_REACHABLE) {
						$reachable[(string)$key] = $contact;
					}
				}
				$valid = count($reachable) === 1
					&& isset($reachable[$expectedNewKey])
					&& ($expectedOldKey === '' || !isset($liveKeys[$expectedOldKey]));
				if (!$valid) {
					$state['phase'] = 'suspended';
					$state['suspended_reason'] = 'post_handover_validation_failed';
					$state['healthy_polls'] = 0;
					$state['updated_at'] = $now;
					$this->setAutoHandoverState($extension, $state);
					$this->logWarning('Registration Watch auto handover post-handover validation failed for extension ' . $extension . '; automatic mutation suspended.');
					continue;
				}

				$state['validation_observations'] = (int)($state['validation_observations'] ?? 0) + 1;
				$this->logInfo('Registration Watch auto handover post-handover validation passed for extension ' . $extension . ': observation ' . $state['validation_observations'] . '/' . self::AUTO_HANDOVER_VALIDATION_POLLS);
				if ((int)$state['validation_observations'] >= self::AUTO_HANDOVER_VALIDATION_POLLS) {
					$this->clearAutoHandoverState($extension);
				} else {
					$state['updated_at'] = $now;
					$this->setAutoHandoverState($extension, $state);
				}
				continue;
			}

			$enabledDegraded = array_values(array_filter($rows, function ($row) {
				if ((int)($row['enabled'] ?? 0) !== 1) {
					return false;
				}
				$status = $this->normaliseState($row['last_known_status'] ?? self::STATUS_UNKNOWN);
				return $status === self::STATUS_UNREACHABLE || $status === self::STATUS_NOT_REGISTERED;
			}));
			if (count($enabledDegraded) !== 1) {
				if ($state) {
					$this->clearAutoHandoverState($extension, 'enabled_degraded_row_count=' . count($enabledDegraded));
				}
				continue;
			}

			$oldRow = $enabledDegraded[0];
			$oldId = (int)$oldRow['id'];
			$oldKey = (string)($oldRow['registration_key'] ?? '');
			$oldIp = $this->normaliseSourceIp($oldRow['source_ip'] ?? '');
			$oldStatus = $this->normaliseState($oldRow['last_known_status'] ?? self::STATUS_UNKNOWN);

			$reachableReplacements = $this->reachableReplacementContacts($liveForExtension, $oldKey, $oldIp);
			if (count($reachableReplacements) !== 1) {
				if ($state) {
					$reason = count($reachableReplacements) > 1 ? 'multiple_reachable_replacements' : 'replacement_missing';
					$this->clearAutoHandoverState($extension, $reason);
				}
				continue;
			}

			$newKey = (string)array_key_first($reachableReplacements);
			$replacement = $reachableReplacements[$newKey];
			$newIp = $this->normaliseSourceIp($replacement['source_ip'] ?? '');

			$duplicateRows = array_values(array_filter($rows, function ($row) use ($oldId, $newKey) {
				return (int)($row['id'] ?? 0) !== $oldId
					&& (string)($row['registration_key'] ?? '') === $newKey;
			}));
			if (count($duplicateRows) !== 1) {
				if ($state) {
					$this->clearAutoHandoverState($extension, 'duplicate_row_count=' . count($duplicateRows));
				}
				continue;
			}

			$duplicateRow = $duplicateRows[0];
			$firstDiscoveredTs = strtotime((string)($duplicateRow['first_discovered_at'] ?? ''));
			if ($firstDiscoveredTs === false || ($nowTs - $firstDiscoveredTs) < $pollWindowSeconds) {
				continue;
			}

			$candidateTuple = [
				'old_id' => $oldId,
				'old_key' => $oldKey,
				'new_key' => $newKey,
				'old_ip' => $oldIp,
				'new_ip' => $newIp,
			];

			if ($oldKey !== '' && isset($liveKeys[$oldKey])) {
				if (!$state
					|| ($state['phase'] ?? '') !== 'pre_candidate'
					|| (int)($state['old_id'] ?? 0) !== $oldId
					|| (string)($state['old_key'] ?? '') !== $oldKey
					|| (string)($state['new_key'] ?? '') !== $newKey
					|| (string)($state['old_ip'] ?? '') !== $oldIp
					|| (string)($state['new_ip'] ?? '') !== $newIp
				) {
					$state = array_merge($candidateTuple, [
						'phase' => 'pre_candidate',
						'pre_observations' => 1,
						'churn_events' => max(1, (int)($state['churn_events'] ?? 0)),
						'confirmations' => 0,
						'live_signature' => $liveSignature,
						'first_seen_at' => $now,
						'updated_at' => $now,
					]);
					$this->setAutoHandoverState($extension, $state);
					$this->logInfo('Registration Watch auto handover candidate first seen for extension ' . $extension . ': old_key=' . $oldKey . ', new_key=' . $newKey . ', old_ip=' . ($oldIp !== '' ? $oldIp : '-') . ', new_ip=' . ($newIp !== '' ? $newIp : '-'));
				} else {
					$state['pre_observations'] = (int)($state['pre_observations'] ?? 0) + 1;
					$state['churn_events'] = max(1, (int)($state['churn_events'] ?? 0));
					$state['updated_at'] = $now;
					$this->setAutoHandoverState($extension, $state);
					$this->logInfo('Registration Watch auto handover confirmation for extension ' . $extension . ': pre-candidate observation ' . (int)$state['pre_observations']);
				}
				continue;
			}

			if (!$state
				|| !in_array((string)($state['phase'] ?? ''), ['tracking', 'pre_candidate'], true)
				|| (int)($state['old_id'] ?? 0) !== $oldId
				|| (string)($state['old_key'] ?? '') !== $oldKey
				|| (string)($state['new_key'] ?? '') !== $newKey
				|| (string)($state['old_ip'] ?? '') !== $oldIp
				|| (string)($state['new_ip'] ?? '') !== $newIp
			) {
				if ($state) {
					$this->clearAutoHandoverState($extension, 'candidate_changed');
				}
				$state = array_merge($candidateTuple, [
					'phase' => 'tracking',
					'confirmations' => 1,
					'churn_events' => 0,
					'live_signature' => $liveSignature,
					'first_seen_at' => $now,
					'updated_at' => $now,
				]);
				$this->setAutoHandoverState($extension, $state);
				$this->logInfo('Registration Watch auto handover candidate first seen for extension ' . $extension . ': old_key=' . $oldKey . ', new_key=' . $newKey . ', old_ip=' . ($oldIp !== '' ? $oldIp : '-') . ', new_ip=' . ($newIp !== '' ? $newIp : '-'));
				continue;
			}

			$confirmations = max(1, (int)($state['confirmations'] ?? 1));
			$churn = max(0, (int)($state['churn_events'] ?? 0));
			if (($state['phase'] ?? '') === 'pre_candidate') {
				$churn = max(1, $churn);
				$confirmations = 1;
				$state['phase'] = 'tracking';
				$state['live_signature'] = $liveSignature;
			} elseif ((string)($state['live_signature'] ?? '') !== $liveSignature) {
				$confirmations = 1;
				$churn++;
				$state['live_signature'] = $liveSignature;
				$this->logInfo('Registration Watch auto handover candidate reset for extension ' . $extension . ': topology_changed');
			} else {
				$confirmations++;
			}

			$threshold = $churn > 0 ? self::AUTO_HANDOVER_CONFIRM_POLLS_CHURN : self::AUTO_HANDOVER_CONFIRM_POLLS_DEFAULT;
			$state['confirmations'] = $confirmations;
			$state['churn_events'] = $churn;
			$state['updated_at'] = $now;
			$this->setAutoHandoverState($extension, $state);
			$this->logInfo('Registration Watch auto handover confirmation for extension ' . $extension . ': ' . $confirmations . '/' . $threshold);
			if ($confirmations < $threshold) {
				continue;
			}

			$db = $this->db();
			$db->beginTransaction();
			try {
				$deleteDuplicate = $db->prepare(
					'DELETE FROM registrationwatch_registrations
					WHERE id = :id
						AND extension = :extension
						AND registration_key = :registration_key'
				);
				$deleteDuplicate->execute([
					':id' => (int)$duplicateRow['id'],
					':extension' => $extension,
					':registration_key' => $newKey,
				]);
				if ($deleteDuplicate->rowCount() !== 1) {
					throw new \RuntimeException('automatic handover duplicate delete precondition failed');
				}

				$newStatus = $this->normaliseState($replacement['status'] ?? self::STATUS_UNKNOWN);
				$contactUri = (string)($replacement['contact_uri'] ?? '');
				$latency = isset($replacement['latency_ms']) && $replacement['latency_ms'] !== null && $replacement['latency_ms'] !== ''
					? (float)$replacement['latency_ms']
					: null;
				$lastSeenAt = $contactUri !== '' ? $now : ($oldRow['last_seen_at'] ?: null);

				$updatePrimary = $db->prepare(
					'UPDATE registrationwatch_registrations
					SET registration_key = :registration_key,
						discovered = 1,
						auto_disabled_absent_at = NULL,
						last_known_status = :last_known_status,
						contact_uri = :contact_uri,
						latency_ms = :latency_ms,
						source_ip = :source_ip,
						source_port = :source_port,
						registration_ua_class = :registration_ua_class,
						transport = :transport,
						user_agent = :user_agent,
						device_name = :device_name,
						firmware_version = :firmware_version,
						contact_count = :contact_count,
						contact_expires_at = :contact_expires_at,
						qualify_frequency = :qualify_frequency,
						last_seen_at = :last_seen_at,
						last_checked_at = :last_checked_at,
						last_discovered_at = :last_discovered_at,
						updated_at = :updated_at
					WHERE id = :id'
				);
				$updatePrimary->execute([
					':registration_key' => $newKey,
					':last_known_status' => $newStatus,
					':contact_uri' => $contactUri !== '' ? $contactUri : null,
					':latency_ms' => $latency,
					':source_ip' => $newIp !== '' ? $newIp : null,
					':source_port' => $replacement['source_port'] ?? null,
					':registration_ua_class' => $replacement['registration_ua_class'] ?? ($oldRow['registration_ua_class'] ?? ''),
					':transport' => $replacement['transport'] ?? ($oldRow['transport'] ?? null),
					':user_agent' => $replacement['user_agent'] ?? ($oldRow['user_agent'] ?? null),
					':device_name' => $replacement['device_name'] ?? ($oldRow['device_name'] ?? null),
					':firmware_version' => $replacement['firmware_version'] ?? ($oldRow['firmware_version'] ?? null),
					':contact_count' => max(1, (int)($replacement['contact_count'] ?? ($oldRow['contact_count'] ?? 1))),
					':contact_expires_at' => $replacement['contact_expires_at'] ?? ($oldRow['contact_expires_at'] ?? null),
					':qualify_frequency' => $replacement['qualify_frequency'] ?? ($oldRow['qualify_frequency'] ?? null),
					':last_seen_at' => $lastSeenAt,
					':last_checked_at' => $now,
					':last_discovered_at' => $now,
					':updated_at' => $now,
					':id' => $oldId,
				]);

				$updateEscalation = $db->prepare(
					'UPDATE registrationwatch_alert_escalation
					SET registration_key = :registration_key,
						extension = :extension,
						updated_at = :updated_at
					WHERE registration_id = :registration_id'
				);
				$updateEscalation->execute([
					':registration_key' => $newKey,
					':extension' => $extension,
					':updated_at' => $now,
					':registration_id' => $oldId,
				]);

				$this->insertStatusHistory(
					$oldId,
					$newKey,
					(string)$oldRow['extension'],
					$oldStatus,
					$newStatus,
					'ip_address_change',
					$contactUri !== '' ? $contactUri : null,
					$latency,
					$now
				);

				$db->commit();
				$this->setAutoHandoverState($extension, [
					'phase' => 'validation',
					'old_key' => $oldKey,
					'new_key' => $newKey,
					'validation_observations' => 0,
					'updated_at' => $now,
				]);
				$this->logInfo('Registration Watch auto handover committed for extension ' . $extension . ': old_ip=' . ($oldIp !== '' ? $oldIp : '-') . ', new_ip=' . ($newIp !== '' ? $newIp : '-') . ', old_key=' . $oldKey . ', new_key=' . $newKey);
			} catch (\Throwable $e) {
				if ($db->inTransaction()) {
					$db->rollBack();
				}
				$this->logWarning('Registration Watch auto handover skipped for extension ' . $extension . ': ' . $e->getMessage());
			}
		}
	}

	private function disableNonDeviceRegistration(int $registrationId, string $now): void {
		$this->deleteEscalationsForRegistration($registrationId);
		$stmt = $this->db()->prepare(
			'UPDATE registrationwatch_registrations
			SET enabled = 0,
				discovered = 0,
				updated_at = :updated_at
			WHERE id = :id
				AND (enabled <> 0 OR discovered <> 0)'
		);
		$stmt->execute([
			':updated_at' => $now,
			':id' => $registrationId,
		]);
		if ($stmt->rowCount() > 0) {
			$this->logInfo('Ignored stored registration because it is not a configured PJSIP device: id ' . $registrationId);
		}
	}

	private function acquireReconcileLock(): bool {
		try {
			$stmt = $this->db()->query("SELECT GET_LOCK('registrationwatch_reconcile', 0)");
			return $stmt ? (int)$stmt->fetchColumn() === 1 : false;
		} catch (\Throwable $e) {
			$this->logWarning('Registration Watch reconcile lock unavailable: ' . $e->getMessage());
			return false;
		}
	}

	private function releaseReconcileLock(): void {
		try {
			$this->db()->query("SELECT RELEASE_LOCK('registrationwatch_reconcile')");
		} catch (\Throwable $e) {
			$this->logWarning('Registration Watch reconcile lock release failed: ' . $e->getMessage());
		}
	}

	private function autoDisableAbsentSeconds(array $settings): int {
		$value = isset($settings['auto_disable_absent_seconds'])
			? trim((string)$settings['auto_disable_absent_seconds'])
			: (string)self::AUTO_DISABLE_ABSENT_DEFAULT_SECONDS;
		if ($value === '' || !ctype_digit($value)) {
			return self::AUTO_DISABLE_ABSENT_DEFAULT_SECONDS;
		}

		return max(0, (int)$value);
	}

	private function shouldAutoDisableAbsentRegistration(array $registration, int $thresholdSeconds, string $now): bool {
		if ($thresholdSeconds <= 0 || (int)($registration['enabled'] ?? 0) !== 1) {
			return false;
		}
		if (!empty($registration['auto_disabled_absent_at'])) {
			return false;
		}

		$lastSeen = trim((string)($registration['last_seen_at'] ?? ''));
		if ($lastSeen === '') {
			return false;
		}

		$lastSeenTs = strtotime($lastSeen);
		$nowTs = strtotime($now);
		if ($lastSeenTs === false || $nowTs === false) {
			return false;
		}

		return ($nowTs - $lastSeenTs) >= $thresholdSeconds;
	}

	private function getLiveContacts(?array $allowedDevices = null): array {
		$output = $this->runAsteriskCommand('pjsip show contacts');
		if (trim($output) === '') {
			throw new \Exception(_('Registration Watch could not query Asterisk. Confirm the FreePBX AMI user has Command privilege.'));
		}

		$contacts = [];
		$pending = [];
		$allowedDevices = $allowedDevices === null ? $this->getAllowedPjsipDeviceIds() : $allowedDevices;
		if ($this->shouldDeferForEmptyAllowlist($allowedDevices)) {
			throw new \Exception(_('Registration Watch PJSIP device allowlist is unavailable; deferring status reconciliation.'));
		}
		$registrarDetails = $this->getRegistrarContactDetails();
		$existingIdentityClasses = $this->getStoredRegistrationIdentityClasses();
		$lineCount = 0;
		$parsedCount = 0;
		$acceptedCount = 0;
		$ignoredNonDeviceCount = 0;
		$failureCount = 0;
		$firstFailedLine = null;

		foreach (preg_split('/\r\n|\r|\n/', $output) as $line) {
			if (trim($line) === '') {
				continue;
			}

			$lineCount++;
			$parsed = $this->parseContactLine($line);
			if ($parsed === null) {
				// Track first failed parse for diagnostic logging
				if (strpos($line, 'Contact:') !== false) {
					$failureCount++;
					if ($firstFailedLine === null) {
						$firstFailedLine = substr($line, 0, 100);
					}
				}
				continue;
			}

			$parsedCount++;
			if (!isset($allowedDevices[$parsed['extension']])) {
				$ignoredNonDeviceCount++;
				continue;
			}

			$parsed = $this->enrichLiveContactFromRegistrar($parsed, $registrarDetails);
			if ($this->normaliseSourceIp($parsed['source_ip'] ?? '') === '') {
				$this->logWarning('PJSIP contact skipped because Registration Watch could not resolve a source IP: ' . substr($line, 0, 100));
				continue;
			}
			$identityGroup = $this->registrationIdentityGroupKey($parsed['extension'], $parsed['source_ip']);
			$pending[$identityGroup][] = $parsed;
			$acceptedCount++;
		}

		foreach ($pending as $identityGroup => $items) {
			foreach ($this->resolveLiveContactIdentityGroup($items, $existingIdentityClasses[$identityGroup] ?? []) as $parsed) {
				$key = $parsed['registration_key'];
				$existing = $contacts[$key] ?? null;
				if ($existing === null) {
					$contacts[$key] = $parsed;
					continue;
				}

				$parsed['contact_count'] = ((int)($existing['contact_count'] ?? 1)) + 1;
				$contacts[$key] = $this->preferredLiveContact($existing, $parsed);
			}
		}

		// Log diagnostics only if there were parse failures (avoid log spam on success)
		if ($lineCount > 0 && $failureCount > 0) {
			$this->logWarning('PJSIP contact parsing: ' . $parsedCount . ' parsed, ' . $failureCount . ' failed. Example: ' . $firstFailedLine);
		}
		$this->logInfo(sprintf(
			'PJSIP live contacts seen: %d, accepted: %d, ignored as non-device: %d.',
			$parsedCount,
			$acceptedCount,
			$ignoredNonDeviceCount
		));

		return $contacts;
	}

	private function resolveLiveContactIdentityGroup(array $items, array $existingState): array {
		$usableClasses = [];
		foreach ($items as $item) {
			$uaClass = $this->normaliseUserAgentClass($item['user_agent'] ?? null);
			if ($uaClass !== '') {
				$usableClasses[$uaClass] = true;
			}
		}

		ksort($usableClasses, SORT_STRING);
		$splitClasses = [];
		$existingClasses = $existingState['classes'] ?? [];
		$existingShared = $existingState['shared'] ?? [];
		$existingNonShared = array_values(array_filter(array_map('strval', $existingClasses), function ($uaClass) {
			return $uaClass !== '';
		}));
		if (count($usableClasses) > 1) {
			$splitClasses = array_fill_keys(array_keys($usableClasses), true);
		} elseif (count($usableClasses) === 1 && $existingNonShared) {
			$splitClasses = array_fill_keys(array_unique(array_merge(array_keys($usableClasses), $existingNonShared)), true);
		}

		$sharedAnchorIndex = null;
		if ($splitClasses && $existingShared) {
			$sharedAnchorIndex = $this->sharedRegistrationAnchorIndex($items, $existingShared);
		}

		foreach ($items as $index => $item) {
			$uaClass = $this->normaliseUserAgentClass($item['user_agent'] ?? null);
			$resolvedClass = '';
			if ($sharedAnchorIndex !== $index && $uaClass !== '' && isset($splitClasses[$uaClass])) {
				$resolvedClass = $uaClass;
			}
			$items[$index]['registration_ua_class'] = $resolvedClass;
			$items[$index]['registration_key'] = $this->registrationKey($item['extension'], $item['source_ip'], $resolvedClass);
		}

		return $items;
	}

	private function sharedRegistrationAnchorIndex(array $items, array $existingShared): ?int {
		foreach ($existingShared as $existing) {
			foreach ($items as $index => $item) {
				if (!empty($existing['contact_uri']) && (string)$existing['contact_uri'] === (string)($item['contact_uri'] ?? '')) {
					return $index;
				}
			}
		}

		foreach ($existingShared as $existing) {
			$existingUaClass = $this->normaliseUserAgentClass($existing['user_agent'] ?? null);
			if ($existingUaClass === '') {
				continue;
			}
			foreach ($items as $index => $item) {
				if ($existingUaClass === $this->normaliseUserAgentClass($item['user_agent'] ?? null)) {
					return $index;
				}
			}
		}

		$ranked = [];
		foreach ($items as $index => $item) {
			$ranked[] = [
				'index' => $index,
				'ua' => $this->normaliseUserAgentClass($item['user_agent'] ?? null),
				'contact_uri' => (string)($item['contact_uri'] ?? ''),
			];
		}
		usort($ranked, function ($a, $b) {
			$uaCompare = strcmp($a['ua'], $b['ua']);
			if ($uaCompare !== 0) {
				return $uaCompare;
			}
			return strcmp($a['contact_uri'], $b['contact_uri']);
		});

		return isset($ranked[0]) ? (int)$ranked[0]['index'] : null;
	}

	private function enrichLiveContactFromRegistrar(array $contact, array $registrarDetails): array {
		$exactCandidate = null;
		$fallbackCandidates = [];
		$extension = (string)($contact['extension'] ?? '');

		foreach ($registrarDetails as $detail) {
			if (($detail['extension'] ?? '') !== $extension) {
				continue;
			}
			if (!empty($detail['contact_uri']) && $this->contactUrisMatchForEnrichment($detail['contact_uri'], $contact['contact_uri'] ?? null)) {
				$exactCandidate = $detail;
				break;
			}
			if (!empty($detail['source_ip']) && $this->normaliseSourceIp($detail['source_ip']) === (string)($contact['source_ip'] ?? '')) {
				$fallbackCandidates[] = $detail;
				continue;
			}
			if (!empty($detail['contact_uri']) && $this->contactUriHostMatchesForEnrichment($detail['contact_uri'], $contact['contact_uri'] ?? null)) {
				$fallbackCandidates[] = $detail;
			}
		}

		if (is_array($exactCandidate)) {
			$detail = $exactCandidate;
			if (!empty($detail['contact_uri'])) {
				$contact['contact_uri'] = (string)$detail['contact_uri'];
			}
			if (!empty($detail['source_ip'])) {
				$contact['source_ip'] = $this->normaliseSourceIp($detail['source_ip']);
			}
			foreach (['user_agent', 'device_name', 'firmware_version', 'contact_expires_at', 'qualify_frequency'] as $field) {
				if (($contact[$field] ?? null) === null && ($detail[$field] ?? null) !== null && $detail[$field] !== '') {
					$contact[$field] = $detail[$field];
				}
			}
			$contact = $this->applyRegistrarPortDetails($contact, $detail);
			return $contact;
		}

		if (count($fallbackCandidates) === 1) {
			$detail = $fallbackCandidates[0];
			if ($this->shouldPromoteRegistrarContactUri(
				$contact['contact_uri'] ?? null,
				$detail['contact_uri'] ?? null,
				$contact['source_ip'] ?? null
			)) {
				$contact['contact_uri'] = (string)$detail['contact_uri'];
			}
			$contact = $this->applyRegistrarPortDetails($contact, $detail);
			foreach (['contact_expires_at', 'qualify_frequency'] as $field) {
				if (($contact[$field] ?? null) === null && ($detail[$field] ?? null) !== null && $detail[$field] !== '') {
					$contact[$field] = $detail[$field];
				}
			}
		}

		return $contact;
	}

	private function contactUriHostMatchesForEnrichment($leftContactUri, $rightContactUri): bool {
		$leftAddress = $this->parseContactUriAddress(isset($leftContactUri) ? (string)$leftContactUri : null);
		$rightAddress = $this->parseContactUriAddress(isset($rightContactUri) ? (string)$rightContactUri : null);
		$leftHost = $this->normaliseSourceIp($leftAddress['host'] ?? '');
		$rightHost = $this->normaliseSourceIp($rightAddress['host'] ?? '');

		return $leftHost !== '' && $leftHost === $rightHost;
	}

	private function normalisePortNumber($value): ?int {
		if ($value === null || $value === '' || !is_numeric($value)) {
			return null;
		}

		$port = (int)$value;
		return ($port > 0 && $port <= 65535) ? $port : null;
	}

	private function applyRegistrarPortDetails(array $contact, array $detail): array {
		$detailSourcePort = $this->normalisePortNumber($detail['source_port'] ?? null);
		$detailUriAddress = $this->parseContactUriAddress(isset($detail['contact_uri']) ? (string)$detail['contact_uri'] : null);
		$detailUriPort = $this->normalisePortNumber($detailUriAddress['port'] ?? null);

		$resolvedPort = $detailSourcePort;
		if ($resolvedPort === null) {
			$resolvedPort = $detailUriPort;
		} elseif ($detailUriPort !== null && $detailUriPort !== $resolvedPort) {
			$sourceText = (string)$resolvedPort;
			$uriText = (string)$detailUriPort;
			if (strlen($uriText) > strlen($sourceText) && strpos($uriText, $sourceText) === 0) {
				$resolvedPort = $detailUriPort;
			}
		}

		if ($resolvedPort !== null) {
			$contact['source_port'] = $resolvedPort;
		}

		return $contact;
	}

	private function shouldPromoteRegistrarContactUri($parsedContactUri, $registrarContactUri, $parsedSourceIp): bool {
		$parsedContactUri = trim((string)$parsedContactUri);
		$registrarContactUri = trim((string)$registrarContactUri);
		if ($parsedContactUri === '' || $registrarContactUri === '') {
			return false;
		}

		$parsedAddress = $this->parseContactUriAddress($parsedContactUri);
		$registrarAddress = $this->parseContactUriAddress($registrarContactUri);
		$parsedHost = $this->normaliseSourceIp($parsedAddress['host'] ?? '');
		$registrarHost = $this->normaliseSourceIp($registrarAddress['host'] ?? '');
		if ($parsedHost === '' || $registrarHost === '' || $parsedHost !== $registrarHost) {
			return false;
		}

		$parsedPort = $this->normalisePortNumber($parsedAddress['port'] ?? null);
		$registrarPort = $this->normalisePortNumber($registrarAddress['port'] ?? null);
		if ($parsedPort === null || $registrarPort === null || $parsedPort === $registrarPort) {
			return false;
		}

		$parsedIp = $this->normaliseSourceIp($parsedSourceIp);
		if ($parsedIp === '' || $parsedIp !== $parsedHost) {
			return false;
		}

		$parsedText = (string)$parsedPort;
		$registrarText = (string)$registrarPort;
		return strlen($registrarText) > strlen($parsedText) && strpos($registrarText, $parsedText) === 0;
	}

	private function contactUrisMatchForEnrichment($left, $right): bool {
		$left = trim((string)$left);
		$right = trim((string)$right);
		if ($left === '' || $right === '') {
			return false;
		}
		if ($left === $right) {
			return true;
		}

		$normalisedLeft = $this->normaliseContactUriForEnrichment($left);
		$normalisedRight = $this->normaliseContactUriForEnrichment($right);

		return $normalisedLeft !== '' && $normalisedLeft === $normalisedRight;
	}

	private function normaliseContactUriForEnrichment(string $contactUri): string {
		$contactUri = trim($contactUri, " \t\n\r\0\x0B<>");
		if ($contactUri === '') {
			return '';
		}

		$contactUri = preg_split('/[;?&#>\s]/', $contactUri, 2)[0] ?? '';
		$contactUri = trim($contactUri);
		if (stripos($contactUri, 'sip:') === 0) {
			$contactUri = substr($contactUri, 4);
		} elseif (stripos($contactUri, 'sips:') === 0) {
			$contactUri = substr($contactUri, 5);
		}

		return strtolower($contactUri);
	}

	private function getStoredRegistrationIdentityClasses(): array {
		if (!$this->tableExists('registrationwatch_registrations')) {
			return [];
		}

		try {
			$stmt = $this->db()->query(
				"SELECT extension, source_ip, registration_ua_class, contact_uri, user_agent
				FROM registrationwatch_registrations
				WHERE source_ip IS NOT NULL AND source_ip <> ''"
			);
		} catch (\Throwable $e) {
			return [];
		}

		$groups = [];
		foreach (($stmt ? $stmt->fetchAll(\PDO::FETCH_ASSOC) : []) as $row) {
			$sourceIp = $this->normaliseSourceIp($row['source_ip'] ?? '');
			$extension = $this->normaliseRegistrationExtension((string)($row['extension'] ?? ''));
			if ($extension === '' || $sourceIp === '') {
				continue;
			}
			$key = $this->registrationIdentityGroupKey($extension, $sourceIp);
			$uaClass = (string)($row['registration_ua_class'] ?? '');
			$groups[$key]['classes'][] = $uaClass;
			if ($uaClass === '') {
				$groups[$key]['shared'][] = [
					'contact_uri' => $row['contact_uri'] ?? null,
					'user_agent' => $row['user_agent'] ?? null,
				];
			}
		}

		return $groups;
	}

	/**
	 * Phase 2 intentionally parses the human-readable PJSIP contact listing
	 * because it is widely available through FreePBX/Asterisk manager command
	 * support. Future work should prefer structured AMI/PJSIP data where that
	 * is practical; keep this parser treated as technical debt.
	 */
	private function parseContactLine(string $line): ?array {
		if (!preg_match('/^\s*Contact:\s+(\S+)\s+(.+)$/', $line, $matches)) {
			return null;
		}

		$target = $matches[1];
		if (strpos($target, '/') === false) {
			return null;
		}

		[$extension, $contactUri] = explode('/', $target, 2);
		$extension = $this->normaliseRegistrationExtension($extension);
		$contactUri = trim($contactUri);
		if ($extension === '') {
			return null;
		}

		$tail = preg_split('/\s+/', trim($matches[2]));
		$rawStatus = '';
		$latency = null;

		foreach ($tail as $token) {
			if ($this->isAsteriskStatus($token)) {
				$rawStatus = $token;
			} elseif (is_numeric($token)) {
				$latency = (float)$token;
			}
		}

		$contactAddress = $this->parseContactUriAddress($contactUri);
		$contactHost = $contactAddress['host'];
		$sourceIp = $this->normaliseSourceIp($contactHost);

		return [
			'registration_key' => '',
			'registration_ua_class' => '',
			'extension' => $extension,
			'contact_uri' => $contactUri,
			'status' => $this->mapAsteriskStatus($rawStatus),
			'latency_ms' => $latency,
			'source_ip' => $sourceIp,
			'parsed_contact_host' => $contactHost,
			'source_port' => $contactAddress['port'],
			'contact_count' => 1,
			'transport' => null,  // Not available from "pjsip show contacts"; requires future AMI/log ingestion
			'user_agent' => null, // Enriched from registrar/contact where available.
			'device_name' => null,
			'firmware_version' => null,
			'contact_expires_at' => null,
			'qualify_frequency' => null,
		];
	}

	private function normaliseRegistrationExtension(string $extension): string {
		return strtolower(trim($extension));
	}

	private function normaliseSourceIp($sourceIp): string {
		$sourceIp = trim((string)$sourceIp, " \t\n\r\0\x0B[]");
		if ($sourceIp === '' || !filter_var($sourceIp, FILTER_VALIDATE_IP)) {
			return '';
		}

		$packed = @inet_pton($sourceIp);
		if ($packed === false) {
			return strtolower($sourceIp);
		}

		$normalised = @inet_ntop($packed);
		return $normalised === false ? strtolower($sourceIp) : strtolower($normalised);
	}

	private function registrationKey(string $extension, string $sourceIp, string $uaClass = ''): string {
		$basis = $this->normaliseRegistrationExtension($extension) . "\0" . $this->normaliseSourceIp($sourceIp);
		$uaClass = $this->normaliseUserAgentClass($uaClass);
		if ($uaClass !== '') {
			$basis .= "\0" . $uaClass;
		}

		return hash('sha256', $basis);
	}

	private function noContactRegistrationKey(string $extension): string {
		return hash('sha256', $this->normaliseRegistrationExtension($extension) . "\0no-contact");
	}

	private function registrationIdentityGroupKey(string $extension, string $sourceIp): string {
		return $this->normaliseRegistrationExtension($extension) . "\0" . $this->normaliseSourceIp($sourceIp);
	}

	private function normaliseUserAgentClass($userAgent): string {
		$userAgent = strtolower(trim((string)$userAgent));
		if ($userAgent === '') {
			return '';
		}

		$userAgent = preg_replace('/\s+/', ' ', $userAgent);
		return $userAgent === null ? '' : $userAgent;
	}

	private function preferredLiveContact(array $existing, array $candidate): array {
		$existingRank = $this->statusRank((string)($existing['status'] ?? ''));
		$candidateRank = $this->statusRank((string)($candidate['status'] ?? ''));
		if ($candidateRank > $existingRank) {
			return $candidate;
		}
		if ($candidateRank < $existingRank) {
			$existing['contact_count'] = $candidate['contact_count'] ?? $existing['contact_count'] ?? 1;
			return $existing;
		}

		$existingUri = (string)($existing['contact_uri'] ?? '');
		$candidateUri = (string)($candidate['contact_uri'] ?? '');
		if (strcmp($candidateUri, $existingUri) >= 0) {
			return $candidate;
		}

		$existing['contact_count'] = $candidate['contact_count'] ?? $existing['contact_count'] ?? 1;
		return $existing;
	}

	private function parseContactUriAddress(?string $contactUri): array {
		$result = ['host' => null, 'port' => null];
		$contactUri = trim((string)$contactUri);
		if ($contactUri === '') {
			return $result;
		}
		if (preg_match('/\s/', $contactUri)) {
			return $result;
		}

		$contactUri = trim($contactUri, '<>');
		$atPosition = strrpos($contactUri, '@');
		$hostPort = $atPosition === false ? $contactUri : substr($contactUri, $atPosition + 1);
		$hostPort = preg_split('/[;?\#>\s]/', $hostPort, 2)[0] ?? '';
		$hostPort = trim($hostPort);
		if ($hostPort === '') {
			return $result;
		}

		if (strpos($hostPort, ':') !== false && stripos($hostPort, 'sip:') === 0) {
			$hostPort = substr($hostPort, strpos($hostPort, ':') + 1);
		}

		$host = null;
		$port = null;
		if (preg_match('/^\[([^\]]+)\](?::([0-9]+))?$/', $hostPort, $matches)) {
			$host = trim($matches[1]);
			$port = $matches[2] ?? null;
		} elseif (substr_count($hostPort, ':') === 1 && preg_match('/^([^:]+):([0-9]+)$/', $hostPort, $matches)) {
			$host = trim($matches[1]);
			$port = $matches[2];
		} elseif (substr_count($hostPort, ':') === 0) {
			$host = $hostPort;
		} else {
			$host = $hostPort;
		}

		$host = trim((string)$host, " \t\n\r\0\x0B[]");
		if ($host === '') {
			return $result;
		}
		if (!filter_var($host, FILTER_VALIDATE_IP) && !preg_match('/^[A-Za-z0-9.-]+$/', $host)) {
			return $result;
		}

		$result['host'] = $host;
		if ($port !== null && ctype_digit((string)$port)) {
			$portNumber = (int)$port;
			if ($portNumber > 0 && $portNumber <= 65535) {
				$result['port'] = $portNumber;
			}
		}

		return $result;
	}

	private function parseContactUriOriginalHostAddress(?string $contactUri): array {
		$result = ['host' => null, 'port' => null];
		$contactUri = trim((string)$contactUri);
		if ($contactUri === '' || preg_match('/\s/', $contactUri)) {
			return $result;
		}

		if (!preg_match('/[;?&]x-ast-orig-host=([^;?&#>\s]+)/', $contactUri, $matches)) {
			return $result;
		}

		return $this->parseAddressHostPort(rawurldecode($matches[1]));
	}

	private function registrationAddressDetails(?string $contactUri, $sourceIp = null, $sourcePort = null): array {
		$contactAddress = $this->parseContactUriAddress($contactUri);
		$originalAddress = $this->parseContactUriOriginalHostAddress($contactUri);
		$hasOriginalAddress = $originalAddress['host'] !== null || $originalAddress['port'] !== null;

		$deviceAddress = $hasOriginalAddress ? $originalAddress : $contactAddress;
		$networkAddress = $hasOriginalAddress ? $contactAddress : ['host' => null, 'port' => null];

		if ($networkAddress['host'] === null && trim((string)$sourceIp) !== '') {
			$networkAddress['host'] = $sourceIp;
		}
		if ($networkAddress['port'] === null && trim((string)$sourcePort) !== '') {
			$networkAddress['port'] = $sourcePort;
		}

		return [
			'device_ip' => $deviceAddress['host'],
			'device_port' => $deviceAddress['port'],
			'network_ip' => $networkAddress['host'],
			'network_port' => $networkAddress['port'],
		];
	}

	private function parseAddressHostPort(string $hostPort): array {
		$result = ['host' => null, 'port' => null];
		$hostPort = trim($hostPort, " \t\n\r\0\x0B<>");
		if ($hostPort === '') {
			return $result;
		}

		$host = null;
		$port = null;
		if (preg_match('/^\[([^\]]+)\](?::([0-9]+))?$/', $hostPort, $matches)) {
			$host = trim($matches[1]);
			$port = $matches[2] ?? null;
		} elseif (substr_count($hostPort, ':') === 1 && preg_match('/^([^:]+):([0-9]+)$/', $hostPort, $matches)) {
			$host = trim($matches[1]);
			$port = $matches[2];
		} elseif (substr_count($hostPort, ':') === 0) {
			$host = $hostPort;
		} else {
			$host = $hostPort;
		}

		$host = trim((string)$host, " \t\n\r\0\x0B[]");
		if ($host === '') {
			return $result;
		}
		if (!filter_var($host, FILTER_VALIDATE_IP) && !preg_match('/^[A-Za-z0-9.-]+$/', $host)) {
			return $result;
		}

		$result['host'] = $host;
		if ($port !== null && ctype_digit((string)$port)) {
			$portNumber = (int)$port;
			if ($portNumber > 0 && $portNumber <= 65535) {
				$result['port'] = $portNumber;
			}
		}

		return $result;
	}

	private function isAsteriskStatus(string $value): bool {
		return in_array(strtolower($value), ['avail', 'reachable', 'unavail', 'unavailable', 'unreachable', 'unknown', 'removed', 'nonqual'], true);
	}

	private function mapAsteriskStatus(string $value): string {
		switch (strtolower($value)) {
			case 'avail':
			case 'reachable':
				return self::STATUS_REACHABLE;
			case 'unavail':
			case 'unavailable':
			case 'unreachable':
				return self::STATUS_UNREACHABLE;
			case 'removed':
				return self::STATUS_NOT_REGISTERED;
			case 'nonqual':
				return self::STATUS_REGISTERED_NO_QUALIFY;
			case 'unknown':
			default:
				return self::STATUS_UNKNOWN;
		}
	}

	private function statusRank(string $status): int {
		$status = $this->normaliseState($status);

		switch ($status) {
			case self::STATUS_REACHABLE:
				return 5;
			case self::STATUS_UNREACHABLE:
				return 4;
			case self::STATUS_REGISTERED_NO_QUALIFY:
				return 3;
			case self::STATUS_UNKNOWN:
				return 2;
			case self::STATUS_NOT_REGISTERED:
				return 1;
			default:
				return 0;
		}
	}

	private function hadRegisteredState(string $status): bool {
		return in_array($this->normaliseState($status), [
			self::STATUS_REACHABLE,
			self::STATUS_UNREACHABLE,
			self::STATUS_REGISTERED_NO_QUALIFY,
		], true);
	}

	private function historyReason(bool $previousHadContact, string $newStatus): string {
		if ($this->normaliseState($newStatus) === self::STATUS_NOT_REGISTERED && $previousHadContact) {
			return 'removed';
		}

		return 'status_change';
	}

	private function classifyNetworkGroup(?string $sourceIp): string {
		if ($sourceIp === null || $sourceIp === '') {
			return 'Unknown';
		}

		// Check against configured VPN networks
		$vpnNetworks = $this->getTrustedVpnNetworks();
		foreach ($vpnNetworks as $cidr) {
			if ($this->ipInCidr($sourceIp, $cidr)) {
				return "VPN: $cidr";
			}
		}

		// Classify as private/local vs public/WAN
		if ($this->isPrivateIp($sourceIp)) {
			return 'Local LAN';
		}

		return 'WAN';
	}

	private function getTrustedVpnNetworks(): array {
		$settings = $this->getAlertSettings();
		$vpnConfigRaw = $settings['trusted_vpn_networks'] ?? '';
		if ($vpnConfigRaw === '') {
			return [];
		}

		$networks = [];
		foreach (preg_split('/\r\n|\r|\n/', $vpnConfigRaw) as $line) {
			$cidr = trim($line);
			if ($cidr !== '') {
				$networks[] = $cidr;
			}
		}

		return $networks;
	}

	private function ipInCidr(string $ip, string $cidr): bool {
		// Parse CIDR notation (e.g., "10.8.0.0/24")
		if (strpos($cidr, '/') === false) {
			// Invalid CIDR; treat as single IP comparison
			return $ip === $cidr;
		}

		[$network, $bits] = explode('/', $cidr, 2);
		$bits = (int)$bits;

		// Handle IPv4
		if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($network, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
			$ip = ip2long($ip);
			$network = ip2long($network);
			$mask = -1 << (32 - $bits);
			$network &= $mask;
			return ($ip & $mask) === $network;
		}

		// Handle IPv6 - simplified comparison
		if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && filter_var($network, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
			// For IPv6, do a string prefix match on the network portion
			// This is a simplified check; full IPv6 CIDR support would require inet_pton
			$networkBytes = (int)($bits / 4);
			return strncmp($ip, $network, $networkBytes) === 0;
		}

		return false;
	}

	private function isPrivateIp(string $ip): bool {
		return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false
			&& filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
	}

	public function getTopologyGroups(): array {
		$registrations = $this->getStoredRegistrations();
		$groups = [
			'VPN' => [],
			'WAN' => [],
			'Local LAN' => [],
			'Unknown' => [],
		];

		foreach ($registrations as $registration) {
			if ((int)$registration['discovered'] === 0) {
				continue;
			}

			$sourceIp = $registration['source_ip'] ?? null;
			$group = $this->classifyNetworkGroup($sourceIp);

			// Check if group is a VPN network group
			if (strpos($group, 'VPN:') === 0) {
				if (!isset($groups[$group])) {
					$groups[$group] = [];
				}
				$groups[$group][] = $registration;
			} else {
				$groups[$group][] = $registration;
			}
		}

		// Remove empty groups
		$groups = array_filter($groups, function ($items) {
			return count($items) > 0;
		});

		return $groups;
	}

	private function insertStatusHistory(int $registrationId, string $registrationKey, string $extension, ?string $fromState, string $toState, string $reason, ?string $contactUri, ?float $latency, string $createdAt): int {
		$stmt = $this->db()->prepare(
			'INSERT INTO registrationwatch_status_history
				(registration_id, registration_key, extension, from_state, to_state, source, reason, contact_uri, latency_ms, created_at)
			VALUES
				(:registration_id, :registration_key, :extension, :from_state, :to_state, :source, :reason, :contact_uri, :latency_ms, :created_at)'
		);
		$stmt->execute([
			':registration_id' => $registrationId,
			':registration_key' => $registrationKey,
			':extension' => $extension,
			':from_state' => $fromState !== '' ? $fromState : null,
			':to_state' => $toState,
			':source' => 'reconcile',
			':reason' => $reason,
			':contact_uri' => $contactUri,
			':latency_ms' => $latency,
			':created_at' => $createdAt,
		]);
		return (int)$this->db()->lastInsertId();
	}

	private function processAlertQueue(string $now): void {
		$settings = $this->getAlertSettings();
		$recipients = $this->normaliseRecipients($settings['alert_recipients']);
		$canSend = $settings['alert_enabled'] === '1' && (bool)$recipients;
		$canSendWebhook = false;
		try {
			$canSendWebhook = $this->hasEnabledWebhookDestinations();
		} catch (\Throwable $e) {
			$this->logWarning('Webhook destinations could not be loaded; email notification processing will continue.');
		}
		$collectedAlerts = [];
		$recoveryAuditCandidates = [];
		$reminderCycles = [];

		try {
			$debounceSeconds = min(self::ALERT_TIMING_MAX_SECONDS, max(0, (int)$settings['debounce_seconds']));
			$staleCutoff = date('Y-m-d H:i:s', strtotime($now) - ($debounceSeconds + self::ALERT_STALE_TRANSITION_MAX_SECONDS));
			$candidateStmt = $this->db()->prepare(
				'SELECT DISTINCT h.registration_id
				FROM registrationwatch_status_history h
				JOIN registrationwatch_registrations e
					ON e.id = h.registration_id
				WHERE h.source = :source
					AND h.created_at >= :stale_cutoff
					AND h.created_at <= :now
					AND e.enabled = 1
				ORDER BY h.registration_id ASC'
			);
			$candidateStmt->execute([
				':source' => 'reconcile',
				':stale_cutoff' => $staleCutoff,
				':now' => $now,
			]);
			$registrationIds = array_values(array_unique(array_map('intval', $candidateStmt->fetchAll(\PDO::FETCH_COLUMN))));

			foreach (array_chunk($registrationIds, 100) as $candidateRegistrationIds) {
				$placeholders = [];
				$params = [':source' => 'reconcile'];
				foreach ($candidateRegistrationIds as $index => $registrationId) {
					$key = ':registration_id_' . $index;
					$placeholders[] = $key;
					$params[$key] = $registrationId;
				}

				$historyStmt = $this->db()->prepare(
					'SELECT h.id, h.registration_id, h.registration_key, h.extension, h.from_state, h.to_state, h.source, h.reason,
						h.contact_uri, h.latency_ms, h.created_at, e.repeat_mode
					FROM registrationwatch_status_history h
					JOIN registrationwatch_registrations e
						ON e.id = h.registration_id
					WHERE h.source = :source
						AND h.registration_id IN (' . implode(', ', $placeholders) . ')
						AND (
							h.created_at >= :history_cutoff AND h.created_at <= :now
							OR h.id = (
								SELECT prior.id
								FROM registrationwatch_status_history prior
								WHERE prior.registration_id = h.registration_id
									AND prior.source = :prior_source
									AND prior.created_at < :prior_cutoff
									AND prior.to_state IN (:prior_to_unreachable, :prior_to_not_registered)
									AND prior.from_state IN (:prior_from_reachable, :prior_from_registered_no_qualify)
									AND NOT EXISTS (
										SELECT 1
										FROM registrationwatch_status_history boundary
										WHERE boundary.registration_id = prior.registration_id
											AND boundary.source = :boundary_source
											AND (boundary.created_at > prior.created_at OR (boundary.created_at = prior.created_at AND boundary.id > prior.id))
											AND boundary.created_at < :boundary_cutoff
											AND boundary.from_state IN (:boundary_from_unreachable, :boundary_from_not_registered, :boundary_from_unknown)
											AND boundary.to_state IN (:boundary_to_reachable, :boundary_to_registered_no_qualify)
									)
								ORDER BY prior.created_at DESC, prior.id DESC
								LIMIT 1
							)
						)
						AND e.enabled = 1
					ORDER BY h.registration_id ASC, h.created_at ASC, h.id ASC'
				);
				$params[':history_cutoff'] = $staleCutoff;
				$params[':now'] = $now;
				$params[':prior_source'] = 'reconcile';
				$params[':prior_cutoff'] = $staleCutoff;
				$params[':boundary_cutoff'] = $staleCutoff;
				$params[':prior_to_unreachable'] = self::STATUS_UNREACHABLE;
				$params[':prior_to_not_registered'] = self::STATUS_NOT_REGISTERED;
				$params[':prior_from_reachable'] = self::STATUS_REACHABLE;
				$params[':prior_from_registered_no_qualify'] = self::STATUS_REGISTERED_NO_QUALIFY;
				$params[':boundary_source'] = 'reconcile';
				$params[':boundary_from_unreachable'] = self::STATUS_UNREACHABLE;
				$params[':boundary_from_not_registered'] = self::STATUS_NOT_REGISTERED;
				$params[':boundary_from_unknown'] = self::STATUS_UNKNOWN;
				$params[':boundary_to_reachable'] = self::STATUS_REACHABLE;
				$params[':boundary_to_registered_no_qualify'] = self::STATUS_REGISTERED_NO_QUALIFY;
				$historyStmt->execute($params);

				$transitionsByRegistration = [];
				foreach ($historyStmt->fetchAll(\PDO::FETCH_ASSOC) as $transition) {
					$transitionsByRegistration[(int)$transition['registration_id']][] = $transition;
				}

				foreach ($transitionsByRegistration as $transitions) {
					$incident = null;
					foreach ($transitions as $transition) {
						$from = $this->normaliseState($transition['from_state'] ?? '');
						$to = $this->normaliseState($transition['to_state'] ?? '');
						$fromUnhealthy = $this->isUnhealthyState($from);
						$toUnhealthy = $this->isUnhealthyState($to);

						if (!$fromUnhealthy && $toUnhealthy && !($from === self::STATUS_UNKNOWN && $incident !== null)) {
							$incident = [
								'start' => $transition,
								'start_is_alertable' => $this->hadRegisteredState($from) && !$fromUnhealthy,
								'problem_transition' => null,
								'problem_transitions' => [],
							];
						} elseif ($fromUnhealthy && $toUnhealthy && $incident === null) {
							$incident = [
								'start' => $transition,
								'start_is_alertable' => false,
								'problem_transition' => null,
								'problem_transitions' => [],
							];
						}

						if ($toUnhealthy && $incident !== null) {
							$alertType = $this->alertTypeForTransition($transition, $settings);
							if ($this->isEscalatingAlertType((string)$alertType)) {
								if (empty($incident['start_is_alertable'])) {
									$incident['start'] = $transition;
									$incident['start_is_alertable'] = true;
									$incident['problem_transitions'] = [];
								}
								$incident['problem_transition'] = $transition;
								$incident['problem_alert_type'] = $alertType;
								$incident['problem_transitions'][] = $transition;
							}
						}

						if ($incident !== null && $this->isRecoveryTransition($transition)) {
							if ($incident !== null) {
								$this->processAlertIncident(
									$incident,
									$transition,
									$debounceSeconds,
									$staleCutoff,
									$now,
									$settings,
									$recipients,
									$canSend,
									$canSendWebhook,
									$collectedAlerts,
									$recoveryAuditCandidates
								);
							}
							if ($this->isRecoveryTransition($transition)) {
								$this->resetEscalationForRecovery($transition);
							}
							$incident = null;
						}
					}

					if ($incident !== null) {
						$this->processAlertIncident(
							$incident,
							null,
							$debounceSeconds,
							$staleCutoff,
							$now,
							$settings,
							$recipients,
							$canSend,
							$canSendWebhook,
							$collectedAlerts,
							$recoveryAuditCandidates
						);
					}
				}
			}

			$due = $this->collectDueReminderAlerts($now, $settings, $recipients, $canSendWebhook);
			$collectedAlerts = array_merge($collectedAlerts, $due['alerts']);
			$reminderCycles = $due['cycles'];

			$this->dispatchCollectedAlerts(
				$collectedAlerts,
				$reminderCycles,
				$settings,
				$recipients,
				$now,
				$due['webhook_reminders']
			);
			$this->recordSuppressedRecoveryAudits($recoveryAuditCandidates, $now);
		} catch (\Exception $e) {
			$this->logError('Alert processing failed: ' . $e->getMessage());
		}
	}

	private function hasEnabledWebhookDestinations(): bool {
		foreach ($this->getWebhookDestinations() as $destination) {
			if (!empty($destination['enabled'])) {
				return true;
			}
		}
		return false;
	}

	private function queueWebhookEvent(
		array $transition,
		string $alertType,
		int $reminderN,
		int $incidentStartHistoryId,
		?callable $afterDestinationRead = null
	): void {
		try {
			$historyId = (int)($transition['id'] ?? 0);
			$registrationId = (int)($transition['registration_id'] ?? 0);
			if ($historyId <= 0 || $registrationId <= 0) {
				return;
			}

			$eventType = $alertType === 'recovery'
				? 'registration.registered'
				: ($alertType === 'not_registered' ? 'registration.unregistered' : 'registration.unreachable');
			$eventId = hash('sha256', 'registrationwatch:' . $historyId . ':' . $alertType . ':' . $reminderN);
			$timestamp = strtotime((string)($transition['created_at'] ?? ''));
			$variables = [
				'event' => $eventType,
				'event_id' => $eventId,
				'extension' => (string)($transition['extension'] ?? ''),
				'technology' => 'PJSIP',
				'previous_status' => $this->stateLabel($transition['from_state'] ?? ''),
				'current_status' => $this->stateLabel($transition['to_state'] ?? ''),
				'timestamp' => $timestamp === false ? gmdate('c') : gmdate('c', $timestamp),
				'source' => 'Registration Watch',
				'system_identifier' => $this->getSystemIdentifier(),
				'alert_type' => $alertType,
			];
			$now = $this->now();
			$snoozed = $this->isMonitoringSnoozed();
			$db = $this->db();
			$destinations = $this->getWebhookDestinations();
			if ($afterDestinationRead !== null) {
				$afterDestinationRead($destinations);
			}
			$queueCount = (int)$db->query('SELECT COUNT(*) FROM registrationwatch_webhook_queue')->fetchColumn();
			if ($queueCount >= 10000) {
				$db->exec("DELETE FROM registrationwatch_webhook_queue
					WHERE status IN ('delivered', 'failed', 'suppressed')
					ORDER BY id ASC LIMIT 1000");
				$queueCount = (int)$db->query('SELECT COUNT(*) FROM registrationwatch_webhook_queue')->fetchColumn();
			}
			$pendingCount = (int)$db->query("SELECT COUNT(*) FROM registrationwatch_webhook_queue WHERE status IN ('pending', 'processing')")->fetchColumn();

			foreach ($destinations as $destination) {
				if (empty($destination['enabled'])) {
					continue;
				}
				if ($alertType === 'recovery') {
					$priorStmt = $db->prepare(
						"SELECT status
						FROM registrationwatch_webhook_queue
						WHERE destination_id = :destination_id
							AND registration_id = :registration_id
							AND history_id >= :incident_start
							AND history_id < :recovery_history
							AND alert_type IN ('unreachable', 'not_registered')
						ORDER BY id ASC"
					);
					$priorStmt->execute([
						':destination_id' => (string)$destination['id'],
						':registration_id' => $registrationId,
						':incident_start' => max(0, $incidentStartHistoryId),
						':recovery_history' => $historyId,
					]);
					$priorEvents = $priorStmt->fetchAll(\PDO::FETCH_COLUMN);
					$problemQueued = false;
					foreach ($priorEvents as $priorStatus) {
						if (in_array((string)$priorStatus, ['pending', 'processing', 'delivered'], true)) {
							$problemQueued = true;
							break;
						}
					}
					if (!$problemQueued) {
						continue;
					}
				}

				$payloadError = null;
				$payload = RegistrationwatchWebhook::renderPayload(
					(string)($destination['payload_template'] ?? ''),
					$variables,
					$payloadError
				);
				if ($payload === null) {
					$this->logWarning('Webhook event was not queued because its configured payload is invalid.');
					continue;
				}
				if ($pendingCount >= 5000 || $queueCount >= 10000) {
					$this->logWarning('Webhook delivery queue is full; a notification event was not queued.');
					continue;
				}
				$json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
				if (!is_string($json)) {
					$this->logWarning('Webhook event payload could not be encoded.');
					continue;
				}
				$stmt = $db->prepare(
					'INSERT IGNORE INTO registrationwatch_webhook_queue
						(destination_id, event_id, registration_id, history_id, incident_start_history_id, destination_fingerprint,
						 alert_type, event_type, payload,
						 status, attempts, next_attempt_at, created_at, updated_at)
					VALUES
						(:destination_id, :event_id, :registration_id, :history_id, :incident_start_history_id, :destination_fingerprint,
						 :alert_type, :event_type, :payload,
						 :status, 0, :next_attempt_at, :created_at, :updated_at)'
				);
				$stmt->execute([
					':destination_id' => (string)$destination['id'],
					':event_id' => $eventId,
					':registration_id' => $registrationId,
					':history_id' => $historyId,
					':incident_start_history_id' => max(0, $incidentStartHistoryId),
					':destination_fingerprint' => $this->webhookDestinationDeliveryFingerprint($destination),
					':alert_type' => $alertType,
					':event_type' => $eventType,
					':payload' => $json,
					':status' => $snoozed ? 'suppressed' : 'pending',
					':next_attempt_at' => $now,
					':created_at' => $now,
					':updated_at' => $now,
				]);
				if ($stmt->rowCount() > 0) {
					$queueCount++;
					if (!$snoozed) {
						$pendingCount++;
					}
				}
			}
		} catch (\Throwable $e) {
			$this->logWarning(
				'Webhook event could not be queued (' . get_class($e) . ', code ' . (string)$e->getCode()
				. '); registration monitoring and email notification processing will continue.'
			);
		}
	}

	private function getWebhookTransitionById(int $historyId): ?array {
		if ($historyId <= 0) {
			return null;
		}
		$stmt = $this->db()->prepare(
			'SELECT id, registration_id, registration_key, extension, from_state, to_state, source, reason,
				contact_uri, latency_ms, created_at
			FROM registrationwatch_status_history
			WHERE id = :id
			LIMIT 1'
		);
		$stmt->execute([':id' => $historyId]);
		$row = $stmt->fetch(\PDO::FETCH_ASSOC);
		return is_array($row) ? $row : null;
	}

	private function processWebhookQueue(
		string $now,
		?callable $resolver = null,
		?callable $transport = null,
		?callable $clock = null,
		?int $batchLimit = null
	): void {
		$clock = $clock ?? static function (): float {
			return hrtime(true) / 1000000000;
		};
		$startedAt = $clock();
		$processed = 0;
		$batchLimit = $batchLimit ?? 1;
		$batchLimit = min(self::WEBHOOK_WORKER_BATCH_LIMIT, max(1, $batchLimit));
		$claimBudgetSeconds = self::WEBHOOK_WORKER_BUDGET_SECONDS
			- self::WEBHOOK_WORKER_DELIVERY_BUDGET_SECONDS;
		while ($processed < $batchLimit
			&& ($clock() - $startedAt) < $claimBudgetSeconds) {
			$claimed = $this->claimWebhookDelivery($now);
			if ($claimed === null) {
				$this->pruneCompletedWebhookDeliveries();
				break;
			}
			if (!$claimed) {
				continue;
			}
			$processed++;
			$completionTime = static function () use ($now, $startedAt, $clock): string {
				$elapsedSeconds = max(0, (int)floor($clock() - $startedAt));
				return date('Y-m-d H:i:s', strtotime($now) + $elapsedSeconds);
			};
			$this->processClaimedWebhookDelivery(
				$claimed,
				$now,
				$resolver,
				$transport,
				$completionTime
			);
		}
	}

	private function claimWebhookDelivery(string $now): ?array {
		$db = null;
		try {
			$db = $this->db();
			$staleProcessing = date('Y-m-d H:i:s', strtotime($now) - 600);
			$lockClause = $db->getAttribute(\PDO::ATTR_DRIVER_NAME) === 'mysql' ? ' FOR UPDATE' : '';
			$db->beginTransaction();
			$stmt = $db->prepare(
				"SELECT *
				FROM registrationwatch_webhook_queue
				WHERE (status = 'pending' AND next_attempt_at <= :now)
					OR (status = 'processing' AND updated_at <= :stale_processing)
				ORDER BY
					CASE WHEN status = 'pending' THEN next_attempt_at ELSE updated_at END,
					id ASC
				LIMIT 1" . $lockClause
			);
			$stmt->execute([
				':now' => $now,
				':stale_processing' => $staleProcessing,
			]);
			$delivery = $stmt->fetch(\PDO::FETCH_ASSOC);
			if (!is_array($delivery)) {
				$db->commit();
				return null;
			}

			$storedAttempts = (int)$delivery['attempts'];
			$attempts = (string)$delivery['status'] === 'processing' && $storedAttempts >= 3
				? $storedAttempts
				: $storedAttempts + 1;
			$mark = $db->prepare(
				"UPDATE registrationwatch_webhook_queue
				SET status = 'processing', attempts = :attempts, last_attempt_at = :last_attempt_at, updated_at = :updated_at
				WHERE id = :id AND status = :expected_status AND updated_at = :expected_updated_at"
			);
			$mark->execute([
				':attempts' => $attempts,
				':last_attempt_at' => $now,
				':updated_at' => $now,
				':id' => (int)$delivery['id'],
				':expected_status' => (string)$delivery['status'],
				':expected_updated_at' => (string)$delivery['updated_at'],
			]);
			$db->commit();
			if ($mark->rowCount() !== 1) {
				return [];
			}
			$delivery['stored_status'] = (string)$delivery['status'];
			$delivery['stored_attempts'] = $storedAttempts;
			$delivery['status'] = 'processing';
			$delivery['attempts'] = $attempts;
			return $delivery;
		} catch (\Throwable $e) {
			if ($db instanceof \PDO && $db->inTransaction()) {
				try {
					$db->rollBack();
				} catch (\Throwable $rollbackError) {
					$this->logError('Webhook delivery worker could not roll back its database transaction.');
				}
			}
			$this->logWarning(
				'Webhook delivery worker failed while claiming a delivery (' . get_class($e) . ', code ' . (string)$e->getCode()
				. '); registration monitoring will continue.'
			);
			return null;
		}
	}

	private function pruneCompletedWebhookDeliveries(): void {
		try {
			$this->db()->exec("DELETE FROM registrationwatch_webhook_queue
				WHERE status IN ('delivered', 'failed', 'suppressed')
					AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
		} catch (\Throwable $e) {
			$this->logWarning('Webhook delivery history pruning failed; monitoring will continue.');
		}
	}

	private function processClaimedWebhookDelivery(
		array $delivery,
		string $now,
		?callable $resolver,
		?callable $transport,
		?callable $completionTime = null
	): void {
		$completionTime = $completionTime ?? static function () use ($now): string {
			return $now;
		};
		$deliveryId = (int)$delivery['id'];
		$storedAttempts = (int)$delivery['stored_attempts'];
		$attempts = (int)$delivery['attempts'];
		try {
			if ((string)$delivery['stored_status'] === 'processing' && $storedAttempts >= 3) {
				$this->updateWebhookDelivery(
					$deliveryId,
					'failed',
					null,
					'Delivery worker was interrupted after the maximum attempts.',
					$now,
					$storedAttempts
				);
				return;
			}

			$current = $this->db()->prepare(
				"SELECT COUNT(*) FROM registrationwatch_webhook_queue
				WHERE id = :id AND status = 'processing' AND attempts = :attempts"
			);
			$current->execute([':id' => $deliveryId, ':attempts' => $attempts]);
			if ((int)$current->fetchColumn() !== 1) {
				return;
			}

			if ((string)$delivery['alert_type'] === 'recovery') {
				$priorStmt = $this->db()->prepare(
					"SELECT status
					FROM registrationwatch_webhook_queue
					WHERE destination_id = :destination_id
						AND registration_id = :registration_id
						AND history_id >= :incident_start
						AND history_id < :recovery_history
						AND alert_type IN ('unreachable', 'not_registered')
					ORDER BY id ASC"
				);
				$priorStmt->execute([
					':destination_id' => (string)$delivery['destination_id'],
					':registration_id' => (int)$delivery['registration_id'],
					':incident_start' => (int)$delivery['incident_start_history_id'],
					':recovery_history' => (int)$delivery['history_id'],
				]);
				$priorStatuses = $priorStmt->fetchAll(\PDO::FETCH_COLUMN);
				$problemDelivered = in_array('delivered', $priorStatuses, true);
				$problemPending = count(array_intersect(['pending', 'processing'], $priorStatuses)) > 0;
				if (!$problemDelivered) {
					if ($problemPending) {
						$this->updateWebhookDelivery(
							$deliveryId,
							'pending',
							null,
							'Waiting for the corresponding problem notification.',
							$now,
							max(0, $attempts - 1),
							date('Y-m-d H:i:s', strtotime($now) + 60),
							$attempts
						);
						return;
					}
					$this->updateWebhookDelivery(
						$deliveryId,
						'suppressed',
						null,
						'No successful problem notification was delivered.',
						$now,
						$attempts
					);
					return;
				}
			}

			$destinationId = (string)$delivery['destination_id'];
			if (!$this->acquireWebhookDestinationLock($destinationId, 0)) {
				$this->updateWebhookDelivery(
					$deliveryId,
					'pending',
					null,
					'Destination configuration is being changed.',
					$now,
					$storedAttempts,
					date('Y-m-d H:i:s', strtotime($now) + 60),
					$attempts
				);
				return;
			}
			try {
				$claimAfterLock = $this->db()->prepare(
					"SELECT COUNT(*) FROM registrationwatch_webhook_queue
					WHERE id = :id AND status = 'processing' AND attempts = :attempts"
				);
				$claimAfterLock->execute([':id' => $deliveryId, ':attempts' => $attempts]);
				if ((int)$claimAfterLock->fetchColumn() !== 1) {
					return;
				}
				$destination = $this->getWebhookDestination($destinationId);
				if ($destination === null || empty($destination['enabled'])) {
					$this->updateWebhookDelivery($deliveryId, 'suppressed', null, 'Destination disabled or removed.', $now, $attempts);
					return;
				}
				$queuedFingerprint = (string)($delivery['destination_fingerprint'] ?? '');
				$currentFingerprint = $this->webhookDestinationDeliveryFingerprint($destination);
				if ($queuedFingerprint === '') {
					$this->updateWebhookDelivery(
						$deliveryId,
						'suppressed',
						null,
						'Destination configuration identity was not recorded for this delivery.',
						$now,
						$attempts
					);
					return;
				}
				if (!hash_equals($queuedFingerprint, $currentFingerprint)) {
					$this->updateWebhookDelivery(
						$deliveryId,
						'suppressed',
						null,
						'Destination configuration changed before delivery.',
						$now,
						$attempts
					);
					return;
				}
				$destination = $this->prepareWebhookDestination($destination);
				if (isset($destination['error'])) {
					$this->updateWebhookDelivery($deliveryId, 'failed', null, 'Saved authentication headers cannot be decrypted.', $now, $attempts);
					return;
				}
				$payload = json_decode((string)$delivery['payload'], true);
				if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE) {
					$this->updateWebhookDelivery($deliveryId, 'failed', null, 'Stored notification payload is invalid.', $now, $attempts);
					return;
				}
				if ($this->isMonitoringSnoozed()) {
					$this->updateWebhookDelivery(
						$deliveryId,
						'suppressed',
						null,
						'Monitoring is snoozed.',
						$now,
						$storedAttempts,
						null,
						$attempts
					);
					return;
				}

				$result = RegistrationwatchWebhook::deliver($destination, $payload, $resolver, $transport);
				$completedAt = $completionTime();
				if (!empty($result['status'])) {
					$this->updateWebhookDelivery(
						$deliveryId,
						'delivered',
						$result['http_status'],
						null,
						$completedAt,
						$attempts,
						null,
						$attempts,
						$now
					);
				} elseif (!empty($result['retryable']) && $attempts < 3) {
					$this->updateWebhookDelivery(
						$deliveryId,
						'pending',
						$result['http_status'],
						(string)$result['error'],
						$completedAt,
						$attempts,
						date('Y-m-d H:i:s', strtotime($completedAt) + ($attempts === 1 ? 60 : 300)),
						$attempts,
						$now
					);
				} else {
					$this->updateWebhookDelivery(
						$deliveryId,
						'failed',
						$result['http_status'],
						(string)$result['error'],
						$completedAt,
						$attempts,
						null,
						$attempts,
						$now
					);
				}
			} finally {
				$this->releaseWebhookDestinationLock($destinationId);
			}
		} catch (\Throwable $e) {
			$completedAt = $completionTime();
			$this->logWarning(
				'Webhook delivery ' . $deliveryId . ' failed (' . get_class($e) . ', code ' . (string)$e->getCode()
				. '); remaining batch deliveries will continue.'
			);
			try {
				$this->updateWebhookDelivery(
					$deliveryId,
					$attempts < 3 ? 'pending' : 'failed',
					null,
					'Delivery worker encountered an unexpected error.',
					$completedAt,
					$attempts,
					$attempts < 3 ? date('Y-m-d H:i:s', strtotime($completedAt) + ($attempts === 1 ? 60 : 300)) : null,
					$attempts,
					$now
				);
			} catch (\Throwable $updateError) {
				$this->logError('Webhook delivery ' . $deliveryId . ' could not record its worker failure.');
			}
		}
	}

	private function updateWebhookDelivery(
		int $id,
		string $status,
		?int $httpStatus,
		?string $error,
		string $updatedAt,
		int $attempts,
		?string $nextAttemptAt = null,
		?int $expectedClaimAttempts = null,
		?string $expectedClaimUpdatedAt = null
	): bool {
		$expectedClaimAttempts = $expectedClaimAttempts ?? $attempts;
		$expectedClaimUpdatedAt = $expectedClaimUpdatedAt ?? $updatedAt;
		$stmt = $this->db()->prepare(
			'UPDATE registrationwatch_webhook_queue
			SET status = :status, http_status = :http_status, last_error = :last_error,
				attempts = :attempts,
				next_attempt_at = COALESCE(:next_attempt_at, next_attempt_at),
				updated_at = :updated_at
			WHERE id = :id
				AND status = \'processing\'
				AND attempts = :expected_claim_attempts
				AND updated_at = :expected_claim_updated_at'
		);
		$stmt->execute([
			':status' => $status,
			':http_status' => $httpStatus,
			':last_error' => $error === null ? null : substr($error, 0, 512),
			':attempts' => $attempts,
			':next_attempt_at' => $nextAttemptAt,
			':updated_at' => $updatedAt,
			':id' => $id,
			':expected_claim_attempts' => $expectedClaimAttempts,
			':expected_claim_updated_at' => $expectedClaimUpdatedAt,
		]);
		return $stmt->rowCount() === 1;
	}

	private function alertTypeForTransition(array $transition, array $settings): ?string {
		$from = $this->normaliseState($transition['from_state'] ?? '');
		$to = $this->normaliseState($transition['to_state'] ?? '');
		if ($from === '') {
			return null;
		}

		if ($to === self::STATUS_UNREACHABLE && $settings['alert_on_unreachable'] === '1' && $this->hadRegisteredState($from)) {
			return 'unreachable';
		}

		if ($to === self::STATUS_NOT_REGISTERED && $settings['alert_on_not_registered'] === '1' && in_array($from, [
			self::STATUS_REACHABLE,
			self::STATUS_REGISTERED_NO_QUALIFY,
			self::STATUS_UNREACHABLE,
		], true)) {
			return 'not_registered';
		}

		if ($settings['alert_on_recovery'] === '1' && (in_array($from, [
			self::STATUS_UNREACHABLE,
			self::STATUS_NOT_REGISTERED,
		], true) || $from === self::STATUS_UNKNOWN) && in_array($to, [
			self::STATUS_REACHABLE,
			self::STATUS_REGISTERED_NO_QUALIFY,
		], true)) {
			return 'recovery';
		}

		return null;
	}

	private function isEscalatingAlertType(string $alertType): bool {
		return in_array($alertType, ['unreachable', 'not_registered'], true);
	}

	private function isRecoveryTransition(array $transition): bool {
		$from = $this->normaliseState($transition['from_state'] ?? '');
		$to = $this->normaliseState($transition['to_state'] ?? '');
		return (in_array($from, [
			self::STATUS_UNREACHABLE,
			self::STATUS_NOT_REGISTERED,
		], true) || $from === self::STATUS_UNKNOWN) && in_array($to, [
			self::STATUS_REACHABLE,
			self::STATUS_REGISTERED_NO_QUALIFY,
		], true);
	}

	private function resetEscalationForRecovery(array $transition): void {
		$stmt = $this->db()->prepare(
			'DELETE FROM registrationwatch_alert_escalation
			WHERE registration_id = :registration_id
				AND history_id <= :recovery_history_id'
		);
		$stmt->execute([
			':registration_id' => (int)$transition['registration_id'],
			':recovery_history_id' => (int)$transition['id'],
		]);
	}

	private function resolveRepeatMode(?string $registrationRepeatMode, array $settings): string {
		$registrationRepeatMode = trim((string)$registrationRepeatMode);
		if ($registrationRepeatMode !== '') {
			return $this->normaliseRepeatMode($registrationRepeatMode);
		}

		return $this->normaliseRepeatMode($settings['repeat_mode'] ?? self::REPEAT_MODE_NEVER);
	}

	private function getActiveEscalationForRegistration(int $registrationId): array {
		$stmt = $this->db()->prepare(
			'SELECT id, registration_id, registration_key, extension, history_id, alert_type, active_since, last_alert_at, alert_count, next_due_at, repeat_mode
			FROM registrationwatch_alert_escalation
			WHERE registration_id = :registration_id
			ORDER BY active_since ASC, id ASC
			LIMIT 1'
		);
		$stmt->execute([':registration_id' => $registrationId]);
		$row = $stmt->fetch(\PDO::FETCH_ASSOC);

		return is_array($row) ? $row : [];
	}

	private function upsertEscalationForTransition(array $transition, string $alertType, string $repeatMode, string $now, array $existingEscalation = []): void {
		$registrationId = (int)$transition['registration_id'];
		$registrationKey = (string)$transition['registration_key'];
		$extension = (string)$transition['extension'];
		$repeatMode = $this->normaliseRepeatMode($repeatMode);
		if ($repeatMode === self::REPEAT_MODE_NEVER) {
			$this->deleteEscalationsForRegistration($registrationId);
			return;
		}

		$alertCount = isset($existingEscalation['alert_count']) ? max(0, (int)$existingEscalation['alert_count']) : 0;
		$activeSince = !empty($existingEscalation['active_since']) ? (string)$existingEscalation['active_since'] : (string)$transition['created_at'];
		$lastAlertAt = !empty($existingEscalation['last_alert_at']) ? (string)$existingEscalation['last_alert_at'] : $now;
		$nextDueAt = !empty($existingEscalation['next_due_at'])
			? (string)$existingEscalation['next_due_at']
			: $this->nextRepeatDueAt($now, $repeatMode, $alertCount);
		if ($nextDueAt === null) {
			$this->deleteEscalationsForRegistration($registrationId);
			return;
		}

		$stmt = $this->db()->prepare(
			'INSERT INTO registrationwatch_alert_escalation
				(registration_id, registration_key, extension, history_id, alert_type, active_since, last_alert_at, alert_count, next_due_at, repeat_mode, created_at, updated_at)
			VALUES
				(:registration_id, :registration_key, :extension, :history_id, :alert_type, :active_since, :last_alert_at, :alert_count, :next_due_at, :repeat_mode, :created_at, :updated_at)
			ON DUPLICATE KEY UPDATE
				registration_key = VALUES(registration_key),
				extension = VALUES(extension),
				history_id = VALUES(history_id),
				active_since = VALUES(active_since),
				last_alert_at = VALUES(last_alert_at),
				alert_count = VALUES(alert_count),
				next_due_at = VALUES(next_due_at),
				repeat_mode = VALUES(repeat_mode),
				updated_at = VALUES(updated_at)'
		);
		$stmt->execute([
			':registration_id' => $registrationId,
			':registration_key' => $registrationKey,
			':extension' => $extension,
			':history_id' => (int)$transition['id'],
			':alert_type' => $alertType,
			':active_since' => $activeSince,
			':last_alert_at' => $lastAlertAt,
			':alert_count' => $alertCount,
			':next_due_at' => $nextDueAt,
			':repeat_mode' => $repeatMode,
			':created_at' => $now,
			':updated_at' => $now,
		]);
	}

	private function deleteEscalationsForRegistration(int $registrationId): void {
		$stmt = $this->db()->prepare(
			'DELETE FROM registrationwatch_alert_escalation
			WHERE registration_id = :registration_id'
		);
		$stmt->execute([':registration_id' => $registrationId]);
	}

	private function deleteEscalationById(int $id): void {
		$stmt = $this->db()->prepare(
			'DELETE FROM registrationwatch_alert_escalation
			WHERE id = :id'
		);
		$stmt->execute([':id' => $id]);
	}

	private function deleteOtherEscalations(int $registrationId, string $activeAlertType): void {
		$stmt = $this->db()->prepare(
			'DELETE FROM registrationwatch_alert_escalation
			WHERE registration_id = :registration_id
				AND alert_type <> :alert_type'
		);
		$stmt->execute([
			':registration_id' => $registrationId,
			':alert_type' => $activeAlertType,
		]);
	}

	private function collectDueReminderAlerts(
		string $now,
		array $settings,
		array $recipients,
		bool $canSendWebhook = false,
		?callable $liveContactLoader = null
	): array {
		$result = ['alerts' => [], 'cycles' => [], 'webhook_reminders' => []];
		$canSendEmail = $settings['alert_enabled'] === '1' && (bool)$recipients;
		if (!$canSendEmail && !$canSendWebhook) {
			return $result;
		}

		try {
			$liveContacts = $liveContactLoader !== null
				? $liveContactLoader()
				: $this->getLiveContacts();
		} catch (\Throwable $e) {
			$this->logWarning('Reminder pass skipped because live registration status is unavailable: ' . $e->getMessage());
			return $result;
		}

		$stmt = $this->db()->prepare(
			'SELECT a.id, a.registration_id, a.registration_key, a.extension, a.history_id, a.alert_type, a.active_since, a.last_alert_at,
				a.alert_count, a.next_due_at, a.repeat_mode,
				r.last_known_status, r.contact_uri, r.latency_ms, r.enabled
			FROM registrationwatch_alert_escalation a
			JOIN registrationwatch_registrations r
				ON r.id = a.registration_id
			WHERE a.next_due_at <= :now
				AND r.enabled = 1
			ORDER BY a.next_due_at ASC, a.id ASC
			LIMIT 100'
		);
		$stmt->execute([':now' => $now]);

		foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
			$newerStmt = $this->db()->prepare(
				'SELECT id FROM registrationwatch_alert_escalation
				WHERE registration_id = :registration_id
					AND (history_id > :history_id OR (history_id = :history_id AND id > :id))
				ORDER BY history_id DESC, id DESC
				LIMIT 1'
			);
			$newerStmt->execute([
				':registration_id' => (int)$row['registration_id'],
				':history_id' => (int)$row['history_id'],
				':id' => (int)$row['id'],
			]);
			if ($newerStmt->fetchColumn() !== false) {
				$this->deleteEscalationById((int)$row['id']);
				continue;
			}

			$currentStatus = $this->currentLiveStatusForReminder($row, $liveContacts);
			if (!$this->isReminderStillAlertable($currentStatus)) {
				if ($currentStatus === self::STATUS_UNKNOWN) {
					continue;
				}
				$this->deleteEscalationById((int)$row['id']);
				continue;
			}
			$alertType = $this->reminderAlertTypeForStatus($currentStatus);
			if ($alertType === null) {
				$this->deleteEscalationById((int)$row['id']);
				continue;
			}
			if (($alertType === 'unreachable' && $settings['alert_on_unreachable'] !== '1')
				|| ($alertType === 'not_registered' && $settings['alert_on_not_registered'] !== '1')) {
				continue;
			}
			if ((string)$row['alert_type'] !== $alertType) {
				if (!$this->retargetEscalationForReminder($row, $alertType)) {
					continue;
				}
				$row['alert_type'] = $alertType;
			}

			$reminderN = ((int)$row['alert_count']) + 1;
			$transition = $this->buildReminderTransition($row, $currentStatus, $now);
			$reservedAny = false;

			if ($canSendEmail) {
				$email = $this->buildAlertEmail($transition, $alertType);
				foreach ($recipients as $recipient) {
					$reserved = $this->reserveAlertHistory([
						'registration_id' => (int)$row['registration_id'],
						'registration_key' => $row['registration_key'],
						'extension' => $row['extension'],
						'history_id' => (int)$row['history_id'],
						'reminder_n' => $reminderN,
						'alert_type' => $alertType,
						'status' => $currentStatus,
						'contact_uri' => $row['contact_uri'] ?? null,
						'recipient' => $recipient,
						'subject' => $email['subject'],
						'message' => $email['message'],
						'sent_at' => $now,
						'result' => 'pending',
						'error' => null,
					]);
					if (!$reserved) {
						continue;
					}

					$reservedAny = true;
					$result['alerts'][] = [
						'registration_id' => (int)$row['registration_id'],
						'registration_key' => (string)$row['registration_key'],
						'extension' => (string)$row['extension'],
						'history_id' => (int)$row['history_id'],
						'reminder_n' => $reminderN,
						'alert_type' => $alertType,
						'status' => $currentStatus,
						'contact_uri' => $row['contact_uri'] ?? null,
						'recipient' => $recipient,
						'subject' => $email['subject'],
						'message' => $email['message'],
						'source' => 'reminder',
					];
				}
			}

			$queuedWebhookReminder = false;
			if ($canSendWebhook) {
				$webhookTransition = $transition;
				try {
					$historicalTransition = $this->getWebhookTransitionById((int)$row['history_id']);
					if ($historicalTransition !== null) {
						$webhookTransition = $historicalTransition;
						$webhookTransition['to_state'] = $currentStatus;
						$webhookTransition['reason'] = 'reminder';
						$webhookTransition['reminder_n'] = $reminderN;
						$webhookTransition['alert_type'] = $alertType;
					}
				} catch (\Throwable $e) {
					$this->logWarning('Webhook reminder context lookup failed; the reminder will use the current registration state.');
				}
				$result['webhook_reminders'][] = $webhookTransition;
				$queuedWebhookReminder = true;
			}
			if ($reservedAny || $queuedWebhookReminder) {
				$result['cycles'][(int)$row['id']] = [
					'row' => $row,
					'reminder_n' => $reminderN,
				];
			}
		}

		return $result;
	}

	private function dispatchCollectedAlerts(
		array $alerts,
		array $reminderCycles,
		array $settings,
		array $recipients,
		string $now,
		array $webhookReminders = []
	): void {
		if (!$alerts && !$webhookReminders) {
			return;
		}

		$remindersToQueue = $webhookReminders;
		if (!$remindersToQueue) {
			try {
				foreach ($alerts as $alert) {
					if ((string)($alert['source'] ?? '') !== 'reminder') {
						continue;
					}
					$transition = $this->getWebhookTransitionById((int)$alert['history_id']);
					if ($transition === null) {
						continue;
					}
					$transition['to_state'] = (string)$alert['status'];
					$transition['reason'] = 'reminder';
					$transition['reminder_n'] = (int)($alert['reminder_n'] ?? 0);
					$transition['alert_type'] = (string)$alert['alert_type'];
					$remindersToQueue[] = $transition;
				}
			} catch (\Throwable $e) {
				$this->logWarning('Webhook reminder lookup failed; email notification processing will continue.');
			}
		}
		foreach ($remindersToQueue as $transition) {
			$this->queueWebhookEvent(
				$transition,
				(string)$transition['alert_type'],
				(int)($transition['reminder_n'] ?? 0),
				(int)$transition['id']
			);
		}

		if ($this->isMonitoringSnoozed()) {
			foreach ($alerts as $alert) {
				$this->updateReservedAlertHistory(
					(int)$alert['history_id'],
					(string)$alert['alert_type'],
					(string)$alert['recipient'],
					'suppressed',
					'Monitoring snoozed',
					$now,
					(int)($alert['reminder_n'] ?? 0)
				);
			}
			$this->markReminderCyclesComplete($reminderCycles, $now);
			return;
		}

		$threshold = $this->stormThreshold($settings);
		if ($threshold > 0 && count($alerts) >= $threshold) {
			$summaryResults = [];
			foreach ($recipients as $recipient) {
				$recipientAlerts = array_values(array_filter($alerts, function (array $alert) use ($recipient): bool {
					return (string)$alert['recipient'] === (string)$recipient;
				}));
				if (!$recipientAlerts) {
					continue;
				}

				$recipientSummaryResult = $this->dispatchStormSummary($recipientAlerts, [$recipient], $now);
				$summaryResults[$recipient] = $recipientSummaryResult[$recipient] ?? ['status' => false, 'message' => 'Storm summary was not attempted for this recipient.'];
			}

			foreach ($alerts as $alert) {
				$recipient = (string)$alert['recipient'];
				$summaryResult = $summaryResults[$recipient] ?? ['status' => false, 'message' => 'Storm summary was not attempted for this recipient.'];
				$coveredBySummary = !empty($summaryResult['status']);
				$this->updateReservedAlertHistory(
					(int)$alert['history_id'],
					(string)$alert['alert_type'],
					$recipient,
					$coveredBySummary ? 'storm_suppressed' : 'storm_summary_failed',
					$coveredBySummary ? null : (string)$summaryResult['message'],
					$now,
					(int)($alert['reminder_n'] ?? 0)
				);
			}
			$this->markReminderCyclesComplete($reminderCycles, $now);
			return;
		}

		foreach ($alerts as $alert) {
			$result = $this->sendEmail((string)$alert['recipient'], (string)$alert['subject'], (string)$alert['message']);
			if (!$result['status']) {
				$this->logWarning('Alert email send failed for ' . $alert['recipient'] . ' on extension ' . $alert['extension'] . ': ' . $result['message']);
			}
			$this->updateReservedAlertHistory(
				(int)$alert['history_id'],
				(string)$alert['alert_type'],
				(string)$alert['recipient'],
				$result['status'] ? 'sent' : 'failed',
				$result['status'] ? null : $result['message'],
				$this->now(),
				(int)($alert['reminder_n'] ?? 0)
			);
		}

		$this->markReminderCyclesComplete($reminderCycles, $now);
	}

	private function stormThreshold(array $settings): int {
		$value = isset($settings['storm_threshold']) ? trim((string)$settings['storm_threshold']) : $this->settingsDefaults['storm_threshold'];
		if ($value === '' || !ctype_digit($value)) {
			return 0;
		}

		return min(10000, max(0, (int)$value));
	}

	private function dispatchStormSummary(array $alerts, array $recipients, string $now): array {
		$email = $this->buildStormSummaryEmail($alerts, $now);
		$results = [];
		foreach ($recipients as $recipient) {
			$result = $this->sendEmail($recipient, $email['subject'], $email['message']);
			$results[$recipient] = $result;
			if (!$result['status']) {
				$this->logWarning('Storm summary email send failed for ' . $recipient . ': ' . $result['message']);
			}
			$this->insertAlertHistory([
				'extension' => '',
				'history_id' => null,
				'reminder_n' => 0,
				'alert_type' => 'storm_summary',
				'status' => 'storm_summary',
				'recipient' => $recipient,
				'subject' => $email['subject'],
				'message' => $email['message'],
				'sent_at' => $now,
				'result' => $result['status'] ? 'sent' : 'failed',
				'error' => $result['status'] ? null : $result['message'],
			]);
		}

		return $results;
	}

	private function buildStormSummaryEmail(array $alerts, string $now): array {
		$total = count($alerts);
		$typeCounts = [];
		$registrations = [];

		foreach ($alerts as $alert) {
			$type = (string)$alert['alert_type'];
			$typeCounts[$type] = ($typeCounts[$type] ?? 0) + 1;
			$key = (string)$alert['extension'] . '|' . $type . '|' . (string)$alert['status'];
			$registrations[$key] = [
				'extension' => (string)$alert['extension'],
				'alert_type' => $type,
				'status' => (string)$alert['status'],
			];
		}

		ksort($typeCounts);
		ksort($registrations);

		$subject = $total === 1
			? _('Registration Watch: Storm Summary (1 alert suppressed)')
			: sprintf(_('Registration Watch: Storm Summary (%d alerts suppressed)'), $total);
		$message = [
			_('Registration Watch Storm Summary') . ' from ' . $this->getSystemIdentifier(),
			'',
			$total === 1
				? _('1 alert email was suppressed in this processing pass.')
				: sprintf(_('%d alert emails were suppressed in this processing pass.'), $total),
			_('Storm Threshold limits large batches of alerts generated in the same processing pass. It reduces email floods from sudden widespread registration changes, but it is not full correlated-outage detection. The count is per registration. Use 0 to disable.'),
			'',
			'Time: ' . $now,
			'',
			_('Suppressed alert types:'),
		];

		foreach ($typeCounts as $type => $count) {
			$message[] = sprintf('%s: %d', $this->stateLabel($type), $count);
		}

		if (count($typeCounts) === 1 && isset($typeCounts['recovery'])) {
			$message[] = '';
			$message[] = sprintf(_('%d recovery alerts were suppressed in this pass.'), $total);
		}

		$message[] = '';
		$message[] = _('Watched registrations included in this pass:');
		foreach ($registrations as $registration) {
			$message[] = sprintf(
				'%s - %s',
				$registration['extension'],
				$this->alertTypePhrase($registration['alert_type'], $registration['status'])
			);
		}

		return [
			'subject' => $subject,
			'message' => implode("\n", $message),
		];
	}

	private function alertTypePhrase(string $alertType, string $status): string {
		if ($alertType === 'recovery') {
			return 'recovered to ' . $this->stateLabel($status);
		}
		return 'became ' . $this->stateLabel($status);
	}

	private function markReminderCyclesComplete(array $reminderCycles, string $now): void {
		foreach ($reminderCycles as $cycle) {
			$this->markReminderCycleComplete($cycle['row'], (int)$cycle['reminder_n'], $now);
		}
	}

	private function processAlertIncident(array $incident, ?array $recovery, int $debounceSeconds, string $staleCutoff, string $now, array $settings, array $recipients, bool $canSend, bool $canSendWebhook, array &$collectedAlerts, array &$recoveryAuditCandidates): void {
		$start = $incident['start'];
		$problemTransitions = $incident['problem_transitions'] ?? [];
		$problemTransition = $problemTransitions
			? $problemTransitions[count($problemTransitions) - 1]
			: ($incident['problem_transition'] ?? null);
		$problemAlertType = $incident['problem_alert_type'] ?? null;
		$startId = (int)$start['id'];
		$registrationId = (int)$start['registration_id'];
		$endId = $recovery !== null ? (int)$recovery['id'] : (int)($problemTransition['id'] ?? $startId);
		$startTs = strtotime((string)$start['created_at']);
		$problemTransitionTs = strtotime((string)($problemTransition['created_at'] ?? ''));
		$nowTs = strtotime($now);
		$staleCutoffTs = strtotime($staleCutoff);
		$finishTs = $recovery !== null ? strtotime((string)$recovery['created_at']) : $nowTs;
		$hasAlertableProblem = !empty($incident['start_is_alertable'])
			&& is_array($problemTransition)
			&& $this->isEscalatingAlertType((string)$problemAlertType);
		$problemEligible = $hasAlertableProblem
			&& $startTs !== false
			&& $problemTransitionTs !== false
			&& $finishTs !== false
			&& $nowTs !== false
			&& $staleCutoffTs !== false
			&& $problemTransitionTs >= $staleCutoffTs
			&& $finishTs - $startTs >= $debounceSeconds;
		$debounceSuppressed = $hasAlertableProblem
			&& $recovery !== null
			&& $this->isRecoveryTransition($recovery)
			&& $startTs !== false
			&& $finishTs !== false
			&& $nowTs !== false
			&& $staleCutoffTs !== false
			&& $startTs >= $staleCutoffTs
			&& $finishTs >= $staleCutoffTs
			&& $finishTs <= $nowTs
			&& $finishTs >= $startTs
			&& $finishTs - $startTs < $debounceSeconds;

		if ($problemEligible) {
			if ($recovery === null) {
				$repeatMode = $this->resolveRepeatMode($problemTransition['repeat_mode'] ?? null, $settings);
				$existingEscalation = $this->getActiveEscalationForRegistration($registrationId);
				$this->deleteOtherEscalations($registrationId, (string)$problemAlertType);
				$this->upsertEscalationForTransition($problemTransition, (string)$problemAlertType, $repeatMode, $now, $existingEscalation);
			}

			if ($canSendWebhook) {
				$webhookTransitions = $debounceSeconds === 0 ? $problemTransitions : [$problemTransition];
				foreach ($webhookTransitions as $transition) {
					$alertType = $this->alertTypeForTransition($transition, $settings);
					if ($this->isEscalatingAlertType((string)$alertType)) {
						$this->queueWebhookEvent($transition, (string)$alertType, 0, $startId);
					}
				}
			}

			if ($canSend) {
				foreach ($recipients as $recipient) {
					$priorActions = $this->getProblemAlertResultsForIncident($registrationId, $startId, $endId, $recipient);
					$lastNotifiedHistoryId = 0;
					foreach ($priorActions as $priorAction) {
						if (in_array((string)$priorAction['result'], ['sent', 'storm_suppressed'], true)) {
							$lastNotifiedHistoryId = max($lastNotifiedHistoryId, (int)$priorAction['history_id']);
						}
					}

					if ($debounceSeconds === 0) {
						$transitionsToAlert = $problemTransitions;
					} elseif ($lastNotifiedHistoryId === 0) {
						$transitionsToAlert = [$problemTransition];
					} else {
						$transitionsToAlert = array_values(array_filter($problemTransitions, static function (array $transition) use ($lastNotifiedHistoryId): bool {
							return (int)$transition['id'] > $lastNotifiedHistoryId;
						}));
					}

					foreach ($transitionsToAlert as $transition) {
						$transitionTs = strtotime((string)$transition['created_at']);
						if ($transitionTs === false || $staleCutoffTs === false || $nowTs === false || $transitionTs < $staleCutoffTs || $transitionTs > $nowTs) {
							continue;
						}

						$alertType = $this->alertTypeForTransition($transition, $settings);
						if (!$this->isEscalatingAlertType((string)$alertType) || $this->hasRecordedAlertForRecipient((int)$transition['id'], (string)$alertType, $recipient)) {
							continue;
						}

						$email = $this->buildAlertEmail($transition, (string)$alertType);
						$reserved = $this->reserveAlertHistory([
							'registration_id' => $registrationId,
							'registration_key' => $transition['registration_key'],
							'extension' => $transition['extension'],
							'history_id' => (int)$transition['id'],
							'alert_type' => $alertType,
							'status' => $transition['to_state'],
							'contact_uri' => $transition['contact_uri'] ?? null,
							'recipient' => $recipient,
							'subject' => $email['subject'],
							'message' => $email['message'],
							'sent_at' => $now,
							'result' => 'pending',
							'error' => null,
						]);
						if (!$reserved) {
							continue;
						}

						$collectedAlerts[] = [
							'registration_id' => $registrationId,
							'registration_key' => (string)$transition['registration_key'],
							'extension' => (string)$transition['extension'],
							'history_id' => (int)$transition['id'],
							'reminder_n' => 0,
							'alert_type' => (string)$alertType,
							'status' => (string)$transition['to_state'],
							'contact_uri' => $transition['contact_uri'] ?? null,
							'recipient' => $recipient,
							'subject' => $email['subject'],
							'message' => $email['message'],
							'source' => 'transition',
						];
					}
				}
			}
		} elseif ($debounceSuppressed && $canSend) {
			foreach ($recipients as $recipient) {
				if ($this->hasRecordedAlertForRecipient((int)$problemTransition['id'], (string)$problemAlertType, $recipient)) {
					continue;
				}

				$email = $this->buildAlertEmail($problemTransition, (string)$problemAlertType);
				$reserved = $this->reserveAlertHistory([
					'registration_id' => $registrationId,
					'registration_key' => $problemTransition['registration_key'],
					'extension' => $problemTransition['extension'],
					'history_id' => (int)$problemTransition['id'],
					'alert_type' => $problemAlertType,
					'status' => $problemTransition['to_state'],
					'contact_uri' => $problemTransition['contact_uri'] ?? null,
					'recipient' => $recipient,
					'subject' => $email['subject'],
					'message' => $email['message'],
					'sent_at' => $now,
					'result' => 'pending',
					'error' => null,
				]);
				if ($reserved) {
					$this->updateReservedAlertHistory(
						(int)$problemTransition['id'],
						(string)$problemAlertType,
						$recipient,
						'suppressed',
						'Debounce Delay',
						$now
					);
				}
			}
		}

		$recoveryTs = $recovery !== null ? strtotime((string)$recovery['created_at']) : false;
		if ($canSendWebhook && $recovery !== null && $this->isRecoveryTransition($recovery)) {
			$recoveryAlertType = $this->alertTypeForTransition($recovery, $settings);
			if ($recoveryAlertType === 'recovery'
				&& $recoveryTs !== false
				&& $staleCutoffTs !== false
				&& $recoveryTs >= $staleCutoffTs
				&& ($nowTs === false || $recoveryTs <= $nowTs)) {
				$this->queueWebhookEvent($recovery, 'recovery', 0, $startId);
			}
		}

		if ($recovery === null || !$canSend || !$this->isRecoveryTransition($recovery)) {
			return;
		}

		$recoveryTs = strtotime((string)$recovery['created_at']);
		if ($recoveryTs === false || $staleCutoffTs === false || $recoveryTs < $staleCutoffTs || ($nowTs !== false && $recoveryTs > $nowTs)) {
			return;
		}

		$recoveryAlertType = $this->alertTypeForTransition($recovery, $settings);
		if ($recoveryAlertType !== 'recovery') {
			return;
		}

		foreach ($recipients as $recipient) {
			$priorActions = $this->getProblemAlertResultsForIncident($registrationId, $startId, (int)$recovery['id'], $recipient);
			$problemWasNotified = false;
			foreach ($priorActions as $priorAction) {
				if (in_array((string)$priorAction['result'], ['sent', 'storm_suppressed'], true)) {
					$problemWasNotified = true;
					break;
				}
			}
			if ($this->hasRecordedAlertForRecipient((int)$recovery['id'], 'recovery', $recipient)) {
				continue;
			}
			if (!$problemWasNotified) {
				if ($priorActions) {
					$recoveryAuditCandidates[] = [
						'registration_id' => $registrationId,
						'start_history_id' => $startId,
						'recovery' => $recovery,
						'recipient' => $recipient,
					];
				}
				continue;
			}

			$email = $this->buildAlertEmail($recovery, 'recovery');
			$reserved = $this->reserveAlertHistory([
				'registration_id' => $registrationId,
				'registration_key' => $recovery['registration_key'],
				'extension' => $recovery['extension'],
				'history_id' => (int)$recovery['id'],
				'alert_type' => 'recovery',
				'status' => $recovery['to_state'],
				'contact_uri' => $recovery['contact_uri'] ?? null,
				'recipient' => $recipient,
				'subject' => $email['subject'],
				'message' => $email['message'],
				'sent_at' => $now,
				'result' => 'pending',
				'error' => null,
			]);
			if (!$reserved) {
				continue;
			}

			$collectedAlerts[] = [
				'registration_id' => $registrationId,
				'registration_key' => (string)$recovery['registration_key'],
				'extension' => (string)$recovery['extension'],
				'history_id' => (int)$recovery['id'],
				'reminder_n' => 0,
				'alert_type' => 'recovery',
				'status' => (string)$recovery['to_state'],
				'contact_uri' => $recovery['contact_uri'] ?? null,
				'recipient' => $recipient,
				'subject' => $email['subject'],
				'message' => $email['message'],
				'source' => 'transition',
			];
		}
	}

	private function recordSuppressedRecoveryAudits(array $candidates, string $now): void {
		foreach ($candidates as $candidate) {
			$recovery = $candidate['recovery'];
			$recipient = (string)$candidate['recipient'];
			$recoveryId = (int)$recovery['id'];
			if ($this->hasRecordedAlertForRecipient($recoveryId, 'recovery', $recipient)) {
				continue;
			}

			$priorActions = $this->getProblemAlertResultsForIncident(
				(int)$candidate['registration_id'],
				(int)$candidate['start_history_id'],
				$recoveryId,
				$recipient
			);
			$suppressionReason = null;
			$problemWasNotified = false;
			foreach ($priorActions as $priorAction) {
				$result = (string)$priorAction['result'];
				if (in_array($result, ['sent', 'storm_suppressed'], true)) {
					$problemWasNotified = true;
					break;
				}

				if ($suppressionReason !== null) {
					continue;
				}
				if ($result === 'failed') {
					$suppressionReason = 'No successful problem notification delivered';
				} elseif ($result === 'storm_summary_failed') {
					$error = trim((string)($priorAction['error'] ?? ''));
					$suppressionReason = 'Storm Summary delivery failed' . ($error !== '' ? ': ' . $error : '');
				} elseif ($result === 'suppressed') {
					$error = trim((string)($priorAction['error'] ?? ''));
					if ($error === 'Debounce Delay') {
						$suppressionReason = 'Original problem alert suppressed (Debounce Delay)';
					} elseif ($error === 'Monitoring snoozed') {
						$suppressionReason = 'Original problem alert suppressed (Monitoring snoozed)';
					} elseif ($error !== '') {
						$suppressionReason = 'Original problem alert suppressed (' . $error . ')';
					} else {
						$suppressionReason = 'Original problem alert suppressed';
					}
				}
			}

			if ($problemWasNotified || $suppressionReason === null) {
				continue;
			}

			$email = $this->buildAlertEmail($recovery, 'recovery');
			$reserved = $this->reserveAlertHistory([
				'registration_id' => (int)$candidate['registration_id'],
				'registration_key' => $recovery['registration_key'],
				'extension' => $recovery['extension'],
				'history_id' => $recoveryId,
				'alert_type' => 'recovery',
				'status' => $recovery['to_state'],
				'contact_uri' => $recovery['contact_uri'] ?? null,
				'recipient' => $recipient,
				'subject' => $email['subject'],
				'message' => $email['message'],
				'sent_at' => $now,
				'result' => 'pending',
				'error' => null,
			]);
			if ($reserved) {
				$this->updateReservedAlertHistory($recoveryId, 'recovery', $recipient, 'suppressed', $suppressionReason, $now);
			}
		}
	}

	private function getProblemAlertResultsForIncident(int $registrationId, int $startHistoryId, int $endHistoryId, string $recipient): array {
		$stmt = $this->db()->prepare(
			"SELECT history_id, result, error
			FROM registrationwatch_alert_history
			WHERE registration_id = :registration_id
				AND history_id >= :start_history_id
				AND history_id <= :end_history_id
				AND alert_type IN ('unreachable', 'not_registered')
				AND recipient = :recipient
			ORDER BY history_id DESC, sent_at DESC, id DESC"
		);
		$stmt->execute([
			':registration_id' => $registrationId,
			':start_history_id' => $startHistoryId,
			':end_history_id' => $endHistoryId,
			':recipient' => $recipient,
		]);

		return $stmt->fetchAll(\PDO::FETCH_ASSOC);
	}

	private function isUnhealthyState(string $state): bool {
		return in_array($this->normaliseState($state), [
			self::STATUS_UNREACHABLE,
			self::STATUS_NOT_REGISTERED,
		], true);
	}

	private function currentLiveStatusForReminder(array $row, array $liveContacts): string {
		$registrationKey = (string)($row['registration_key'] ?? '');
		if ($registrationKey !== '' && isset($liveContacts[$registrationKey])) {
			return $this->normaliseState($liveContacts[$registrationKey]['status'] ?? self::STATUS_UNKNOWN);
		}

		return self::STATUS_NOT_REGISTERED;
	}

	private function isReminderStillAlertable(string $currentStatus): bool {
		return $this->isUnhealthyState($currentStatus);
	}

	private function reminderAlertTypeForStatus(string $currentStatus): ?string {
		switch ($this->normaliseState($currentStatus)) {
			case self::STATUS_UNREACHABLE:
				return 'unreachable';
			case self::STATUS_NOT_REGISTERED:
				return 'not_registered';
			default:
				return null;
		}
	}

	private function retargetEscalationForReminder(array $row, string $alertType): bool {
		$conflict = $this->db()->prepare(
			'SELECT id, history_id FROM registrationwatch_alert_escalation
			WHERE registration_id = :registration_id
				AND alert_type = :alert_type
				AND id <> :id
			ORDER BY history_id DESC, id DESC
			LIMIT 1'
		);
		$conflict->execute([
			':registration_id' => (int)$row['registration_id'],
			':alert_type' => $alertType,
			':id' => (int)$row['id'],
		]);
		$conflictRow = $conflict->fetch(\PDO::FETCH_ASSOC);
		if (is_array($conflictRow)) {
			if ((int)$conflictRow['history_id'] >= (int)$row['history_id']) {
				$this->deleteEscalationById((int)$row['id']);
				return false;
			}
			$this->deleteEscalationById((int)$conflictRow['id']);
		}

		$stmt = $this->db()->prepare(
			'UPDATE registrationwatch_alert_escalation
			SET alert_type = :alert_type
			WHERE id = :id'
		);
		$stmt->execute([
			':alert_type' => $alertType,
			':id' => (int)$row['id'],
		]);

		return true;
	}

	private function buildReminderTransition(array $row, string $currentStatus, string $now): array {
		return [
			'id' => (int)$row['history_id'],
			'registration_id' => (int)$row['registration_id'],
			'registration_key' => (string)$row['registration_key'],
			'extension' => (string)$row['extension'],
			'from_state' => null,
			'to_state' => $currentStatus,
			'source' => 'reconcile',
			'reason' => 'reminder',
			'contact_uri' => $row['contact_uri'] ?? null,
			'latency_ms' => $row['latency_ms'] ?? null,
			'created_at' => $row['active_since'] ?: $now,
			'repeat_mode' => (string)($row['repeat_mode'] ?? ''),
			'reminder_n' => ((int)($row['alert_count'] ?? 0)) + 1,
			'alert_type' => $this->reminderAlertTypeForStatus($currentStatus),
		];
	}

	private function markReminderCycleComplete(array $row, int $reminderN, string $now): void {
		$repeatMode = $this->normaliseRepeatMode($row['repeat_mode'] ?? self::REPEAT_MODE_NEVER);
		$nextDueAt = $this->nextRepeatDueAt($now, $repeatMode, $reminderN);
		if ($nextDueAt === null) {
			$this->deleteEscalationById((int)$row['id']);
			return;
		}

		$stmt = $this->db()->prepare(
			'UPDATE registrationwatch_alert_escalation
			SET alert_count = :alert_count,
				last_alert_at = :last_alert_at,
				next_due_at = :next_due_at,
				updated_at = :updated_at
			WHERE id = :id'
		);
		$stmt->execute([
			':alert_count' => $reminderN,
			':last_alert_at' => $now,
			':next_due_at' => $nextDueAt,
			':updated_at' => $now,
			':id' => (int)$row['id'],
		]);
	}

        private function hasRecordedAlertForRecipient(int $historyId, string $alertType, string $recipient): bool {
                $stmt = $this->db()->prepare(
                        'SELECT COUNT(*)
                        FROM registrationwatch_alert_history
                        WHERE history_id = :history_id
                                AND alert_type = :alert_type
                                AND recipient = :recipient
                                AND reminder_n = 0'
                );
                $stmt->execute([
                        ':history_id' => $historyId,
                        ':alert_type' => $alertType,
                        ':recipient' => $recipient,
                ]);

                return (int)$stmt->fetchColumn() > 0;
        }

	private function runAsteriskCommand(string $command): string {
		$astman = $this->FreePBX->astman ?? null;
		if (!$astman) {
			throw new \Exception(_('Registration Watch could not query Asterisk. Confirm the FreePBX AMI user has Command privilege.'));
		}

		try {
			if (method_exists($astman, 'Command')) {
				$result = $astman->Command($command);
				return is_array($result) ? implode("\n", $result) : (string)$result;
			}

			if (method_exists($astman, 'send_request')) {
				$result = $astman->send_request('Command', ['Command' => $command]);
				if (is_array($result)) {
					if (isset($result['data'])) {
						return is_array($result['data']) ? implode("\n", $result['data']) : (string)$result['data'];
					}
					return implode("\n", array_map('strval', $result));
				}
				return (string)$result;
			}
		} catch (\Throwable $e) {
			throw new \Exception(_('Registration Watch could not query Asterisk. Confirm the FreePBX AMI user has Command privilege.') . ' ' . $e->getMessage(), 0, $e);
		}

		throw new \Exception(_('Registration Watch could not query Asterisk. Confirm the FreePBX AMI user has Command privilege.'));
	}

	private function parseUserAgentDetails(?string $userAgent): array {
		$userAgent = trim((string)$userAgent);

		if ($userAgent === '') {
			return [
				'device_name' => null,
				'firmware_version' => null,
			];
		}

		if (preg_match('/^([^\/]+)\/(.+)$/', $userAgent, $matches)) {
			return [
				'device_name' => trim($matches[1]) ?: null,
				'firmware_version' => trim($matches[2]) ?: null,
			];
		}

		if (preg_match('/^(.+?)\s+([0-9]+(?:\.[0-9A-Za-z_-]+)+)$/', $userAgent, $matches)) {
			return [
				'device_name' => trim($matches[1]) ?: null,
				'firmware_version' => trim($matches[2]) ?: null,
			];
		}

		// Sangoma P-series user agents include firmware followed by a 12-hex device id.
		// Example: "Sangoma P330 4_27_8 000FD3D0B030"
		if (preg_match('/^(Sangoma\s+P[0-9A-Za-z-]+)\s+([0-9]+(?:_[0-9A-Za-z]+)+)\s+([0-9A-Fa-f]{12})$/', $userAgent, $matches)) {
			return [
				'device_name' => trim($matches[1] . ' ' . strtoupper($matches[3])) ?: null,
				'firmware_version' => trim($matches[2]) ?: null,
			];
		}

		return [
			'device_name' => $userAgent,
			'firmware_version' => null,
		];
	}

	private function getRegistrarContactDetails(): array {
		$details = [];

		try {
			$output = $this->runAsteriskCommand('database show registrar/contact');
		} catch (\Throwable $e) {
			$this->logWarning('Registrar contact metadata unavailable: ' . $e->getMessage());
			return $details;
		}

		foreach (preg_split('/\r\n|\r|\n/', (string)$output) as $line) {
			$line = trim($line);

			if ($line === '' || strpos($line, '/registrar/contact/') !== 0) {
				continue;
			}

			$parts = explode(': ', $line, 2);
			if (count($parts) !== 2) {
				continue;
			}

			$key = $parts[0];
			$json = $parts[1];

			$payload = json_decode($json, true);
			if (!is_array($payload)) {
				continue;
			}

			$registration = (string)($payload['endpoint'] ?? '');
			if ($registration === '' && preg_match('#^/registrar/contact/([^;]+)#', $key, $matches)) {
				$registration = (string)$matches[1];
			}

			if ($registration === '') {
				continue;
			}

			$userAgent = isset($payload['user_agent']) ? (string)$payload['user_agent'] : '';
			$parsed = $this->parseUserAgentDetails($userAgent);

			$expiresAt = null;
			if (!empty($payload['expiration_time']) && ctype_digit((string)$payload['expiration_time'])) {
				$expiresAt = date('Y-m-d H:i:s', (int)$payload['expiration_time']);
			}

			$details[] = [
				'extension' => $this->normaliseRegistrationExtension($registration),
				'contact_uri' => isset($payload['uri']) && $payload['uri'] !== '' ? (string)$payload['uri'] : null,
				'source_ip' => isset($payload['via_addr']) && $payload['via_addr'] !== '' ? $this->normaliseSourceIp($payload['via_addr']) : null,
				'source_port' => isset($payload['via_port']) && is_numeric($payload['via_port']) ? (int)$payload['via_port'] : null,
				'user_agent' => $userAgent !== '' ? $userAgent : null,
				'device_name' => $parsed['device_name'],
				'firmware_version' => $parsed['firmware_version'],
				'contact_expires_at' => $expiresAt,
				'qualify_frequency' => isset($payload['qualify_frequency']) && is_numeric($payload['qualify_frequency'])
					? (int)$payload['qualify_frequency']
					: null,
			];
		}

		return $details;
	}

	private function getStoredRegistrations(): array {
		$stmt = $this->db()->query(
			'SELECT id, registration_key, registration_ua_class, extension, description, notes, notes_updated_at,
				enabled, auto_disabled_absent_at, repeat_mode, discovered, last_known_status, contact_uri,
				source_ip, source_port, contact_count, transport, user_agent, device_name, firmware_version,
				contact_expires_at, qualify_frequency, last_heartbeat_at, latency_ms, last_seen_at,
				last_checked_at, first_discovered_at, last_discovered_at
			FROM registrationwatch_registrations
			ORDER BY extension, source_ip, id'
		);

		$rows = $stmt ? $stmt->fetchAll(\PDO::FETCH_ASSOC) : [];
		if (!is_array($rows)) {
			return [];
		}

		return array_map([$this, 'withRegistrationDisplayAddress'], $rows);
	}

	private function getRegistrationMapRows(): array {
		$rows = [];
		foreach ($this->getStoredRegistrations() as $registration) {
			if ((int)$registration['discovered'] === 0) {
				continue;
			}
			$rows[] = [
				'id' => (int)$registration['id'],
				'registration_id' => (int)$registration['id'],
				'registration_key' => $registration['registration_key'],
				'registration_ua_class' => $registration['registration_ua_class'] ?? '',
				'extension' => $registration['extension'],
				'description' => $registration['description'],
				'notes' => $registration['notes'],
				'notes_updated_at' => $registration['notes_updated_at'],
				'enabled' => (int)$registration['enabled'],
				'repeat_mode' => $registration['repeat_mode'] ?? null,
				'status' => $registration['last_known_status'],
				'contact_uri' => $registration['contact_uri'],
				'source_ip' => $registration['source_ip'],
				'source_port' => $registration['source_port'] ?? null,
				'contact_count' => isset($registration['contact_count']) ? (int)$registration['contact_count'] : 1,
				'device_ip' => $registration['device_ip'] ?? null,
				'device_port' => $registration['device_port'] ?? null,
				'network_ip' => $registration['network_ip'] ?? null,
				'network_port' => $registration['network_port'] ?? null,
				'seen_by_asterisk' => $registration['seen_by_asterisk'] ?? null,
				'user_agent' => $registration['user_agent'] ?? null,
				'device_name' => $registration['device_name'] ?? null,
				'firmware_version' => $registration['firmware_version'] ?? null,
				'contact_expires_at' => $registration['contact_expires_at'] ?? null,
				'qualify_frequency' => $registration['qualify_frequency'] ?? null,
				'latency_ms' => $registration['latency_ms'],
				'last_seen_at' => $registration['last_seen_at'],
				'last_checked_at' => $registration['last_checked_at'],
			];
		}

		return $rows;
	}

	private function getWatchedExtensionGroups(): array {
		$all = $this->getStoredRegistrations();
		$byExtension = [];
		foreach ($all as $row) {
			$ext = (string)($row['extension'] ?? '');
			$byExtension[$ext][] = $row;
		}

		$groups = [];
		foreach ($byExtension as $contacts) {
			usort($contacts, function ($a, $b) {
				return (int)($a['id'] ?? 0) - (int)($b['id'] ?? 0);
			});
			$primary = $contacts[0];

			// Worst status wins: any unhealthy contact makes the group unhealthy.
			$groupStatus = (string)($primary['last_known_status'] ?? self::STATUS_UNKNOWN);
			$groupRank = $this->statusRank($groupStatus);
			foreach ($contacts as $contact) {
				$s = (string)($contact['last_known_status'] ?? self::STATUS_UNKNOWN);
				$rank = $this->statusRank($s);
				if ($rank < $groupRank) {
					$groupRank = $rank;
					$groupStatus = $s;
				}
			}

			$configuredEnabled = $this->getExtensionConfiguredMonitoringState((string)($primary['extension'] ?? ''));
			$enabled = $configuredEnabled === null ? 0 : $configuredEnabled;

			$discovered = 0;
			foreach ($contacts as $contact) {
				if ((int)($contact['discovered'] ?? 0)) {
					$discovered = 1;
					break;
				}
			}

			$groups[] = [
				'id' => (int)($primary['id'] ?? 0),
				'registration_id' => (int)($primary['id'] ?? 0),
				'registration_key' => (string)($primary['registration_key'] ?? ''),
				'extension' => (string)($primary['extension'] ?? ''),
				'description' => $primary['description'] ?? null,
				'notes' => (string)($primary['notes'] ?? ''),
				'notes_updated_at' => $primary['notes_updated_at'] ?? null,
				'enabled' => $enabled,
				'repeat_mode' => $primary['repeat_mode'] ?? null,
				'last_known_status' => $groupStatus,
				'status' => $groupStatus,
				'discovered' => $discovered,
			];
		}

		return $groups;
	}

	private function getLastRefreshTime(): string {
		$stmt = $this->db()->query('SELECT MAX(last_checked_at) FROM registrationwatch_registrations');
		$value = $stmt ? $stmt->fetchColumn() : '';
		return $value ? (string)$value : '';
	}

	private function getStatusHistory(): array {
		$page = $this->getHistoryPage(
			'registrationwatch_status_history',
			'id, registration_id, registration_key, extension, from_state, to_state, source, reason, contact_uri, latency_ms, created_at',
			'created_at',
			[
				'time' => 'created_at',
				'extension' => 'extension',
				'from' => 'from_state',
				'to' => 'to_state',
				'source' => "CASE WHEN TRIM(COALESCE(source, '')) = 'reconcile' THEN 'Asterisk' WHEN TRIM(COALESCE(source, '')) = '' THEN '-' ELSE TRIM(COALESCE(source, '')) END",
				'reason' => "CASE TRIM(COALESCE(reason, '')) WHEN 'status_change' THEN 'Status changed' WHEN 'removed' THEN 'Contact removed' WHEN 'reminder' THEN 'Repeat alert' WHEN 'ip_address_change' THEN 'IP address change' WHEN 'ip address change' THEN 'IP address change' WHEN '' THEN '-' ELSE TRIM(COALESCE(reason, '')) END",
				'latency' => 'latency_ms',
			],
			'ui_status_history_sort_key',
			'ui_status_history_sort_dir',
			'status_history'
		);

		$rows = $page['rows'];
		foreach ($rows as &$row) {
			$row['source'] = $this->sourceLabel($row['source'] ?? '');
			$row['reason'] = $this->reasonLabel($row['reason'] ?? '');
		}
		unset($row);
		$page['rows'] = $rows;

		return $page;
	}

	private function getAlertHistory(): array {
		$page = $this->getHistoryPage(
			'registrationwatch_alert_history',
			'id, registration_id, registration_key, extension, contact_uri, history_id, alert_type, status, recipient, subject, sent_at, result, error',
			'sent_at',
			[
				'time' => 'sent_at',
				'extension' => 'extension',
				'type' => 'alert_type',
				'status' => 'status',
				'recipient' => 'recipient',
				'result' => 'result',
				'error' => 'error',
			],
			'ui_alert_history_sort_key',
			'ui_alert_history_sort_dir',
			'alert_history'
		);
		$rows = $page['rows'];
		foreach ($rows as &$row) {
			$row['display_error'] = $this->formatAlertHistoryReasonForDisplay($row);
		}
		unset($row);
		$page['rows'] = $rows;

		return $page;
	}

	private function formatAlertHistoryReasonForDisplay(array $entry): string {
		$error = (string)($entry['error'] ?? '');
		if ($error === '') {
			return (string)($entry['result'] ?? '') === 'storm_suppressed' ? _('Covered by Storm Summary') : '';
		}
		$alertType = (string)($entry['alert_type'] ?? '');
		$result = (string)($entry['result'] ?? '');
		$stormFailurePrefix = 'Storm Summary delivery failed';
		if (($alertType === 'storm_summary' && $result === 'failed')
			|| $result === 'storm_summary_failed'
			|| strpos($error, $stormFailurePrefix) === 0
		) {
			$diagnostic = $error;
			if (strpos($diagnostic, $stormFailurePrefix) === 0) {
				$diagnostic = trim(substr($diagnostic, strlen($stormFailurePrefix)));
				if (strpos($diagnostic, ':') === 0) {
					$diagnostic = trim(substr($diagnostic, 1));
				}
			}
			return _('Storm Summary delivery failed') . ($diagnostic !== '' ? ': ' . $diagnostic : '');
		}

		$displayReasons = [
			'Debounce Delay' => _('Debounce Delay'),
			'Original problem alert suppressed (Debounce Delay)' => _('Debounce Delay'),
			'Monitoring snoozed' => _('Monitoring Snooze'),
			'Original problem alert suppressed (Monitoring snoozed)' => _('Monitoring Snooze'),
			'No successful problem notification delivered' => _('Problem notification not delivered'),
		];
		if (isset($displayReasons[$error])) {
			return $displayReasons[$error];
		}

		return $error;
	}

	private function getHistoryPage(string $table, string $columns, string $defaultColumn, array $sortColumns, string $settingKey, string $settingDir, string $requestPrefix): array {
		$settings = $this->getAlertSettings();
		$sortKey = isset($_REQUEST[$requestPrefix . '_sort_key']) ? (string)$_REQUEST[$requestPrefix . '_sort_key'] : (string)$settings[$settingKey];
		$sortColumn = $sortColumns[$sortKey] ?? $defaultColumn;
		$sortDir = isset($_REQUEST[$requestPrefix . '_sort_dir']) ? strtolower((string)$_REQUEST[$requestPrefix . '_sort_dir']) : strtolower((string)$settings[$settingDir]);
		$sortDir = $sortDir === 'asc' ? 'ASC' : 'DESC';
		$offsetValue = isset($_REQUEST[$requestPrefix . '_offset']) ? (string)$_REQUEST[$requestPrefix . '_offset'] : '0';
		$offset = ctype_digit($offsetValue) ? (int)$offsetValue : 0;
		$offset -= $offset % self::HISTORY_PAGE_SIZE;

		$countStmt = $this->db()->query('SELECT COUNT(*) FROM ' . $table);
		$total = $countStmt ? (int)$countStmt->fetchColumn() : 0;
		if ($total === 0) {
			$offset = 0;
		} elseif ($offset >= $total) {
			$offset = (int)(floor(($total - 1) / self::HISTORY_PAGE_SIZE) * self::HISTORY_PAGE_SIZE);
		}

		$stmt = $this->db()->prepare(
			'SELECT ' . $columns . ' FROM ' . $table .
			' ORDER BY ' . $sortColumn . ' ' . $sortDir . ', id ' . $sortDir .
			' LIMIT :limit OFFSET :offset'
		);
		$stmt->bindValue(':limit', self::HISTORY_PAGE_SIZE, \PDO::PARAM_INT);
		$stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
		$stmt->execute();

		return [
			'rows' => $stmt->fetchAll(\PDO::FETCH_ASSOC),
			'total' => $total,
			'offset' => $offset,
			'limit' => self::HISTORY_PAGE_SIZE,
		];
	}

	private function getPruneSettings(): array {
		$settings = $this->getAlertSettings();

		return [
			'status_history_prune_policy' => $this->normalisePrunePolicy($settings['status_history_prune_policy'] ?? 'never'),
			'alert_history_prune_policy' => $this->normalisePrunePolicy($settings['alert_history_prune_policy'] ?? 'never'),
		];
	}

	private function normalisePrunePolicy(string $policy): string {
		$policy = strtolower(trim($policy));
		return in_array($policy, ['hourly', 'daily', 'monthly', 'yearly', 'never'], true) ? $policy : 'never';
	}

	private function applyHistoryPruning(?string $historyType = null, ?string $policy = null): array {
		$deleted = [
			'status' => 0,
			'alert' => 0,
		];

		if ($historyType !== null) {
			if ($historyType === 'status') {
				$deleted['status'] = $this->pruneStatusHistory($this->normalisePrunePolicy((string)$policy));
			} elseif ($historyType === 'alert') {
				$deleted['alert'] = $this->pruneAlertHistory($this->normalisePrunePolicy((string)$policy));
			}

			return $deleted;
		}

		$settings = $this->getPruneSettings();
		$deleted['status'] = $this->pruneStatusHistory($settings['status_history_prune_policy']);
		$deleted['alert'] = $this->pruneAlertHistory($settings['alert_history_prune_policy']);

		return $deleted;
	}

	private function pruneStatusHistory(string $policy): int {
		$cutoff = $this->pruneCutoff($policy);
		if ($cutoff === null) {
			return 0;
		}

		$stmt = $this->db()->prepare('DELETE FROM registrationwatch_status_history WHERE created_at < :cutoff');
		$stmt->execute([':cutoff' => $cutoff]);
		return $stmt->rowCount();
	}

	private function pruneAlertHistory(string $policy): int {
		$cutoff = $this->pruneCutoff($policy);
		if ($cutoff === null) {
			return 0;
		}

		$stmt = $this->db()->prepare('DELETE FROM registrationwatch_alert_history WHERE sent_at < :cutoff');
		$stmt->execute([':cutoff' => $cutoff]);
		return $stmt->rowCount();
	}

	private function pruneCutoff(string $policy): ?string {
		$policy = $this->normalisePrunePolicy($policy);
		if ($policy === 'never') {
			return null;
		}

		try {
			$cutoff = new \DateTimeImmutable($this->now());
			switch ($policy) {
				case 'hourly':
					$cutoff = $cutoff->modify('-1 hour');
					break;
				case 'daily':
					$cutoff = $cutoff->modify('-1 day');
					break;
				case 'monthly':
					$cutoff = $cutoff->modify('-1 month');
					break;
				case 'yearly':
					$cutoff = $cutoff->modify('-1 year');
					break;
				default:
					return null;
			}
		} catch (\Exception $e) {
			$this->logError('Unable to calculate history pruning cutoff: ' . $e->getMessage());
			return null;
		}

		return $cutoff->format('Y-m-d H:i:s');
	}

	private function normaliseAlertTimingSeconds(string $key, string $default): ?int {
		$value = isset($_REQUEST[$key]) ? trim((string)$_REQUEST[$key]) : trim($default);
		if ($value === '' || !ctype_digit($value)) {
			return null;
		}

		$seconds = (int)$value;
		if ($seconds < 0 || $seconds > self::ALERT_TIMING_MAX_SECONDS) {
			return null;
		}

		return $seconds;
	}

	private function normaliseRepeatMode(?string $mode): string {
		$mode = strtolower(trim((string)$mode));
		if ($mode === self::REPEAT_MODE_FIBONACCI) {
			return self::REPEAT_MODE_ESCALATING;
		}

		return in_array($mode, self::REPEAT_MODES, true) ? $mode : self::REPEAT_MODE_NEVER;
	}

	private function normaliseStormThreshold(string $value): ?int {
		$value = trim($value);
		if ($value === '') {
			return 0;
		}
		if (!ctype_digit($value)) {
			return null;
		}

		$threshold = (int)$value;
		if ($threshold < 0 || $threshold > 10000) {
			return null;
		}

		return $threshold;
	}

	private function repeatIntervalSeconds(string $repeatMode, int $alertCount): ?int {
		switch ($this->normaliseRepeatMode($repeatMode)) {
			case self::REPEAT_MODE_FIVE_MINUTES:
				return 300;
			case self::REPEAT_MODE_HOURLY:
				return 3600;
			case self::REPEAT_MODE_DAILY:
				return self::REPEAT_DAILY_SECONDS;
			case self::REPEAT_MODE_ESCALATING:
				return $this->escalatingRepeatIntervalSeconds($alertCount);
			case self::REPEAT_MODE_NEVER:
			default:
				return null;
		}
	}

	private function nextRepeatDueAt(string $lastAlertAt, string $repeatMode, int $alertCount): ?string {
		$interval = $this->repeatIntervalSeconds($repeatMode, $alertCount);
		if ($interval === null) {
			return null;
		}

		$timestamp = strtotime($lastAlertAt);
		if ($timestamp === false) {
			$timestamp = strtotime($this->now());
		}

		return date('Y-m-d H:i:s', $timestamp + $interval);
	}

	// alert_count is the number of reminders already sent. This returns the
	// wait until the next reminder using a Fibonacci-style multiplier sequence
	// (1, 1, 2, 3, 5, 8, …) on a 5-minute base, capped at the daily ceiling.
	// alertCount 0 and 1 both map to multiplier 1 (5 m), giving exactly two
	// 5-minute gaps before the sequence begins to grow.
	private function escalatingRepeatIntervalSeconds(int $alertCount): int {
		$step = max(1, $alertCount + 1);
		$previous = 0;
		$current = 1;

		for ($i = 1; $i < $step; $i++) {
			$next = $previous + $current;
			$previous = $current;
			$current = $next;

			if ($current * self::REPEAT_ESCALATING_BASE_SECONDS >= self::REPEAT_ESCALATING_CEILING_SECONDS) {
				return self::REPEAT_ESCALATING_CEILING_SECONDS;
			}
		}

		return min(
			self::REPEAT_ESCALATING_CEILING_SECONDS,
			$current * self::REPEAT_ESCALATING_BASE_SECONDS
		);
	}

	private function positiveRequestId(string $key): int {
		$value = isset($_REQUEST[$key]) ? (string)$_REQUEST[$key] : '';
		if (!ctype_digit($value)) {
			return 0;
		}

		$id = (int)$value;
		return $id > 0 ? $id : 0;
	}

	private function getAlertSettings(): array {
		$settings = $this->settingsDefaults;
		$stmt = $this->db()->query('SELECT setting_key, setting_value FROM registrationwatch_settings');
		if ($stmt) {
			foreach ($stmt->fetchAll(\PDO::FETCH_ASSOC) as $row) {
				$key = (string)$row['setting_key'];
				if (array_key_exists($key, $settings)) {
					$settings[$key] = (string)$row['setting_value'];
				}
			}
		}

		return $settings;
	}

	private function setSetting(string $key, string $value): void {
		$stmt = $this->db()->prepare(
			'INSERT INTO registrationwatch_settings (setting_key, setting_value, updated_at)
			VALUES (:setting_key, :setting_value, :updated_at)
			ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)'
		);
		$stmt->execute([
			':setting_key' => $key,
			':setting_value' => $value,
			':updated_at' => $this->now(),
		]);
	}

	private function normaliseRecipients(string $raw): array {
		$parts = preg_split('/[,;\s]+/', trim($raw));
		$recipients = [];

		foreach ($parts as $part) {
			$email = trim((string)$part);
			if ($email === '') {
				continue;
			}
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				continue;
			}
			$recipients[strtolower($email)] = $email;
		}

		return array_values($recipients);
	}

	private function getRegistrationDetailsById(int $registrationId): array {
		$stmt = $this->db()->prepare(
			'SELECT id, registration_key, extension, description, last_known_status, contact_uri, source_ip, source_port,
				user_agent, device_name, firmware_version, contact_expires_at,
				qualify_frequency, last_checked_at
			FROM registrationwatch_registrations
			WHERE id = :id
			LIMIT 1'
		);
		$stmt->execute([':id' => $registrationId]);

		$row = $stmt->fetch(\PDO::FETCH_ASSOC);
		return is_array($row) ? $this->withRegistrationDisplayAddress($row) : [];
	}

	private function withRegistrationDisplayAddress(array $registration): array {
		$addressDetails = $this->registrationAddressDetails(
			$registration['contact_uri'] ?? null,
			$registration['source_ip'] ?? null,
			$registration['source_port'] ?? null
		);
		$registration['device_ip'] = $addressDetails['device_ip'];
		$registration['device_port'] = $addressDetails['device_port'];
		$registration['network_ip'] = $addressDetails['network_ip'];
		$registration['network_port'] = $addressDetails['network_port'];
		$registration['seen_by_asterisk'] = $this->formatSeenByAsterisk(
			$registration['source_ip'] ?? null,
			$registration['source_port'] ?? null
		);

		return $registration;
	}

	private function formatSeenByAsterisk($sourceIp, $sourcePort): ?string {
		$sourceIp = trim((string)$sourceIp);
		if ($sourceIp === '') {
			return null;
		}

		if ($sourcePort !== null && $sourcePort !== '' && is_numeric($sourcePort)) {
			$port = (int)$sourcePort;
			if ($port > 0 && $port <= 65535) {
				return $sourceIp . ':' . $port;
			}
		}

		return $sourceIp;
	}

	private function buildAlertEmail(array $transition, string $alertType): array {
		$extension = (string)$transition['extension'];
		$toState = $this->normaliseState($transition['to_state'] ?? '');
		$subjectStatus = $this->stateLabel($toState);
		$isReminder = ($transition['reason'] ?? '') === 'reminder';
		if ($alertType === 'recovery') {
			$subjectStatus = 'has recovered';
		}

		$still = ($isReminder && $alertType !== 'recovery') ? 'still ' : '';
		$subject = 'Registration Watch: ' . $extension . ' ' . ($alertType === 'recovery' ? $subjectStatus : 'is ' . $still . $subjectStatus);
		$latencyValue = $transition['latency_ms'] ?? null;
		$latency = $latencyValue !== null && $latencyValue !== '' ? (string)$latencyValue . ' ms' : 'Unavailable';
		if ($toState === self::STATUS_REGISTERED_NO_QUALIFY) {
			$latency = 'Unavailable; qualify is not enabled.';
		}
		$registrationDetails = !empty($transition['registration_id'])
			? $this->getRegistrationDetailsById((int)$transition['registration_id'])
			: [];
		$deviceName = trim((string)($registrationDetails['device_name'] ?? ''));
		$firmwareVersion = trim((string)($registrationDetails['firmware_version'] ?? ''));
		$userAgent = trim((string)($registrationDetails['user_agent'] ?? ''));
		$historicalAddress = $toState === self::STATUS_NOT_REGISTERED;
		$contactUriForAddress = $registrationDetails['contact_uri'] ?? null;
		$sourceIpForAddress = $registrationDetails['source_ip'] ?? null;
		$sourcePortForAddress = $registrationDetails['source_port'] ?? null;
		if ($toState === self::STATUS_NOT_REGISTERED) {
			$contactUriForAddress = $transition['contact_uri'] ?? null;
		}
		$addressDetails = $this->registrationAddressDetails($contactUriForAddress, $sourceIpForAddress, $sourcePortForAddress);
		$addressPrefix = $historicalAddress ? 'Last ' : '';
		$reasonLine = ['Reason: ' . $this->reasonLabel($transition['reason'] ?? '')];
		if ($isReminder) {
			$reasonLine[] = 'Repeat mode: ' . $this->repeatModeLabel((string)($transition['repeat_mode'] ?? ''));
			$reminderN = (int)($transition['reminder_n'] ?? 0);
			if ($reminderN > 0) {
				$reasonLine[] = 'Reminder: ' . $reminderN;
			}
		}
		$systemIdentifier = $this->getSystemIdentifier();
		$message = array_merge(
			[
				'Registration Watch state change from ' . $systemIdentifier,
				'',
				'Extension: ' . $extension,
				'New state: ' . $this->stateLabel($toState),
			],
			$reasonLine,
			[
				'Latency: ' . $latency,
				'',
				'Device: ' . ($deviceName !== '' ? $deviceName : 'Unknown'),
				'Version: ' . ($firmwareVersion !== '' ? $firmwareVersion : 'Unknown'),
				$addressPrefix . 'Device IP: ' . (($addressDetails['device_ip'] ?? '') !== '' ? $addressDetails['device_ip'] : 'Unknown'),
				$addressPrefix . 'Device Port: ' . (($addressDetails['device_port'] ?? '') !== '' ? $addressDetails['device_port'] : 'Unknown'),
				$addressPrefix . 'Network IP: ' . (($addressDetails['network_ip'] ?? '') !== '' ? $addressDetails['network_ip'] : 'Unknown'),
				$addressPrefix . 'Network Port: ' . (($addressDetails['network_port'] ?? '') !== '' ? $addressDetails['network_port'] : 'Unknown'),
				'Contact expires: ' . (($registrationDetails['contact_expires_at'] ?? '') !== '' ? $registrationDetails['contact_expires_at'] : 'Unknown'),
				'Qualify frequency: ' . (($registrationDetails['qualify_frequency'] ?? '') !== '' ? $registrationDetails['qualify_frequency'] . ' seconds' : 'Unknown'),
				'Transition time: ' . $transition['created_at'],
				'Source: Asterisk',
				'',
				'Please note: email deliveries can be delayed.',
				'Check current status in the FreePBX module.',
			]
		);

		return [
			'subject' => $subject,
			'message' => implode("\n", $message),
		];
	}

	private function sendEmail(string $recipient, string $subject, string $message): array {
		// Follow the broad FreePBX missedcall CI_Email pattern. Do not fall
		// back to raw mail(); failures are returned for alert-history storage.
		try {
			if (!class_exists('\CI_Email')) {
				return ['status' => false, 'message' => 'CI_Email is not available.'];
			}

			$from = $this->resolveNotificationFrom();
			if ($from['address'] === '') {
				return ['status' => false, 'message' => 'Email "From:" Address is not configured in Advanced Settings.'];
			}

			$email = new \CI_Email();
			if ($this->emailFromSupportsReturnPath($email)) {
				$email->from($from['address'], $from['name'], $from['address']);
			} else {
				$email->from($from['address'], $from['name']);
				if (method_exists($email, 'set_header')) {
					$email->set_header('Return-Path', $from['address']);
				}
			}
			if (method_exists($email, 'reply_to')) {
				$email->reply_to($from['address'], $from['name']);
			}
			$email->to($recipient);
			$email->subject($subject);
			$email->set_mailtype('text');
			$email->message($message);

			if ($email->send()) {
				return ['status' => true, 'message' => 'accepted by local mailer; delivery not confirmed'];
			}

			$error = 'CI_Email send failed.';
			if (method_exists($email, 'print_debugger')) {
				$debug = trim(strip_tags((string)$email->print_debugger(['headers'])));
				if ($debug !== '') {
					$error .= ' ' . $debug;
				}
			}

			return ['status' => false, 'message' => $error];
		} catch (\Exception $e) {
			return ['status' => false, 'message' => $e->getMessage()];
		}
	}

	private function getConfiguredNotificationFrom(): string {
		return $this->getFreePBXConfigValue('AMPUSERMANEMAILFROM');
	}

	private function getFreePBXConfigValue(string $key): string {
		try {
			if (isset($this->FreePBX->Config)) {
				return (string)$this->FreePBX->Config->get($key);
			}
			if (method_exists($this->FreePBX, 'Config')) {
				return (string)$this->FreePBX->Config()->get($key);
			}
		} catch (\Throwable $e) {
			// Fall through and fail safely rather than guessing a sender domain.
		}

		return '';
	}

	private function resolveNotificationFrom(): array {
		$resolved = $this->parseNotificationFrom($this->getConfiguredNotificationFrom());
		if ($resolved['address'] !== '' && $resolved['name'] === '') {
			$resolved['name'] = $this->getNotificationSenderNameFallback();
		}

		return $resolved;
	}

	private function parseNotificationFrom(string $value): array {
		$value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$value = trim($value);
		$invalid = ['address' => '', 'name' => ''];
		if ($value === '' || preg_match('/[\r\n]/', $value)) {
			return $invalid;
		}

		$name = '';
		$address = $value;
		if (strpos($value, '<') !== false || strpos($value, '>') !== false) {
			if (!preg_match('/^(?:([^<>]+?)\s*)?<([^<>]+)>$/', $value, $matches)) {
				return $invalid;
			}
			$name = isset($matches[1]) ? trim($matches[1]) : '';
			$address = trim($matches[2]);
		}

		if (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
			return $invalid;
		}

		return ['address' => $address, 'name' => $name];
	}

	private function getNotificationSenderNameFallback(): string {
		$brand = trim($this->getFreePBXConfigValue('DASHBOARD_FREEPBX_BRAND'));
		if ($brand !== '') {
			return $brand;
		}

		return 'Registration Watch';
	}

	private function emailFromSupportsReturnPath($email): bool {
		try {
			$method = new \ReflectionMethod($email, 'from');
			return $method->getNumberOfParameters() >= 3;
		} catch (\ReflectionException $e) {
			return false;
		}
	}

	private function insertAlertHistory(array $alert): void {
		$stmt = $this->db()->prepare(
			'INSERT IGNORE INTO registrationwatch_alert_history
				(registration_id, registration_key, extension, contact_uri, history_id, reminder_n, alert_type, status, recipient, subject, message, sent_at, result, error)
			VALUES
				(:registration_id, :registration_key, :extension, :contact_uri, :history_id, :reminder_n, :alert_type, :status, :recipient, :subject, :message, :sent_at, :result, :error)'
		);
		$stmt->execute([
			':registration_id' => $alert['registration_id'] ?? null,
			':registration_key' => $alert['registration_key'] ?? null,
			':extension' => $alert['extension'],
			':contact_uri' => $alert['contact_uri'] ?? null,
			':history_id' => $alert['history_id'],
			':reminder_n' => $alert['reminder_n'] ?? 0,
			':alert_type' => $alert['alert_type'],
			':status' => $alert['status'],
			':recipient' => $alert['recipient'],
			':subject' => $alert['subject'],
			':message' => $alert['message'],
			':sent_at' => $alert['sent_at'],
			':result' => $alert['result'],
			':error' => $alert['error'],
		]);
	}

	private function reserveAlertHistory(array $alert): bool {
		$stmt = $this->db()->prepare(
			'INSERT IGNORE INTO registrationwatch_alert_history
				(registration_id, registration_key, extension, contact_uri, history_id, reminder_n, alert_type, status, recipient, subject, message, sent_at, result, error)
			VALUES
				(:registration_id, :registration_key, :extension, :contact_uri, :history_id, :reminder_n, :alert_type, :status, :recipient, :subject, :message, :sent_at, :result, :error)'
		);
		$stmt->execute([
			':registration_id' => $alert['registration_id'] ?? null,
			':registration_key' => $alert['registration_key'] ?? null,
			':extension' => $alert['extension'],
			':contact_uri' => $alert['contact_uri'] ?? null,
			':history_id' => $alert['history_id'],
			':reminder_n' => $alert['reminder_n'] ?? 0,
			':alert_type' => $alert['alert_type'],
			':status' => $alert['status'],
			':recipient' => $alert['recipient'],
			':subject' => $alert['subject'],
			':message' => $alert['message'],
			':sent_at' => $alert['sent_at'],
			':result' => $alert['result'],
			':error' => $alert['error'],
		]);

		return $stmt->rowCount() > 0;
	}

	private function updateReservedAlertHistory(int $historyId, string $alertType, string $recipient, string $result, ?string $error, string $sentAt, int $reminderN = 0): void {
		$stmt = $this->db()->prepare(
			'UPDATE registrationwatch_alert_history
			SET sent_at = :sent_at,
				result = :result,
				error = :error
			WHERE history_id = :history_id
				AND alert_type = :alert_type
				AND recipient = :recipient
				AND reminder_n = :reminder_n'
		);
		$stmt->execute([
			':sent_at' => $sentAt,
			':result' => $result,
			':error' => $error,
			':history_id' => $historyId,
			':alert_type' => $alertType,
			':recipient' => $recipient,
			':reminder_n' => $reminderN,
		]);
	}

	private function tableExists(string $table): bool {
		$stmt = $this->db()->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table');
		$stmt->execute([':table' => $table]);
		return (int)$stmt->fetchColumn() > 0;
	}

	private function createCsrfToken(): string {
		if (!$this->ensureSessionForCsrfWrite()) {
			return '';
		}

		$token = isset($_SESSION[self::CSRF_SESSION_KEY]) ? (string)$_SESSION[self::CSRF_SESSION_KEY] : '';
		if ($token !== '') {
			return $token;
		}

		try {
			$token = bin2hex(random_bytes(32));
			$_SESSION[self::CSRF_SESSION_KEY] = $token;
			return $token;
		} catch (\Throwable $e) {
			$this->logWarning('Unable to create Registration Watch CSRF token: ' . $e->getMessage());
			return '';
		}
	}

	private function ensureSessionForCsrfWrite(): bool {
		if (!function_exists('session_status')) {
			return isset($_SESSION) && is_array($_SESSION);
		}

		$status = session_status();
		if ($status === PHP_SESSION_ACTIVE) {
			return true;
		}

		if ($status === PHP_SESSION_DISABLED || headers_sent()) {
			return false;
		}

		return @session_start();
	}

	private function validateCsrfToken(): bool {
		$sessionToken = isset($_SESSION[self::CSRF_SESSION_KEY]) ? (string)$_SESSION[self::CSRF_SESSION_KEY] : '';
		if ($sessionToken === '') {
			return false;
		}

		$token = isset($_REQUEST['token']) ? (string)$_REQUEST['token'] : '';
		if ($token === '') {
			return false;
		}

		return hash_equals($sessionToken, $token);
	}

	private function logError(string $message): void {
		try {
			if (method_exists('\FreePBX', 'Log')) {
				\FreePBX::Log()->error('registrationwatch: ' . $message);
			}
		} catch (\Exception $e) {
			// Logging unavailable; silently continue
		}
	}

	private function logWarning(string $message): void {
		try {
			if (method_exists('\FreePBX', 'Log')) {
				\FreePBX::Log()->warning('registrationwatch: ' . $message);
			}
		} catch (\Exception $e) {
			// Logging unavailable; silently continue
		}
	}

	private function logInfo(string $message): void {
		try {
			if (method_exists('\FreePBX', 'Log')) {
				\FreePBX::Log()->info('registrationwatch: ' . $message);
			}
		} catch (\Exception $e) {
			// Logging unavailable; silently continue
		}
	}


	public function runBackgroundMonitor($output = null): bool {
		try {
			$settings = $this->getAlertSettings();
			$this->applyHistoryPruning();

			$interval = (int)($settings['topology_poll_interval_seconds'] ?? 10);
			if ($interval <= 0) {
				if ($output && method_exists($output, 'writeln')) {
					$output->writeln('Registration Watch background job skipped: polling disabled.');
				}
				return true;
			}

			$this->reconcileCurrentStatus();

			if ($output && method_exists($output, 'writeln')) {
				if (($settings['alert_enabled'] ?? '0') === '1') {
					$output->writeln('Registration Watch background job completed.');
				} else {
					$output->writeln('Registration Watch background job completed; alerts disabled.');
				}
			}

			return true;
		} catch (\Throwable $e) {
			$this->logError('Background job failed: ' . $e->getMessage());

			if ($output && method_exists($output, 'writeln')) {
				$output->writeln('<error>Registration Watch background job failed: ' . $e->getMessage() . '</error>');
			}

			return false;
		}
	}

	public function runWebhookDeliveryWorker(): bool {
		$this->processWebhookQueue(
			$this->now(),
			null,
			null,
			null,
			self::WEBHOOK_WORKER_BATCH_LIMIT
		);
		return true;
	}

	private function getEmailStatus(): array {
		$settings = $this->getAlertSettings();
		$recipients = $this->normaliseRecipients($settings['alert_recipients']);
		$from = $this->resolveNotificationFrom();

		return [
			'ci_email_available' => class_exists('\CI_Email'),
			'from_address_configured' => $from['address'] !== '',
			'alerts_enabled' => $settings['alert_enabled'] === '1',
			'recipients_configured' => count($recipients) > 0,
			'recipient_count' => count($recipients),
		];
	}

	private function db() {
		return \FreePBX::Database();
	}

	private function sourceLabel(?string $source): string {
		$source = trim((string)$source);

		if ($source === 'reconcile') {
			return 'Asterisk';
		}

		return $source !== '' ? $source : '-';
	}

	private function reasonLabel(?string $reason): string {
		$reason = trim((string)$reason);

		switch ($reason) {
			case 'status_change':
				return 'Status changed';
			case 'removed':
				return 'Contact removed';
			case 'reminder':
				return 'Repeat alert';
			case 'ip_address_change':
			case 'ip address change':
				return 'IP address change';
		}

		return $reason !== '' ? $reason : '-';
	}

	private function repeatModeLabel(string $repeatMode): string {
		switch ($this->normaliseRepeatMode($repeatMode)) {
			case self::REPEAT_MODE_FIVE_MINUTES: return 'Every 5 minutes';
			case self::REPEAT_MODE_HOURLY:       return 'Hourly';
			case self::REPEAT_MODE_DAILY:        return 'Daily';
			case self::REPEAT_MODE_ESCALATING:   return 'Escalating';
			default:                             return $repeatMode !== '' ? $repeatMode : 'Never';
		}
	}

	private function stateLabel(?string $state): string {
		$state = $this->normaliseState($state);

		return $state !== '' ? $state : '-';
	}

	private function normaliseState($state): string {
		$state = trim((string)$state);

		switch (strtolower($state)) {
			case 'not_registered':
			case 'not registered':
				return self::STATUS_NOT_REGISTERED;
			case 'registered_no_qualify':
			case 'registered (no qualify)':
				return self::STATUS_REGISTERED_NO_QUALIFY;
		}

		return $state;
	}

	private function isMonitoringSnoozed(): bool {
		$settings = $this->getAlertSettings();
		$until = trim((string)($settings['monitoring_snoozed_until'] ?? ''));
		if ($until === '') {
			return false;
		}
		$ts = strtotime($until);
		return $ts !== false && $ts > strtotime($this->now());
	}

	private function hasMonitoredExtensions(): bool {
		try {
			$stmt = $this->db()->query(
				'SELECT COUNT(*) FROM registrationwatch_registrations WHERE enabled = 1 AND discovered = 1'
			);
			return $stmt ? (int)$stmt->fetchColumn() > 0 : false;
		} catch (\Throwable $e) {
			return false;
		}
	}

	private function getMonitoringState(): array {
		if (!$this->hasMonitoredExtensions()) {
			return ['state' => 'inactive', 'snoozed_until' => null];
		}
		$settings = $this->getAlertSettings();
		$until = trim((string)($settings['monitoring_snoozed_until'] ?? ''));
		if ($until !== '') {
			$ts = strtotime($until);
			if ($ts !== false && $ts > strtotime($this->now())) {
				return ['state' => 'snoozed', 'snoozed_until' => $until];
			}
		}
		return ['state' => 'active', 'snoozed_until' => null];
	}

	private function now(): string {
		return date('Y-m-d H:i:s');
	}
}
